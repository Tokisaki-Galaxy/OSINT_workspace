---
title: 女生的那些行为会让男生很下头（好感度下降）？
url: https://www.zhihu.com/question/473106718/answer/1951366084323173481
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-16 19:25
modified: 2025-09-16 19:25
upvote_num: 2
comment_num: 0
---

"我将来想当老师"

