---
title: 男孩子是真的介意女生的长相吗？
url: https://www.zhihu.com/question/319045805/answer/1945841693980090522
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 13:33
modified: 2025-09-01 13:33
upvote_num: 2
comment_num: 0
---

不上床不恋爱的话我是完全不介意的。

一起玩剧本杀一起聊天这些事情我是完全不关注对方脸的

