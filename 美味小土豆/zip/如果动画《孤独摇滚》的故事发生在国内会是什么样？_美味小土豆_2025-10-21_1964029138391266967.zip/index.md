---
title: 如果动画《孤独摇滚》的故事发生在国内会是什么样？
url: https://www.zhihu.com/question/588159677/answer/1964029138391266967
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 18:03
modified: 2025-10-21 18:03
upvote_num: 28
comment_num: 4
---

我高中就有像小孤独那样巨内向巨敏感长得还不错的女生。

巨好追。什么主见都没有，你牵着干什么她都会听你的，很乖。

小孤独换个剧本妥妥的rbq。

所以我很喜欢孤独摇滚。

