---
title: 如何看待“我可以给，但你不能主动要，从你开口那瞬间，你在我心里就没价值了” 这句话?
url: https://www.zhihu.com/question/552411568/answer/1965404951057502399
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-25 13:10
modified: 2025-10-25 13:10
upvote_num: 36
comment_num: 2
---

所有给过我钱的姑娘都很明确的和我说过：你想要什么就直接说，不要支支吾吾黏黏糊糊的。

我觉得标题这段话就黏黏糊糊的，一副不想给又不许别人说的鸡贼小气模样。

