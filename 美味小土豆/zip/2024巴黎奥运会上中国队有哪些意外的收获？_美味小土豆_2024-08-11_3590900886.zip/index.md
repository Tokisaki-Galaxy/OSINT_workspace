---
title: 2024巴黎奥运会上中国队有哪些意外的收获？
url: https://www.zhihu.com/question/663824292/answer/3590900886
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-11 13:51
modified: 2024-08-11 13:51
upvote_num: 11
comment_num: 2
---

金牌的话：小轮车，拳击，皮划艇，100米自由泳，银牌的话：攀岩，摔跤等等

感觉中国队这次获奖牌的类别比以前要多，并不是都围绕着传统优势项目的

不像你乎上说得那么不堪啊

