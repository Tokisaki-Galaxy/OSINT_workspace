---
title: 为什么部分女性喜欢用红姐事件来攻击男性？
url: https://www.zhihu.com/question/1929843795677148831/answer/1955312309573492923
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 16:46
modified: 2025-09-27 16:46
upvote_num: 5
comment_num: 1
---

不是，我一个男的我都想不通啊

你们是真的不挑的吗？！

真的太恶心了吧!

这事在男人之间只会被嘲的更过分啊

"你那么喜欢🌿老头的●眼?小区门口的阿爷你要不要也去问问哈哈哈哈哈"

