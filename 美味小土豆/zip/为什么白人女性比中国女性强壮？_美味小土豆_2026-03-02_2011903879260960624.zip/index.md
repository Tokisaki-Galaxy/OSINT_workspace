---
title: 为什么白人女性比中国女性强壮？
url: https://www.zhihu.com/question/10428605389/answer/2011903879260960624
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-02 20:41
modified: 2026-03-02 20:41
upvote_num: 5
comment_num: 5
---

其实差不多，按床上都挣扎不开。

