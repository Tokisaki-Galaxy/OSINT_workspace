---
title: 二次元的常识你觉得有哪些?
url: https://www.zhihu.com/question/9093333570/answer/2011208764922011798
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-28 22:38
modified: 2026-02-28 22:40
upvote_num: 3
comment_num: 0
---

一般来说，你可以管下面这类玩意叫"机动兵器"，"人形兵器"都行，而唯独不是"机甲"

![](./assets/v2-b6dbe72cfbfc9713ac68ad9d87de974a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='725' height='770'></svg>)

  


![](./assets/v2-295a7b178147c12f098dd58d85f3275b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2362' height='3507'></svg>)

