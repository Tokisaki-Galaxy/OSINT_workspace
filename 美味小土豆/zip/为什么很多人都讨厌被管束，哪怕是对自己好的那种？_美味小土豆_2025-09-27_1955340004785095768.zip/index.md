---
title: 为什么很多人都讨厌被管束，哪怕是对自己好的那种？
url: https://www.zhihu.com/question/1955212706190714209/answer/1955340004785095768
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 18:36
modified: 2025-09-27 18:36
upvote_num: 2
comment_num: 0
---

因为我就是想尝试一下那些对自己不好的事情呀！

![](./assets/v2-be1a326a39e254b3dec0395691ddfe3c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='876'></svg>)

