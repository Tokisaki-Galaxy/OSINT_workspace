---
title: 女生袜子都是香的吗？女生是不是没有脚气?
url: https://www.zhihu.com/question/1915104902826403023/answer/1949174029266188164
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 18:15
modified: 2025-09-10 18:15
upvote_num: 204
comment_num: 36
---

脚臭体质真是个玄学……

我从小都听说女生穿黑丝，脚从靴子里拔出来的时候气味很上头。

但是我遇到的妹子哪怕穿了一天的靴子，脚上还是只有淡淡的皮革味道……

不，出明日方舟的角色也没用！

![](./assets/v2-dff84c9559b38dd7660a8260f48308fb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='685'></svg>)

