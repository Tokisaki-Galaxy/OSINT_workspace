---
title: 几个女性能打过一个男性？
url: https://www.zhihu.com/question/42214601/answer/3558542120
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 13:52
modified: 2024-07-11 13:52
upvote_num: 3
comment_num: 0
---

一般男的有脑子是不会琢磨这个问题的。很丢脸的

