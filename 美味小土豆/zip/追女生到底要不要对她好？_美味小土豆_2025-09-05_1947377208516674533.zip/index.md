---
title: 追女生到底要不要对她好？
url: https://www.zhihu.com/question/484523432/answer/1947377208516674533
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 19:15
modified: 2025-09-05 19:15
upvote_num: 5
comment_num: 0
---

你都已经不考虑她是不是喜欢你，就决定单方面追她了。

那可不得使劲舔她，

不跪下来舔，估计你自己都要担心是不是恋爱心法修的不够诚了。

——要是你觉得我说得阴阳怪气，你听的很生气。

那就先想想我说的第一句话

