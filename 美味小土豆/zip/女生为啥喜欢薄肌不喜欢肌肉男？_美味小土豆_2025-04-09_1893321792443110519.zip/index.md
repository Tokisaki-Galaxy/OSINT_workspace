---
title: 女生为啥喜欢薄肌不喜欢肌肉男？
url: https://www.zhihu.com/question/631267982/answer/1893321792443110519
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-09 15:18
modified: 2025-04-09 15:18
upvote_num: 3
comment_num: 0
---

我的女性朋友给我过一个最直观的我能理解的答案。

“身材的话，我喜欢元祖，不喜欢重高达，扎古也不行，扎古丑胖丑胖的，大魔勇士这样的直接ng，丑爆了，明白了没～”

