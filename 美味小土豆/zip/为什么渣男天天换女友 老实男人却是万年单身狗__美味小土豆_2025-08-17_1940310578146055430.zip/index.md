---
title: 为什么渣男天天换女友 老实男人却是万年单身狗?
url: https://www.zhihu.com/question/603322298/answer/1940310578146055430
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 07:14
modified: 2025-08-17 07:14
upvote_num: 18
comment_num: 2
---

"你很珍惜她？你说真正喜欢的人是不会想要伤害她的，所以你不舍得碰她咯？那我不客气啦，你不吃我吃咯"

![](./assets/v2-b3651a18234aad7d39ce918dbdcb1f08_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1216' height='832'></svg>)

