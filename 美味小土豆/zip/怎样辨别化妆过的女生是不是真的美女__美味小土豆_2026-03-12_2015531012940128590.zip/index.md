---
title: 怎样辨别化妆过的女生是不是真的美女?
url: https://www.zhihu.com/question/264524788/answer/2015531012940128590
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-12 20:54
modified: 2026-03-12 20:54
upvote_num: 105
comment_num: 20
---

16岁以下的女生很多都还没学会化妆

好了，我教过了。

