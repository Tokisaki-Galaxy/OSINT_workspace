---
title: 你会光明正大、顶天立地、堂堂正正地把漫画书和《战争与和平》《红楼梦》摆在一个书架上吗？
url: https://www.zhihu.com/question/1956469951415158283/answer/1959738412681630116
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-09 21:54
modified: 2025-10-09 21:54
upvote_num: 5
comment_num: 0
---

我既没有看过战争与和平，也没有看过红楼梦。

我的书架上堂堂正正的放着1/4的兔女郎爱宕和1/48的独角兽高达。

