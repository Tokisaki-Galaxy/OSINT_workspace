---
title: 手机被同学抢走后随意翻看，你们会翻脸吗?
url: https://www.zhihu.com/question/662180070/answer/1947502456599717170
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 03:32
modified: 2025-09-06 03:32
upvote_num: 2
comment_num: 0
---

我绝对会一脚踢过去把他打翻在地方然后把手机捡回来。

我手机里一堆妹子们的涩图……

