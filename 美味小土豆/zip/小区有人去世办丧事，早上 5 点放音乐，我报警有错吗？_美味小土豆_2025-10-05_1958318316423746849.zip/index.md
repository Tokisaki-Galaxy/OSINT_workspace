---
title: 小区有人去世办丧事，早上 5 点放音乐，我报警有错吗？
url: https://www.zhihu.com/question/1892863987181405548/answer/1958318316423746849
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-05 23:51
modified: 2025-10-05 23:51
upvote_num: 16
comment_num: 0
---

你被人家打了警察都未必向着你……

