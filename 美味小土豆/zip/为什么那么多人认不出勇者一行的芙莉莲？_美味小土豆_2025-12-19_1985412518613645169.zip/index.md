---
title: 为什么那么多人认不出勇者一行的芙莉莲？
url: https://www.zhihu.com/question/639592042/answer/1985412518613645169
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 18:13
modified: 2025-12-19 18:13
upvote_num: 13
comment_num: 0
---

![](./assets/v2-194c510a759b1e734a8b2e7e4f4c0dbd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='2048'></svg>)

  


![](./assets/v2-3a492340c0419ba06242c85b7d4a7361_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='2048'></svg>)

  


![](./assets/v2-849475db2b93658c5d36a651e377ea55_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='2048'></svg>)

皇帝陛下真拿个破手机站在你面前要你打钱，估计你也只会打他。

