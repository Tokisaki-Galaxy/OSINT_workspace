---
title: 今年孩子上大一，给准备了八百生活费，不知道够不够啊?
url: https://www.zhihu.com/question/1945127724080402472/answer/1956064449254397942
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 18:35
modified: 2025-09-29 18:35
upvote_num: 8
comment_num: 1
---

一个月八百啊

别以为男孩子就没渠道卖屁股了。

