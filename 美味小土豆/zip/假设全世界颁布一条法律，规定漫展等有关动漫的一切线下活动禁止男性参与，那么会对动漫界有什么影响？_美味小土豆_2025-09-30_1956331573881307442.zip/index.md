---
title: 假设全世界颁布一条法律，规定漫展等有关动漫的一切线下活动禁止男性参与，那么会对动漫界有什么影响？
url: https://www.zhihu.com/question/642851849/answer/1956331573881307442
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 12:16
modified: 2025-09-30 12:16
upvote_num: 33
comment_num: 1
---

coser会自觉聚集到不禁止男性参与的外场。

还会开直播叫人过来。

"妈的全是女人，出个屁的cos呀"

