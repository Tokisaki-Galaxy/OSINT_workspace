---
title: 如何看待特朗普贬低电磁弹射，并宣称动用行政手段废除电磁弹射?
url: https://www.zhihu.com/question/1966558346145411453/answer/1967258410190864587
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-30 15:55
modified: 2025-10-30 15:55
upvote_num: 1
comment_num: 1
---

这波我站人力弹射

![](./assets/v2-cb8e2c0d435307fcb25cd0d89405661c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

