---
title: 如何反驳“生孩子很辛苦，你应该不结婚或不生孩子，而不是用生孩子来索要彩礼”？
url: https://www.zhihu.com/question/1997081926633285477/answer/2009953011640836432
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-25 11:29
modified: 2026-02-25 11:29
upvote_num: 6
comment_num: 0
---

这样堂而皇之自我矮化的话看得真让人心酸

到底是什么出生父母养出来的女孩，才能把自己心甘情愿的扭曲成这样的付费生育机器……还要为付费生育摇旗呐喊。

