---
title: 欲望总是特别强烈，怎么办，老是控制不住自己，怎么办有时候觉得自己容貌丑，想扇自己怎么办？
url: https://www.zhihu.com/question/1950580220185806664/answer/1955548751444807783
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 08:25
modified: 2025-09-28 08:25
upvote_num: 3
comment_num: 1
---

要么……你试试一边撸一边扇自己？

