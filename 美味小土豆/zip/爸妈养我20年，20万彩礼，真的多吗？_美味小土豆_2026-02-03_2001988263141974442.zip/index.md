---
title: 爸妈养我20年，20万彩礼，真的多吗？
url: https://www.zhihu.com/question/1976326364383687228/answer/2001988263141974442
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 11:59
modified: 2026-02-03 11:59
upvote_num: 10
comment_num: 0
---

你把你爸妈形容成龟公老鸨你爸妈知道吗？

