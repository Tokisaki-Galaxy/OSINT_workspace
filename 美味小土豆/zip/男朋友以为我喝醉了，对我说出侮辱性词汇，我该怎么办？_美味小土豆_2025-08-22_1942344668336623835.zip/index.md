---
title: 男朋友以为我喝醉了，对我说出侮辱性词汇，我该怎么办？
url: https://www.zhihu.com/question/613547868/answer/1942344668336623835
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-22 21:57
modified: 2025-08-22 21:58
upvote_num: 1
comment_num: 0
---

想玩dirty talk最好找性癖相同的人。

普通人可能挺敏感这玩意的。

dirty talk不能算日常调情的。

有些是真的照着人格羞辱去的，喜欢这口的会喜欢的不得了。

不喜欢的真的会呼你。

