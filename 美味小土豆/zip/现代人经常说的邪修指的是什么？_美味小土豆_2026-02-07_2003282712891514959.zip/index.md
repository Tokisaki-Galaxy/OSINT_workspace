---
title: 现代人经常说的邪修指的是什么？
url: https://www.zhihu.com/question/1956516426920756642/answer/2003282712891514959
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-07 01:43
modified: 2026-02-07 01:45
upvote_num: 1406
comment_num: 75
---

你只要有过和14岁女朋友交往的经历，就能得到照顾9岁小朋友的经验和耐心。

这个经验确实很邪门，我至今都不敢告诉我妈为什么我这么会照顾小孩。

