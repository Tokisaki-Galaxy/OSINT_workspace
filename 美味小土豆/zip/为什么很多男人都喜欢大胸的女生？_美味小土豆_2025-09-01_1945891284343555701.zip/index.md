---
title: 为什么很多男人都喜欢大胸的女生？
url: https://www.zhihu.com/question/659061728/answer/1945891284343555701
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 16:50
modified: 2025-09-01 16:51
upvote_num: 3
comment_num: 1
---

我交往过d杯jk就会向往g杯御姐，揉过g杯御姐就会热衷找a杯萝莉。

我对我没见过的胸型都会心生出强烈的探究欲。

人怎么能故步自封呢。

