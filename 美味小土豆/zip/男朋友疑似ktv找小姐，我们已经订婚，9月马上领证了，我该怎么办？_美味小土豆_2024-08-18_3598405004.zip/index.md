---
title: 男朋友疑似ktv找小姐，我们已经订婚，9月马上领证了，我该怎么办？
url: https://www.zhihu.com/question/664066672/answer/3598405004
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-18 17:14
modified: 2024-08-18 17:14
upvote_num: 1
comment_num: 0
---

分！他平常连内裤都不会自己洗，你给他当老妈子吗？

