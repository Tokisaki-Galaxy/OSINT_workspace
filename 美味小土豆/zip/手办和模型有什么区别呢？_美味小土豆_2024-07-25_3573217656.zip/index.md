---
title: 手办和模型有什么区别呢？
url: https://www.zhihu.com/question/662205841/answer/3573217656
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-25 15:48
modified: 2024-07-25 15:48
upvote_num: 3
comment_num: 0
---

对新人来说，最简单的区分办法就是

涂好颜色的成品=手办

需要自己剪下来拼装的=模型

你问白模gk算啥？

md你都知道白模gk了你装啥萌新！

