---
title: 为什么男性给女性拍照，女性总在怪男性不会拍，拍的不好，从来不想想是不是自己形象的问题呢？
url: https://www.zhihu.com/question/1944841550455616197/answer/1952065943674029842
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-18 17:46
modified: 2025-09-18 17:46
upvote_num: 147
comment_num: 16
---

我cp很客观的评价过我的摄影技术"你拍照确实很涩，构图很好看。但是你拍糖水片真的好烂……你不管拍谁都能拍出一股援交进行中的氛围"

