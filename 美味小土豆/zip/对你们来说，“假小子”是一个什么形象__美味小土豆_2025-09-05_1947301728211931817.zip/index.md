---
title: 对你们来说，“假小子”是一个什么形象?
url: https://www.zhihu.com/question/589918316/answer/1947301728211931817
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 14:15
modified: 2025-09-05 14:23
upvote_num: 7
comment_num: 0
---

这题我会!

能用图片说明白的问题就不要浪费时间打字了！

![](./assets/v2-a7f9be935463ffb08bba8b33feed2604_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='814' height='1200'></svg>)

  


![](./assets/v2-3f2b68e71f30b9dbb2530d152f45d1dc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-ad26729388f85f1488c27dbe560bf154_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='928'></svg>)

  


![](./assets/v2-a3e64909ef7bf64419efc34387217e83_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='896' height='1152'></svg>)

  


![](./assets/v2-b7b31113294d408bec0a72ab7bf8a5ac_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='1152'></svg>)

  


![](./assets/v2-a6d88ee492d5656a38ead9815c3bae72_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='876'></svg>)

  


![](./assets/v2-646c62930bed55a88077a9bc4e1065f0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-26e5e2935687fd3f459d6d8328ba7948_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-f9fc26842dbb2110c6162764360e0e41_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

