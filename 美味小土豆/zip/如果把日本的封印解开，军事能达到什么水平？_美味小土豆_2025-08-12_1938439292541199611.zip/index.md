---
title: 如果把日本的封印解开，军事能达到什么水平？
url: https://www.zhihu.com/question/527035211/answer/1938439292541199611
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 03:19
modified: 2025-08-12 03:19
upvote_num: 0
comment_num: 1
---

我拿海自的人头赌，他们一定会再造一艘类似"大和号"的过时玩意，可能是武库舰，也可能是载机巡洋舰。总之海自一定会有人下克上的这么干。

输了海自死一半。

