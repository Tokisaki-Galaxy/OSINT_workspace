---
title: 女生到底喜不喜欢肌肉男？
url: https://www.zhihu.com/question/339385551/answer/1940689358207300892
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 08:19
modified: 2025-08-18 08:19
upvote_num: 350
comment_num: 131
---

拿ms举例的话

女生不喜欢这种的

![](./assets/v2-d59212175ce15e201bb2c03b2bdfc972_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='673' height='760'></svg>)

女生喜欢这种的

![](./assets/v2-bf3050a9ebd38bfa1604455cc2f20019_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='855'></svg>)

为什么会有这么奇怪的比喻呢

因为我在做"让没有看过高达的女生对ms做出评价"的游戏时

她们对dom的评价就是——丑，像肌肉男，又壮又油腻。

对了，还有一样待遇的是勇士……

