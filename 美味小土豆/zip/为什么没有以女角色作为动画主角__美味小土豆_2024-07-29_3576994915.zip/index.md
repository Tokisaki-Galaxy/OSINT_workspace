---
title: 为什么没有以女角色作为动画主角?
url: https://www.zhihu.com/question/660625388/answer/3576994915
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-29 11:45
modified: 2024-07-29 11:45
upvote_num: 2
comment_num: 0
---

飞跃巅峰，机动警察，神无月的巫女，舞hime，舞乙hime，魔剑美神，GS美神大作战，圣母在上，美少女战士，魔法骑士，光之美少女系列，花仙子，电磁炮……

太多了

