---
title: 为什么说男性是被社会压抑的对象？
url: https://www.zhihu.com/question/11563673457/answer/1940049376450936978
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 13:56
modified: 2025-08-16 13:56
upvote_num: 1
comment_num: 1
---

有没有发现：

女拳在破坏男性被社会压抑了很久的供养者封印。

