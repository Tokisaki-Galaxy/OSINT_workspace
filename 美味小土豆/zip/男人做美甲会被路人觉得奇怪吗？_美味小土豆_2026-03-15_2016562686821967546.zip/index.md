---
title: 男人做美甲会被路人觉得奇怪吗？
url: https://www.zhihu.com/question/11325797466/answer/2016562686821967546
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-15 17:13
modified: 2026-03-15 17:13
upvote_num: 2
comment_num: 1
---

我会修指甲打磨抛光上油，中二病的时候也会上黑色的指甲油。

但是我不会做美甲，那个真的和我太不搭了。

