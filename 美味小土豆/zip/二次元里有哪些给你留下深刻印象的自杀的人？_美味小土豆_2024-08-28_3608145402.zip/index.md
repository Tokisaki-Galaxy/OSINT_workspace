---
title: 二次元里有哪些给你留下深刻印象的自杀的人？
url: https://www.zhihu.com/question/663073207/answer/3608145402
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-28 01:13
modified: 2024-08-28 01:13
upvote_num: 1
comment_num: 0
---

武藏又死了 

![](./assets/v2-cf3bbc45e31ecfe9d7452b7e94880f6e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-c659e2cd5c424bfed9a62082f9f8c508_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-25cec55c43b5e57e5169f8a43418d7fe_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

