---
title: 女人为什么都想要找个180cm的男朋友？
url: https://www.zhihu.com/question/567440481/answer/1982833203057296051
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-12 15:24
modified: 2025-12-12 15:24
upvote_num: 15
comment_num: 4
---

你们狭隘了。

女生找男朋友爱找180的

男生交朋友也爱交180的

男娘找cos搭子同样爱找180的

