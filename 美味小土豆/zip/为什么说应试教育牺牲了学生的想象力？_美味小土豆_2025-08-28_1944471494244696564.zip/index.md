---
title: 为什么说应试教育牺牲了学生的想象力？
url: https://www.zhihu.com/question/305700381/answer/1944471494244696564
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-28 18:48
modified: 2025-08-28 18:48
upvote_num: 3
comment_num: 0
---

但是大部分人的想象力也只是"凭什么你说的就是对的啊？"的毫无意义的东西啊……

