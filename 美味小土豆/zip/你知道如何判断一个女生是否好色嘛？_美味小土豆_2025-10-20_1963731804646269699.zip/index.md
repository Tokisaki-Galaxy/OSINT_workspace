---
title: 你知道如何判断一个女生是否好色嘛？
url: https://www.zhihu.com/question/1945759695617910675/answer/1963731804646269699
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-20 22:22
modified: 2025-10-20 22:22
upvote_num: 9
comment_num: 1
---

热衷于找我做爱。

因为没有瘾的也不会成天勾搭我这种人形幻龙

她总不能是图我又穷又没脑子还说话跳脱的性格吧，或者是真的想认真和我讨论平成老动画?

别开玩笑了。

