---
title: 为什么人们喜欢把军舰娘化，而很少把飞机/坦克娘化？
url: https://www.zhihu.com/question/366144977/answer/1989653712990410727
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-31 11:06
modified: 2025-12-31 11:06
upvote_num: 83
comment_num: 15
---

军武娘这玩意的早期拟人化对象就是战斗机啊。

当年还吐槽过"军舰这么大的东西要怎么拟人化啊！"

答主……你是不知道强袭魔女吗？

![](./assets/v2-9744875a14f8d5c88ddf6dee243a26e0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='853'></svg>)

