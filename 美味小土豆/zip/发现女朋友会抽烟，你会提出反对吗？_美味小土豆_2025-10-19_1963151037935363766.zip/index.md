---
title: 发现女朋友会抽烟，你会提出反对吗？
url: https://www.zhihu.com/question/651874618/answer/1963151037935363766
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-19 07:54
modified: 2025-10-19 07:54
upvote_num: 6
comment_num: 1
---

我真的好喜欢看梳着双马尾的不良jk什么都不穿的裹着白浴巾，用涂着黑色指甲油的纤细手指夹着一支事后烟的小模样。

![](./assets/v2-0060d1f4d759f9ccdb58779d178d7a7c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

