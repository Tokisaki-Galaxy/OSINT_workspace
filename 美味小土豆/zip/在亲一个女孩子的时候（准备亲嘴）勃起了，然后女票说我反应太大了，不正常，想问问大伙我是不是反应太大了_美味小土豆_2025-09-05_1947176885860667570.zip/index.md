---
title: 在亲一个女孩子的时候（准备亲嘴）勃起了，然后女票说我反应太大了，不正常，想问问大伙我是不是反应太大了？
url: https://www.zhihu.com/question/35334570/answer/1947176885860667570
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 05:59
modified: 2025-09-05 05:59
upvote_num: 3
comment_num: 0
---

太奇怪了

我和我cp接吻的时候如果我没硬起来她就会开玩笑说"你是不是不爱我了"

