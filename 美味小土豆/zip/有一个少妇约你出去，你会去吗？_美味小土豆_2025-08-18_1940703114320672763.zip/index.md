---
title: 有一个少妇约你出去，你会去吗？
url: https://www.zhihu.com/question/667629971/answer/1940703114320672763
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 09:14
modified: 2025-08-18 09:14
upvote_num: 6
comment_num: 0
---

我大学的时候别称"对少妇专用强袭型钢加农"

反正大我十岁的姐姐也不会指望着招我当老公。

