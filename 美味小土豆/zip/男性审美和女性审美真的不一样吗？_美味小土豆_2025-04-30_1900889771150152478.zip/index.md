---
title: 男性审美和女性审美真的不一样吗？
url: https://www.zhihu.com/question/581692774/answer/1900889771150152478
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-30 12:30
modified: 2025-04-30 12:30
upvote_num: 0
comment_num: 1
---

女性画师，无论笔下角色画得有多涩，大多都很抵触大rutou。

而男性画师即使把rutou画的比手指还大都不会觉得难受

