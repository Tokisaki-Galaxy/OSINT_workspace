---
title: 你看过哪些让你很感动的本子呢？
url: https://www.zhihu.com/question/277270084/answer/3613741384
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-02 19:45
modified: 2024-09-02 19:58
upvote_num: 8
comment_num: 4
---

![](./assets/v2-2ed98e84fbe2c97971f9167e8901c5fc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1198' height='1924'></svg>)

因为真的有人这样对我说过——“今天是你生日，一直以来辛苦啦，所以今天特地换上了你最喜欢的jk制服”

所以看到有人真的画出来了同样的场景还真的蛮感动的。

![](./assets/v2-5ab42c99e06457944d20cb978f7af16e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1198' height='1925'></svg>)

这一幕莫名的就很戳我

  


还有这两本，描写地雷系的细节还挺戳我的，那种在微淡的绝望中互相救赎的剧情，很写实。

![](./assets/v2-fcfc946510624a0c72bd04e74c8f5ab9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1091'></svg>)

  


![](./assets/v2-5dfe19ba69961ce7770a53cd1e2b165e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1091'></svg>)

  


![](./assets/v2-bdc8676318ad498125babdb2f8b17109_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1091'></svg>)

