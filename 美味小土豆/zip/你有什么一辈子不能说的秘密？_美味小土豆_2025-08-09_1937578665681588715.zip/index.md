---
title: 你有什么一辈子不能说的秘密？
url: https://www.zhihu.com/question/654420664/answer/1937578665681588715
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-09 18:19
modified: 2025-08-09 18:19
upvote_num: 0
comment_num: 1
---

我有些朋友知道我做过男喘

但是他们都不知道我还当过女喘

我的伪声骗过了所有人~

![](./assets/v2-e5d830047e9f3b2fdf04c53bdd8e514f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

