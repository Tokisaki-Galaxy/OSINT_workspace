---
title: 为什么要远离社会底层？
url: https://www.zhihu.com/question/853504106/answer/1912758046440026321
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-02 06:30
modified: 2025-06-02 06:30
upvote_num: 21
comment_num: 0
---

这个世界是靠社会底层运行起来的。很多工作都是这个阶层来完成的

能在社会底层里混得开，很多事情办起来会很轻松。

