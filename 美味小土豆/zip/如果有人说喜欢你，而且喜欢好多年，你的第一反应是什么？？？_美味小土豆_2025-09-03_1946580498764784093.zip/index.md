---
title: 如果有人说喜欢你，而且喜欢好多年，你的第一反应是什么？？？
url: https://www.zhihu.com/question/621492441/answer/1946580498764784093
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 14:29
modified: 2025-09-03 14:29
upvote_num: 4
comment_num: 0
---

我的"她喜欢我"雷达巨敏感

我身边喜欢我的女生只要条件ok的我都吃掉了。

一个人如果说喜欢了我很多年但是我不知道

=你并不喜欢我

