---
title: 为什么男生女装大多扮JK，而女生男装大多扮成男？
url: https://www.zhihu.com/question/1951632686411159103/answer/1954151773859219157
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-24 11:54
modified: 2025-09-24 11:54
upvote_num: 59
comment_num: 0
---

对于不擅长穿搭的男人来说

jk制服最不容易翻车，哪怕穿得很烂很粗糙也会有男人觉得"哦，还可以"

