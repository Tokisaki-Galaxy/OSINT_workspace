---
title: 为什么二次元手游里全是旗袍而非汉服？
url: https://www.zhihu.com/question/586187456/answer/1942443477519538160
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 04:30
modified: 2025-08-23 04:30
upvote_num: 102
comment_num: 19
---

二游的旗袍真的是披两门帘子就出来卖了。

窑姐感巨强，谁能不喜欢。

![](./assets/v2-783069759809ab1ba38fee58dad9f5b7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='500'></svg>)

  


![](./assets/v2-e6b8f08936bfcb3d405cbafba8f345a7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='501' height='579'></svg>)

  


![](./assets/v2-5a7d467b15b440d74462ebc10b99d21d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='652' height='645'></svg>)

  


![](./assets/v2-c7899cc8e7a05f72a2db67be507aa858_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='799' height='412'></svg>)

  


![](./assets/v2-216bd055807ea0c13b4b9d23e3848c45_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='412'></svg>)

  


![](./assets/v2-c31b0c0fe7bdfbfccca0bf3967422de9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='821' height='788'></svg>)

  


![](./assets/v2-6e6cd83eaac3e30da390378df927ec9a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='929'></svg>)

  


![](./assets/v2-e266c9360c9d4c67a13a2e593c36414b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='821' height='720'></svg>)

  


![](./assets/v2-3b0729913d517a82887fa23760de2c42_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1200'></svg>)

