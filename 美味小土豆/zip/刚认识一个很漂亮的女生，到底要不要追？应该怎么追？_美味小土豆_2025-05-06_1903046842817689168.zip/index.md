---
title: 刚认识一个很漂亮的女生，到底要不要追？应该怎么追？
url: https://www.zhihu.com/question/1888335644645898226/answer/1903046842817689168
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-06 11:22
modified: 2025-05-06 11:22
upvote_num: 2
comment_num: 0
---

你追100个好看的异性哪怕都失败了，至少还会留下一个“看女人品味很不错”的名声

