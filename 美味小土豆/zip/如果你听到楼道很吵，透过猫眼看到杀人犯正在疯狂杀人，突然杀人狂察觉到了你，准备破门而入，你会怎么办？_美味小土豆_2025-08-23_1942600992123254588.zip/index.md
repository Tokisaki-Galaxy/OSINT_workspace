---
title: 如果你听到楼道很吵，透过猫眼看到杀人犯正在疯狂杀人，突然杀人狂察觉到了你，准备破门而入，你会怎么办？
url: https://www.zhihu.com/question/547488977/answer/1942600992123254588
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 14:56
modified: 2025-08-23 14:56
upvote_num: 1
comment_num: 0
---

我先问清楚……

这算互殴还是防卫过度?

我会不会被要求赔他2000块钱?和接头的医药费?

我会不会因为持有非法管制刀具而被警察带走?

