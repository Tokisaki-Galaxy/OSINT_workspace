---
title: 为什么泰国基本上接近热带，一些泰国人看上去还是白白嫩嫩的呢？
url: https://www.zhihu.com/question/507933351/answer/1939239174596178442
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 08:17
modified: 2025-08-14 08:18
upvote_num: 1
comment_num: 0
---

你但凡去去p站上搜一下thai girl 都不会有这个结论。

泰国人是真的黑……

黑，龅牙，柴

好看的真没几个

