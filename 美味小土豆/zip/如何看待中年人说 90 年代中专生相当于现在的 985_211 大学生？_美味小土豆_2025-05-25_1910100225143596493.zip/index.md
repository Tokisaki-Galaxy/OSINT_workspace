---
title: 如何看待中年人说 90 年代中专生相当于现在的 985/211 大学生？
url: https://www.zhihu.com/question/8614495900/answer/1910100225143596493
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-25 22:29
modified: 2025-05-25 22:29
upvote_num: 1
comment_num: 0
---

不好好读书将来只能上中专这话90年代已经是普遍认知了啊。

80后还没开始死绝呢就开始吹中专了？

