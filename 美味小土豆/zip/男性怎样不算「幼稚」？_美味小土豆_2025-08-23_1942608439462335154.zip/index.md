---
title: 男性怎样不算「幼稚」？
url: https://www.zhihu.com/question/45730566/answer/1942608439462335154
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 15:25
modified: 2025-08-23 15:25
upvote_num: 2
comment_num: 0
---

逃避责任

双标

自私

唯利是图

爱说教

迷信人脉

推崇酒桌文化

欺软怕硬

窝里横

