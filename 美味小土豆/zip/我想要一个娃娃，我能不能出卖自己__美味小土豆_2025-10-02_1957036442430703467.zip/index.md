---
title: 我想要一个娃娃，我能不能出卖自己?
url: https://www.zhihu.com/question/1956887940371296500/answer/1957036442430703467
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 10:57
modified: 2025-10-02 10:57
upvote_num: 4
comment_num: 3
---

何必要出卖自己

区区800，你卖腿照都能赚到啊……

