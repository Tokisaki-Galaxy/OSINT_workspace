---
title: 尊重女性是加分项吗？
url: https://www.zhihu.com/question/590422478/answer/1993964587192692743
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-12 08:36
modified: 2026-01-12 08:36
upvote_num: 42
comment_num: 2
---

讨人喜欢才是加分项。

因为讨人喜欢，所以她们反而不太在乎你是不是尊重她们。

这时候如果你能尊重一下对方，那对她来说才是莫大的惊喜。

