---
title: 商场里的COSER真的大多是学生么？
url: https://www.zhihu.com/question/1932734592902730786/answer/1987473120253211499
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-25 10:41
modified: 2025-12-25 10:41
upvote_num: 112
comment_num: 2
---

商场里和漫展上的大部分都是学生。

高中生大学生居多，初中生次之，最少的反而是上班族。

这两地方的未成年含量都巨高。

