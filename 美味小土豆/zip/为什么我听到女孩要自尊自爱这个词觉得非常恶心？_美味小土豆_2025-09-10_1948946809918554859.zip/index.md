---
title: 为什么我听到女孩要自尊自爱这个词觉得非常恶心？
url: https://www.zhihu.com/question/1912478251575653367/answer/1948946809918554859
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 03:12
modified: 2025-09-10 03:12
upvote_num: 4
comment_num: 0
---

"那当然啦，你那么可爱的一只小碧池，怎么能被形容的这么恶心呢~当然没有，最喜欢你现在这幅样子啦，乖，张嘴，把药吃掉"

![](./assets/v2-69ed2012a58f67d1f400bf33a87f8a32_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='603'></svg>)

