---
title: 「老穷风」接替「老钱风」火了，精髓在哪？为什么现在年轻人都不「装」了？
url: https://www.zhihu.com/question/1977705314691281525/answer/1978927962540770677
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 20:46
modified: 2025-12-01 20:46
upvote_num: 240
comment_num: 4
---

我爸十五年前就教育我

要学会理直气壮的说"没钱"。

这个世界上最牛逼的一句话就是"我没钱"

它可以帮你解决很多麻烦。

还能帮你看清楚这个世界。

