---
title: 为什么高达叫高达 而扎古就不算高达？?
url: https://www.zhihu.com/question/381096153/answer/3577783318
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-30 06:29
modified: 2024-07-30 06:29
upvote_num: 5
comment_num: 0
---

高达和扎古都是ms，高达是gundam type的ms。扎古是Zack type的ms。

扎古不是高达type，老虎不是吉姆type，钢加农不是勇士type

