---
title: 上海人到底怎么看待外地的女朋友的？
url: https://www.zhihu.com/question/371218434/answer/1976361545433883459
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-24 18:48
modified: 2025-11-24 18:48
upvote_num: 8
comment_num: 4
---

我亲爱的310109哟：

310101的弄堂公主和330481的二代大小姐，你选哪个？

