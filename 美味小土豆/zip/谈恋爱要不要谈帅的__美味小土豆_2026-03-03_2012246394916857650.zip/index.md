---
title: 谈恋爱要不要谈帅的?
url: https://www.zhihu.com/question/1418035649/answer/2012246394916857650
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-03 19:22
modified: 2026-03-03 19:22
upvote_num: 8
comment_num: 0
---

谈恋爱要不要谈漂亮的？

一样的，当然要选帅的漂亮的啊！

等到吵架的时候你就知道了，谈个帅的漂亮的，起码你们在气呼呼的上下打量对方的时候，还能养眼一些。

而且恋爱对象颜值高，出门在外还能白嫖别人的善意，winwin。

