---
title: 如何看待当前“性萧条”的现象？
url: https://www.zhihu.com/question/1917228395672080971/answer/2015436615208694611
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-12 14:38
modified: 2026-03-12 14:38
upvote_num: 8
comment_num: 2
---

你现在在知乎上起个女号，问jk女友要几张腿照，随便在哪个身材贴和大叔vs小姑娘的话题下回几贴发点腿照丝袜照。

哪怕你只有零个关注，都能收到十几二十条私信。

