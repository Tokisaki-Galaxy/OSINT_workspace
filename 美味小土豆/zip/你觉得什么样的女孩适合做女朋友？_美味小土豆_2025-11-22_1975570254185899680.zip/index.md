---
title: 你觉得什么样的女孩适合做女朋友？
url: https://www.zhihu.com/question/1967599510923515181/answer/1975570254185899680
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-22 14:24
modified: 2025-11-22 14:24
upvote_num: 12
comment_num: 1
---

这个问题问我就相当没有意义了。

我第一喜欢的是私生活很混乱的地下小偶像。

其次是爸爸活人数超过十人以上的黑皮援交美少女。

不是能接受，而是很喜欢。

我是个巨爱公车私用的人。

