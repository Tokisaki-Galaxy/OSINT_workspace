---
title: 男生真的会介意女生的身高吗？
url: https://www.zhihu.com/question/1915898728906219636/answer/1939285580346265908
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 11:21
modified: 2025-08-14 11:21
upvote_num: 4
comment_num: 0
---

我完全不介意，我从妃咲到八尺都ok

![](./assets/v2-27b79c5568a6963a4f046fd93b5d6ebe_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-8c3ddc226860373aea92be2834fe4137_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1200'></svg>)

