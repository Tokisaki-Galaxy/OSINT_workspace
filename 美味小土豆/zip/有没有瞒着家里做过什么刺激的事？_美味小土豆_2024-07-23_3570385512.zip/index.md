---
title: 有没有瞒着家里做过什么刺激的事？
url: https://www.zhihu.com/question/660391179/answer/3570385512
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-23 03:38
modified: 2024-07-23 03:38
upvote_num: 2
comment_num: 0
---

瞒着我妈把她买的两只做晚饭的龙虾偷掉一只做改造实验。

