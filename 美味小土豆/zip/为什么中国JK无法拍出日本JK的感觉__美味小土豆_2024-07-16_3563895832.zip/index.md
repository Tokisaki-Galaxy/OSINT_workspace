---
title: 为什么中国JK无法拍出日本JK的感觉?
url: https://www.zhihu.com/question/469654051/answer/3563895832
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-16 18:23
modified: 2024-07-16 18:23
upvote_num: 261
comment_num: 10
---

因为中国jk有中国jk自有的感觉啊

我朋友说过“最背德的事情不是让现役jk穿日式jk制服，而是让她穿着她自己学校的校服，你想象一下她三小时前还穿着这身校服规规矩矩的上课学习，和班级憧憬她的男生聊天嬉闹。而现在她就穿着这身校服，任你采撷”

听他描述我真是血压高来头又痛。

