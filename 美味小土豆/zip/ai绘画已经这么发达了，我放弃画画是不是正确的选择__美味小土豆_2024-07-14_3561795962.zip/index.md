---
title: ai绘画已经这么发达了，我放弃画画是不是正确的选择?
url: https://www.zhihu.com/question/639932812/answer/3561795962
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 19:48
modified: 2024-07-14 19:48
upvote_num: 1
comment_num: 0
---

画画画下去，总有出头的机会。

ai画画，这个门槛低到沼泽地的内卷泥潭里能有什么出头的机会呢？

