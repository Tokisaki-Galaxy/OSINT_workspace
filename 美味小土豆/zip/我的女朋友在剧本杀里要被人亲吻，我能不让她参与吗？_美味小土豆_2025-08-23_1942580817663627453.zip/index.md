---
title: 我的女朋友在剧本杀里要被人亲吻，我能不让她参与吗？
url: https://www.zhihu.com/question/568332577/answer/1942580817663627453
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 13:35
modified: 2025-08-23 13:35
upvote_num: 6
comment_num: 0
---

当然不能。她是拥有自主意识的独立个体 你无权阻止她做任何她想做的事情。

但是你可以换一个女朋友呀

