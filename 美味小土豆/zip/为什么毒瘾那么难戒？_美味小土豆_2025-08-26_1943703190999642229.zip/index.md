---
title: 为什么毒瘾那么难戒？
url: https://www.zhihu.com/question/19915870/answer/1943703190999642229
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-26 15:55
modified: 2025-08-26 15:55
upvote_num: 3
comment_num: 0
---

我cp每次说禁欲一周就给我神秘奖励

结果每次我都做不到然后骗她

我戒这个都戒不掉……

