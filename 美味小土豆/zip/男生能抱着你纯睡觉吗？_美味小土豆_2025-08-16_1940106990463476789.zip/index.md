---
title: 男生能抱着你纯睡觉吗？
url: https://www.zhihu.com/question/441380836/answer/1940106990463476789
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 17:45
modified: 2025-08-16 17:47
upvote_num: 27
comment_num: 1
---

不能。

我已经有肌肉习惯了，抱着就会往奈子那边揉，真的很顺手……

你不舍得咯?

那我开动咯~

