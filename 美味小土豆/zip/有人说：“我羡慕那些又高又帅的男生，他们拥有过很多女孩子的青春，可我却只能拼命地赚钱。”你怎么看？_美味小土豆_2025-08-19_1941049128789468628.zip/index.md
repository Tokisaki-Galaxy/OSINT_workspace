---
title: 有人说：“我羡慕那些又高又帅的男生，他们拥有过很多女孩子的青春，可我却只能拼命地赚钱。”你怎么看？
url: https://www.zhihu.com/question/443354148/answer/1941049128789468628
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 08:09
modified: 2025-08-19 08:09
upvote_num: 4
comment_num: 1
---

所以我一直说

十六那年的夏天一定要和女朋友去海滩来一场轰轰烈烈的恋爱

一起打西瓜

在海边手牵手散步

追逐，嬉笑打闹

在岩石后面热吻

玩一场沙滩排球

一起参加一次漫展

让她出好看的cos,沐浴在众人的灯光下，最后在大家羡慕的目光中扑到你的怀里。

这样会让你长大以后不会在偶尔的一个深夜里翻来覆去的睡不着，去胡思乱想"我的青春是不是一无所有"。

![](./assets/v2-c2a35cb546cb6dc80f7c76c1c87468ad_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

