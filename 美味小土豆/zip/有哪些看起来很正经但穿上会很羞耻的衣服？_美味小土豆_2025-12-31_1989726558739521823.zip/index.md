---
title: 有哪些看起来很正经但穿上会很羞耻的衣服？
url: https://www.zhihu.com/question/41801510/answer/1989726558739521823
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-31 15:56
modified: 2025-12-31 15:59
upvote_num: 12
comment_num: 5
---

![](./assets/v2-1fc1588f9f19ce5034582edaa9a3455c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2730'></svg>)

假如你带着一个29岁的娃娃脸御姐去开房的时候，唰的掏出这套衣服

她一定会红着脸骂你变态！

