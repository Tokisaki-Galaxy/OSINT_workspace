---
title: 如何看待相亲女“我慢热，给你个机会请我吃饭”？
url: https://www.zhihu.com/question/660016176/answer/3565663005
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-18 11:49
modified: 2025-09-19 09:00
upvote_num: 14
comment_num: 0
---

所以我真的建议学生时代应该认真谈一下恋爱

哪怕最后分手了，起码你知道女孩子真诚热烈的爱恋是什么样子的。

而不是在长大以后被这种"我慢热"的狗屁话给骗到。

![](./assets/v2-a1a8a12cfadf86a8e2099ff049b3d5c7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1032' height='901'></svg>)

