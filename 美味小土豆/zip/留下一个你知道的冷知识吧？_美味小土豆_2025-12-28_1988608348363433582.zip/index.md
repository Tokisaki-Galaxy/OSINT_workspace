---
title: 留下一个你知道的冷知识吧？
url: https://www.zhihu.com/question/577734695/answer/1988608348363433582
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-28 13:52
modified: 2025-12-28 13:52
upvote_num: 4
comment_num: 0
---

人类是左右合的，而且人类还有合模线

