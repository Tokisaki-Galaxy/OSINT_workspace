---
title: 假如一个霸凌你的同学然后她家里出事情了你会选择帮助吗?
url: https://www.zhihu.com/question/1991243025981129714/answer/2010450954663777917
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-26 20:27
modified: 2026-02-26 20:27
upvote_num: 6
comment_num: 0
---

你要那么犯贱，以后它再欺负你，可就真的没人帮你了。

