---
title: 女生什么状态才体现出她已经爱上你了？
url: https://www.zhihu.com/question/29872891/answer/1937100320594453278
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-08 10:38
modified: 2025-08-18 12:42
upvote_num: 74
comment_num: 10
---

这样

![](./assets/v2-78fe15e85f701b74c6eec53d169da427_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='1000'></svg>)

