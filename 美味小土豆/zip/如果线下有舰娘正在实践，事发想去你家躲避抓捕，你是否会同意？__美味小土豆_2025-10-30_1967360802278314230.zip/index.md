---
title: 如果线下有舰娘正在实践，事发想去你家躲避抓捕，你是否会同意？?
url: https://www.zhihu.com/question/1962609219523023301/answer/1967360802278314230
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-30 22:42
modified: 2025-10-30 22:42
upvote_num: 6
comment_num: 2
---

不了不了，我这种把航空母舰和战列巡洋舰都🌿怀孕过的屑提督就不要再祸害新船了……

万一让驱逐舰怀孕了可是会被宪兵队抓起来的

![](./assets/v2-fe78313c095edf9b739dc434e21734bf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='515' height='1005'></svg>)

