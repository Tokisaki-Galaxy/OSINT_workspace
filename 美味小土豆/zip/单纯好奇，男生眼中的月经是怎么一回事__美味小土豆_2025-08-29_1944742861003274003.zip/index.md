---
title: 单纯好奇，男生眼中的月经是怎么一回事?
url: https://www.zhihu.com/question/554195885/answer/1944742861003274003
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-29 12:47
modified: 2025-08-29 12:47
upvote_num: 9
comment_num: 0
---

"哈哈哈，你过两天不能吃冰激凌了"

"卫生巾快不够咯，我下午再去买一包，否则你晚上又要叫了"

"你要不要热水袋？"

"你躺着吧，有事情叫我"

"还没结束呢，不要吃冰激凌"

"我把新的床单换好了，旧的我洗掉了"

