---
title: 穷女孩只能找到穷男孩怎么办？
url: https://www.zhihu.com/question/656571531/answer/3582308585
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 广东
created: 2024-08-03 08:45
modified: 2024-08-03 08:45
upvote_num: 10
comment_num: 0
---

穷男孩也有把钱花在自己身上的权利……他们不是任何人的“退路”

