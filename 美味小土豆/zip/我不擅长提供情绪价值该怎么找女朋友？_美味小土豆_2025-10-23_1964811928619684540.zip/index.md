---
title: 我不擅长提供情绪价值该怎么找女朋友？
url: https://www.zhihu.com/question/1943619466165461947/answer/1964811928619684540
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-23 21:54
modified: 2025-10-23 21:54
upvote_num: 48
comment_num: 0
---

这逼玩意压根就不是提供出来的。别胡思乱想了我的朋友。

你需要做的是找到一个喜欢你的姑娘，那你就是她的情绪价值。

