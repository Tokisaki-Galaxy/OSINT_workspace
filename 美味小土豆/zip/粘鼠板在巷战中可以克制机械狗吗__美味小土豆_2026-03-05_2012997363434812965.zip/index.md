---
title: 粘鼠板在巷战中可以克制机械狗吗?
url: https://www.zhihu.com/question/4463057766/answer/2012997363434812965
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-05 21:06
modified: 2026-03-05 21:06
upvote_num: 1
comment_num: 0
---

对付机械狗，只要研发相应的电战机械鹰不就行了。

