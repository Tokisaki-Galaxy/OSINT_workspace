---
title: 男生最不能理解女生的一些行为是什么？
url: https://www.zhihu.com/question/280152008/answer/1957370339198742654
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-03 09:04
modified: 2025-10-03 09:04
upvote_num: 31
comment_num: 3
---

因为从来没想过结婚，也基本不关心别人的将来。

我居然可以理解女生绝大部分的行为。

