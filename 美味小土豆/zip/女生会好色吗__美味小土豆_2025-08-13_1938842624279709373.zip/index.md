---
title: 女生会好色吗?
url: https://www.zhihu.com/question/659373626/answer/1938842624279709373
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 06:01
modified: 2025-08-13 06:01
upvote_num: 1
comment_num: 0
---

有些女生。

表面上看起来可可爱爱文文静静的。

等到哪天她半夜一脸羞涩的把你骗进酒店，啪嗒一下关了灯。一下把你推到在床边爬上来

你会惊恐的发现，她其实是只小号轰龙

![](./assets/v2-ac2c9dea91ad8a7a7c49d0237d0c78db_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1032' height='940'></svg>)

