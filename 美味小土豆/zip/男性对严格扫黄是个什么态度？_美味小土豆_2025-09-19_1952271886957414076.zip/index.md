---
title: 男性对严格扫黄是个什么态度？
url: https://www.zhihu.com/question/663870127/answer/1952271886957414076
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-19 07:24
modified: 2025-09-19 07:24
upvote_num: 9
comment_num: 0
---

越严越好

不是我道德要求高

我就爱看乐子

