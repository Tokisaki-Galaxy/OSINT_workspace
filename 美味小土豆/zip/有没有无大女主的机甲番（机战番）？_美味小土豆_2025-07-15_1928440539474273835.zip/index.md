---
title: 有没有无大女主的机甲番（机战番）？
url: https://www.zhihu.com/question/662389873/answer/1928440539474273835
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-15 13:07
modified: 2025-07-15 13:10
upvote_num: 3
comment_num: 0
---

高达前哨站，这小说甚至没有人类女主角

盖塔系列（真vs neo，新，世末）

魔神凯撒死斗暗黑大将军

大空魔龙

电童

超重神两部（这片很神奇，感情戏不多但是巨卖肉）

  


魔神z，真魔神冲击z篇

