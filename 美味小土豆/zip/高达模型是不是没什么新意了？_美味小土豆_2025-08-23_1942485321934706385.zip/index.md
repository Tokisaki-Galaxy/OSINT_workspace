---
title: 高达模型是不是没什么新意了？
url: https://www.zhihu.com/question/513695925/answer/1942485321934706385
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 07:16
modified: 2025-08-23 07:16
upvote_num: 1
comment_num: 0
---

感谢gqxuuuuuc，起码设计上有新的思路了

