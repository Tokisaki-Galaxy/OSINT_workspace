---
title: 有性瘾女朋友每天都要很多遍要不要分手?
url: https://www.zhihu.com/question/620729078/answer/1932422426488211295
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-26 12:50
modified: 2025-07-26 12:50
upvote_num: 4
comment_num: 1
---

一天5次，持续两年，也能喂饱了。

现在我已经能嘲笑她"少女你体力不行呀"

