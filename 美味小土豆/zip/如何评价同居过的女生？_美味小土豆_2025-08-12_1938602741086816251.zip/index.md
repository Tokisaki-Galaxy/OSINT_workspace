---
title: 如何评价同居过的女生？
url: https://www.zhihu.com/question/1899458427232695967/answer/1938602741086816251
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 14:08
modified: 2025-08-12 14:08
upvote_num: 1
comment_num: 1
---

我甚至愿意比击坠数~这些都不是问题

