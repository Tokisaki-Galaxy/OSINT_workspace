---
title: 为什么性可以给人带来快乐？
url: https://www.zhihu.com/question/454110445/answer/1955594766516459282
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 11:28
modified: 2025-09-28 13:07
upvote_num: 12
comment_num: 8
---

我曾经也以为性让人快乐的根源就是它的本身

——但自从我发现，我快乐的来源是把对方抱在腿上和她接吻。

——原来我只是一个沉迷于被萝莉妈妈宠溺的变态罢了。

![](./assets/v2-70142cf9a44223178d153b03da108b87_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1728' height='1280'></svg>)

