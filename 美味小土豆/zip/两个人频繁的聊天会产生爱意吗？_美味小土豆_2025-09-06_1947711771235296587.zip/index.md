---
title: 两个人频繁的聊天会产生爱意吗？
url: https://www.zhihu.com/question/646656320/answer/1947711771235296587
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 17:24
modified: 2025-09-06 17:24
upvote_num: 16
comment_num: 0
---

你们都频繁聊天了也没想着约出来见一面?面都不见还在想会不会有爱意？这对吗？

