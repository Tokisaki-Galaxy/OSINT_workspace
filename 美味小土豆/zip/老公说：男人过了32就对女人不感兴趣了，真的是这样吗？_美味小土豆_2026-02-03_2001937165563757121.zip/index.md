---
title: 老公说：男人过了32就对女人不感兴趣了，真的是这样吗？
url: https://www.zhihu.com/question/657703963/answer/2001937165563757121
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 08:36
modified: 2026-02-03 08:36
upvote_num: 6
comment_num: 4
---

听他放屁，你给他换个16岁的美少女你就知道他感不感兴趣了。

