---
title: 作为一名男性，你最不理解其他男性的什么行为?
url: https://www.zhihu.com/question/617212165/answer/3565663227
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-18 11:49
modified: 2024-07-18 11:49
upvote_num: 28
comment_num: 10
---

不能理解为什么有的男性认为男人不应该帮男人说话而是要反思自己为什么要压迫女性，还会跑到女性那边说“男人都不是好东西”。

相当的莫名其妙

