---
title: 不放水、认真打的话，一个男人能同时打得过几个女人？
url: https://www.zhihu.com/question/29856240/answer/3544111682
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-06-27 17:54
modified: 2024-06-27 17:54
upvote_num: 0
comment_num: 0
---

放水的话是三个，初中的时候和女同学四人组玩闹，地面技我能压制她们三个人。不放水的话从来没有考虑过这个可能性，不管如何下场一定是极其悲惨的

