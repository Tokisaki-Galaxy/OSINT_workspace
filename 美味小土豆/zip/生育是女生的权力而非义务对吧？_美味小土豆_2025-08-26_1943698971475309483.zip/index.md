---
title: 生育是女生的权力而非义务对吧？
url: https://www.zhihu.com/question/589742174/answer/1943698971475309483
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-26 15:39
modified: 2025-08-26 15:39
upvote_num: 2
comment_num: 0
---

真希望题主能成立党派，切实的鼓励所有女性拒绝生育。

我真的好想看乐子

