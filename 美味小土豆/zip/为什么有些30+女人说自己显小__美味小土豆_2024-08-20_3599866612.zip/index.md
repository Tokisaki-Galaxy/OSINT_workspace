---
title: 为什么有些30+女人说自己显小?
url: https://www.zhihu.com/question/491665644/answer/3599866612
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-20 02:37
modified: 2024-08-20 02:37
upvote_num: 1
comment_num: 1
---

也许我分不清15和17，但是我一定分得清18和30

