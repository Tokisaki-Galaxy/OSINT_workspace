---
title: 为什么现在有这么多人骂二次元？
url: https://www.zhihu.com/question/286194655/answer/1937820562039747770
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 10:20
modified: 2025-08-10 10:20
upvote_num: 8
comment_num: 0
---

现在骂的已经少多啦

我初中的时候谈恋爱还是要努力隐藏二次元属性的。

等到大学的时候已经是可以肆意散发二次元属性还能被称为潮哥了。

现在甚至变成了"咦?你还懂这个呀，有趣的人类。"

这个世界变化太快了。

