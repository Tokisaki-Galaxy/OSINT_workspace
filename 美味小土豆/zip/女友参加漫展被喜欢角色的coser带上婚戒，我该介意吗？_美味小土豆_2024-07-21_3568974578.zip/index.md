---
title: 女友参加漫展被喜欢角色的coser带上婚戒，我该介意吗？
url: https://www.zhihu.com/question/662189477/answer/3568974578
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 19:05
modified: 2024-07-21 19:05
upvote_num: 140
comment_num: 4
---

你女朋友好看吗？好看的话让她出cos和那个男的组cp，然后展结束你可以一边和女朋友doi一边看她的cp问她"你在干嘛呀？今天好多人拍我们照片呀，你今天打扮的好漂亮呀”

让他变成你们play的一环。

