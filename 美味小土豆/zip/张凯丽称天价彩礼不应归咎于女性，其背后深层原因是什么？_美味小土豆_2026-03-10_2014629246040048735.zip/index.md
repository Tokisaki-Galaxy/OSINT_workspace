---
title: 张凯丽称天价彩礼不应归咎于女性，其背后深层原因是什么？
url: https://www.zhihu.com/question/2014378032790533690/answer/2014629246040048735
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-10 09:10
modified: 2026-03-10 09:11
upvote_num: 91
comment_num: 1
---

这个破钱就一定要给吗？这个逼婚就一定要结吗？这个耀祖就非生不可吗？

