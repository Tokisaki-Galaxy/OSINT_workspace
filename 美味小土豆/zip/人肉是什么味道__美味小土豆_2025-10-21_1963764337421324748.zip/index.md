---
title: 人肉是什么味道?
url: https://www.zhihu.com/question/1941555675512680840/answer/1963764337421324748
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 00:31
modified: 2025-10-21 00:32
upvote_num: 14
comment_num: 6
---

微咸，应该不是酸的

感觉口感应该比猪牛羊都要嫩，但是应该很油。

应该很适合榨油。

人类的膻味要远小于动物。

新鲜的年轻肉体是微香的，比牛腩的浓烈香气要淡。

人肉的软弹要远超过常见食用动物。

我觉得应该很好吃。

