---
title: 你认为究竟什么是二次元?
url: https://www.zhihu.com/question/659229462/answer/3568868878
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 16:42
modified: 2024-07-21 16:42
upvote_num: 2
comment_num: 0
---

二次元的概念每十年就会改变一次

“究竟什么是二次元”这个讨论根本没有意义

是同类的总归能分得清同类。

反而是急不可耐的报菜名的大概率不是

