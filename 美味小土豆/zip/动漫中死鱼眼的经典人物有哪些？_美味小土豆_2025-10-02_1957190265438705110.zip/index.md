---
title: 动漫中死鱼眼的经典人物有哪些？
url: https://www.zhihu.com/question/438986241/answer/1957190265438705110
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 21:08
modified: 2025-10-02 21:08
upvote_num: 0
comment_num: 0
---

好像已经没有什么人认识小孤独的叔叔了呢

![](./assets/v2-87c30b910ec6f4d51c2655d127f29b3c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'></svg>)

