---
title: 看事的说男朋友人不行让分手?
url: https://www.zhihu.com/question/1947452238088869199/answer/1947474771815170797
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 01:42
modified: 2025-09-06 01:42
upvote_num: 1
comment_num: 0
---

你把他们两个拉一块当面对质呗

如果算命先生信誓旦旦的答应你那事情一定很有趣

这么有意思的事情你居然不心动去试一下

