---
title: 长得不好看的人吃雌二醇会变漂亮吗？
url: https://www.zhihu.com/question/1894879855243407871/answer/2004137225043063160
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-09 10:19
modified: 2026-02-09 10:19
upvote_num: 14
comment_num: 0
---

"你是否在找自然女？"

