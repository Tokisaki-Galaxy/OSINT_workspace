---
title: 没有天赋真的适合练体育吗？
url: https://www.zhihu.com/question/657590878/answer/1941029996199141622
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 06:53
modified: 2025-08-19 06:53
upvote_num: 8
comment_num: 5
---

我6岁被招进游泳队，初中放弃成为职业运动员，开始水陆双修。

我教练说预备班才开始练田径太晚了。

他勉强收我是因为我是校第一。

但我最好成绩也就区第一。

屁用没有的。

没有极高的天赋真的不推荐走体育的路子。

