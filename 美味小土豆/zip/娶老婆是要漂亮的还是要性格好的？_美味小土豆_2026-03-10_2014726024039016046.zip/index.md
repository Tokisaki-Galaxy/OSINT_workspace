---
title: 娶老婆是要漂亮的还是要性格好的？
url: https://www.zhihu.com/question/1942475258599830182/answer/2014726024039016046
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-10 15:35
modified: 2026-03-10 15:35
upvote_num: 16
comment_num: 2
---

选漂亮的，因为不漂亮就会被我妈指定一个长得漂亮但是性格很糟糕的女人。

与其她指定还不如我自己找个漂亮的应付她一下，起码人家姑娘还站在我这边。

