---
title: 为什么「情绪价值」成为了当代年轻人择偶的「硬通货」？
url: https://www.zhihu.com/question/1943722018966045858/answer/1955217362983843226
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 10:29
modified: 2025-09-27 10:29
upvote_num: 1
comment_num: 0
---

和活人谈恋爱要是没有情绪价值，那不如找充气娃娃算了……

