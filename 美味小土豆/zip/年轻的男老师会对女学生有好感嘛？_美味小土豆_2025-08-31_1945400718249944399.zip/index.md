---
title: 年轻的男老师会对女学生有好感嘛？
url: https://www.zhihu.com/question/487905736/answer/1945400718249944399
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 08:21
modified: 2025-08-31 08:21
upvote_num: 3
comment_num: 3
---

高中的时候听女生抱怨被实习老师骚扰的事情听的不少了，本校的外校的都有。

所以我看到当老师的在互联网上一本正经的回答这类问题就想笑。

不想一棍子打死

但就是觉得很好笑

