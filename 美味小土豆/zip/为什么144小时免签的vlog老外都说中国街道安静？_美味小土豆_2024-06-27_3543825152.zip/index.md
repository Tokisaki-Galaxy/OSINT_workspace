---
title: 为什么144小时免签的vlog老外都说中国街道安静？
url: https://www.zhihu.com/question/659845050/answer/3543825152
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-06-27 13:36
modified: 2024-06-27 13:36
upvote_num: 7
comment_num: 1
---

以前淮海路那边酒吧一条街还营业的时候，每天吵得和养猪场一样。很多时候有外国人吃饭的店也会比其他店吵闹很多

