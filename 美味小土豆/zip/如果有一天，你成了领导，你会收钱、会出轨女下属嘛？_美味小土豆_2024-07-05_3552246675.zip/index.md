---
title: 如果有一天，你成了领导，你会收钱、会出轨女下属嘛？
url: https://www.zhihu.com/question/605997865/answer/3552246675
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-05 12:41
modified: 2024-07-05 12:41
upvote_num: 3
comment_num: 1
---

嘶，我有个朋友说过一句很初生的话“为什么要出轨女下属？我找年轻学生妹不好吗？第二天穿好衣服去公司上班女下属还是会觉得我是那个文质彬彬一表人才但是不好糊弄的好老板”

对了这个人现在不是我朋友了

