---
title: 《高达》那些改造女神是改造人。那么破坏游戏平衡了。对于那些普通的女主怎么办？有何补偿？
url: https://www.zhihu.com/question/1903373281962234585/answer/1905610701415911693
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-13 13:09
modified: 2025-05-13 13:09
upvote_num: 2
comment_num: 2
---

强化人精神不稳定，极容易崩溃啊

