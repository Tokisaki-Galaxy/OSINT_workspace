---
title: 男生真的会觉得女生做美甲好看吗？
url: https://www.zhihu.com/question/389035107/answer/1945843770600961123
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 13:41
modified: 2025-09-01 13:41
upvote_num: 0
comment_num: 0
---

我觉得超好看啊。

无论是地雷系打扮+双马尾+粉色美甲

还是水钻奶白+小裙子的组合。

都好可爱。

忍不住就想舔对方的手指

