---
title: 如果你手机里第八张照片出现在你头顶一米处会咋样？
url: https://www.zhihu.com/question/612445725/answer/3570116936
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-22 19:58
modified: 2024-07-22 19:58
upvote_num: 0
comment_num: 0
---

![](./assets/v2-864951bf4473b01961c444834e8d9935_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='526'></svg>)

典子、今だ！

ザグ王！

