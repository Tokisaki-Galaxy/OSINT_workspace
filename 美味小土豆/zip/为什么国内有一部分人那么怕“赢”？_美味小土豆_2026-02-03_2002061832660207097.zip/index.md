---
title: 为什么国内有一部分人那么怕“赢”？
url: https://www.zhihu.com/question/1996604573868135622/answer/2002061832660207097
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 16:52
modified: 2026-02-03 16:52
upvote_num: 80
comment_num: 5
---

赢学违背了毛主席讲的"实事求是"精神。

所以我认为这玩意有大问题。

赢学入脑的人特别的激进偏执且容易暴怒，而且思考问题特别单线程。

