---
title: 怎么看待高中学校里不让男女做同桌，怕谈恋爱？
url: https://www.zhihu.com/question/481549125/answer/1941106189925611333
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 11:56
modified: 2025-08-19 11:57
upvote_num: 7
comment_num: 0
---

谈恋爱不要找同班的啊！会死的很惨的！

还同桌……你是嫌没人管你是吧！？

