---
title: 为什么机械加工的零件那么贵？
url: https://www.zhihu.com/question/596020796/answer/3552814146
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-05 22:46
modified: 2024-07-05 22:46
upvote_num: 1
comment_num: 0
---

贵的只有你需要，而且你在市面上买不到的零件。

