---
title: 为什么会有人觉得高达水星的魔女以女性为主角很没劲？
url: https://www.zhihu.com/question/620395889/answer/1918002406538581689
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-16 17:50
modified: 2025-06-16 17:50
upvote_num: 4
comment_num: 1
---

开玩笑，真女同机甲番神无月的巫女劲大得一批

