---
title: 为什么男朋友不愿意跟我一起经营我家年入百万的公司？
url: https://www.zhihu.com/question/11909603253/answer/1965741745510802556
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 11:29
modified: 2025-10-26 11:29
upvote_num: 16
comment_num: 1
---

开玩笑，我连我家的公司都不愿意要。

经营一家公司有多累你不清楚?

真经营的那么风生水起的你家会让男朋友插手？

