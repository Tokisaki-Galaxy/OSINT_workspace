---
title: 你见过最不会点菜的人是什么样子的？
url: https://www.zhihu.com/question/40739580/answer/1936958223606327114
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-08 01:13
modified: 2025-08-08 01:13
upvote_num: 2101
comment_num: 36
---

我吧……

我当年怎么会想得出请一个在发育期的初中男生吃蔬菜天妇罗套餐+蔬菜沙拉+海鲜粥的

