---
title: 以前的日漫都这大胆的吗？
url: https://www.zhihu.com/question/665127759/answer/3605792640
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-25 21:05
modified: 2024-08-27 19:13
upvote_num: 653
comment_num: 193
---

宇宙骑士知道吧？

第一部男女主是经历了同生共死一路扶持走过来了，女主几乎经历了男主所有刻骨铭心的时刻

然后第二部的女主，是和第一部的女主抢男主来的，第三话就对第一部的女主公开发表小三宣言，第六话大家打生打死小女主直接失踪和男主特训去了。

这玩意放现在不得被炎上到爆炸啊

原来很多人不知道宇宙骑士有第二部啊

![](./assets/v2-d7d003cb89b6683917fcc1492c3c978d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1097'></svg>)

  


![](./assets/v2-1e4b092efc2be831c962756c21daa853_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1099'></svg>)

  


![](./assets/v2-73d95a21f71151406430ac034d65144d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1099'></svg>)

