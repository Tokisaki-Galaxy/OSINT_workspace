---
title: 假设大和号撞上泰坦尼克中的冰山，会怎么样?
url: https://www.zhihu.com/question/367101053/answer/2006496383146927574
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-15 22:33
modified: 2026-02-15 22:33
upvote_num: 7
comment_num: 2
---

大和的波动炮应该能把冰山蒸发掉。

但是波动炮射程有2万5000公里以上，威力可以直接击碎澳大利亚大陆。

不知道对目的地有什么影响……

