---
title: 为啥女生都拒绝聊骚？
url: https://www.zhihu.com/question/1930218222982002077/answer/1956644974016836443
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 09:01
modified: 2025-10-01 09:06
upvote_num: 61
comment_num: 9
---

如果陌生男性上来就直奔主题而且马上弹视频并不断问女方现在在哪里能不能立刻见面

那100%会被拒绝的。

  


女生喜欢按照她自己的节奏聊骚

她们能一直沉浸在前戏的拉扯和dirty talk的挑逗里

遇到棋逢对手的周旋起来真的特别有趣。

陪女生聊骚需要巨好的耐心

所以我是收费的。

