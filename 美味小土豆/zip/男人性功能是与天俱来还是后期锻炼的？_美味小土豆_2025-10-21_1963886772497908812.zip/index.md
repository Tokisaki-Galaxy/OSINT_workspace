---
title: 男人性功能是与天俱来还是后期锻炼的？
url: https://www.zhihu.com/question/647416344/answer/1963886772497908812
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 08:38
modified: 2025-10-21 08:38
upvote_num: 13
comment_num: 2
---

我曾经一直以为我是与生俱来的。

后来我才意识到不对，我练了12年的蛙跳，深蹲，卷腹，仰卧起坐，俯卧撑和大量的长跑训练。

虽然跑步成绩不怎么样，但是打败异性足够了。

