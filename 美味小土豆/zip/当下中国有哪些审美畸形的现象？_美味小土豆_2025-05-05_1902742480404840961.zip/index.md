---
title: 当下中国有哪些审美畸形的现象？
url: https://www.zhihu.com/question/47581654/answer/1902742480404840961
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-05-05 15:12
modified: 2025-05-05 15:12
upvote_num: 0
comment_num: 0
---

刻线刻线刻线，尖刺刺尖刺刺尖刺刺尖刺刺

