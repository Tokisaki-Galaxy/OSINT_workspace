---
title: 为什么车展的模特大多高挑，但并不一定漂亮？
url: https://www.zhihu.com/question/21540008/answer/1963513696438448965
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-20 07:55
modified: 2025-10-20 07:55
upvote_num: 9
comment_num: 1
---

车展模特很累的，而且开的价格巨低。

真的又累又贱

而且车展对接方还是所有展子里最油腻的。

所以有点姿色不缺钱的真的不愿意去车展

