---
title: 年轻的时候是该享受，还是玩命挣钱？
url: https://www.zhihu.com/question/591398547/answer/1943449291810144359
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 23:06
modified: 2025-08-25 23:06
upvote_num: 3
comment_num: 1
---

趁年轻一定要去享受

这会成为你将来遇到痛苦时活下去的动力

