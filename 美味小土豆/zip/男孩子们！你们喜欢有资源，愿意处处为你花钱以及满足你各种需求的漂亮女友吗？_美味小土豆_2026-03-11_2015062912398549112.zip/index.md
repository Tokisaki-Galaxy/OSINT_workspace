---
title: 男孩子们！你们喜欢有资源，愿意处处为你花钱以及满足你各种需求的漂亮女友吗？
url: https://www.zhihu.com/question/14315601248/answer/2015062912398549112
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-11 13:53
modified: 2026-03-11 13:56
upvote_num: 19
comment_num: 3
---

这样的女朋友我都可以整理出一个合集来了。

[和富二代谈恋爱是怎样的体验？](https://www.zhihu.com/question/32674202/answer/1980655727728153164?share_code=1nnhgPCoUoGd0&utm_psn=2015061799305750472)

  


[和高干子弟谈恋爱是怎样一种体验？](https://www.zhihu.com/question/28942403/answer/1981436046018360683?share_code=133bBYz2qz7Vi&utm_psn=2015061943745016104)

  


[有哪些“贫穷限制了我的想象力”的例子？](https://www.zhihu.com/question/66811597/answer/1951464924837549222)

  


[办公室中的同事全部为女性，是种怎样的体验？](https://www.zhihu.com/question/455556635/answer/2012627725832177108)

