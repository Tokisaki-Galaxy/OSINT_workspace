---
title: 女生可以给别人看泳衣或者泳装照，但是不可以看内衣，为什么呢？
url: https://www.zhihu.com/question/597391926/answer/1993713122817635220
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-11 15:57
modified: 2026-01-11 15:57
upvote_num: 10
comment_num: 1
---

发内衣照，最多说明她想撩你。

发泳装照，那可就是不死不休一决雌雄的宣告了！

![](./assets/v2-65cac49278321697489c509dd6d33f8a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='797' height='1200'></svg>)

