---
title: 如果一篇小说涉及枪械，你希望作者至少要知道什么常识?
url: https://www.zhihu.com/question/1010247280/answer/1962665607896999152
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-17 23:45
modified: 2025-10-17 23:45
upvote_num: 16
comment_num: 1
---

除非你真的开过枪或者摸过枪

否则对枪本身的描写越少越好

不要查百度当懂哥，这样写的越多读着就越蠢。

开枪，枪响，就够了，其他的内容越模糊越好。

