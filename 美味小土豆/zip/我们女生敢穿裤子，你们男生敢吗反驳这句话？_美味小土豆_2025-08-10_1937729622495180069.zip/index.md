---
title: 我们女生敢穿裤子，你们男生敢吗反驳这句话？
url: https://www.zhihu.com/question/392802271/answer/1937729622495180069
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 04:19
modified: 2025-08-10 04:19
upvote_num: 0
comment_num: 0
---

但是，男人也能穿裙子的呀。

出入公共场合也没问题的呀~

![](./assets/v2-7641da2d82661d7573ff8861276e5d88_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='700' height='500'></svg>)

