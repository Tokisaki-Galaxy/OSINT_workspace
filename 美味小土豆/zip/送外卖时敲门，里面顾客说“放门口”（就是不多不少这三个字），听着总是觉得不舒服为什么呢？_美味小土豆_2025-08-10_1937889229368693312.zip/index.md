---
title: 送外卖时敲门，里面顾客说“放门口”（就是不多不少这三个字），听着总是觉得不舒服为什么呢？
url: https://www.zhihu.com/question/11193886834/answer/1937889229368693312
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:53
modified: 2025-08-10 14:53
upvote_num: 0
comment_num: 0
---

为啥我遇到的外卖都是敲一声放下东西就走。

我已经好久没看到外卖员的正脸了

