---
title: 为什么想要改变性别的大多是男生？
url: https://www.zhihu.com/question/274768489/answer/1937712952565280853
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 03:12
modified: 2025-08-10 03:12
upvote_num: 15
comment_num: 0
---

男性就是这样，一会想变成这个，一会想变成那个

比起奥特曼，强殖装甲，宇宙骑士

变成女性终归容易一些

