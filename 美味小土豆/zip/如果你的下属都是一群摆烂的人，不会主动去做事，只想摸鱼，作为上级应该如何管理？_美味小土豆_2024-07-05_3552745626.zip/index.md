---
title: 如果你的下属都是一群摆烂的人，不会主动去做事，只想摸鱼，作为上级应该如何管理？
url: https://www.zhihu.com/question/618717552/answer/3552745626
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-05 21:18
modified: 2024-07-05 21:18
upvote_num: 4
comment_num: 0
---

我们公司的标准是说了就能去把一件事情完成就算好的。

做完一件事情愣着等你来叫他做第二件事情都算是还能用的。

因为这样的人愿意拿着2000块工资干活。

