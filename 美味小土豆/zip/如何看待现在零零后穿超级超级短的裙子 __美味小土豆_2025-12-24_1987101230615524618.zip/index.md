---
title: 如何看待现在零零后穿超级超级短的裙子 ?
url: https://www.zhihu.com/question/15664874952/answer/1987101230615524618
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-24 10:04
modified: 2025-12-24 10:04
upvote_num: 102
comment_num: 15
---

零零后在推特还是个禁词的时候，我已经开始陪着穿jk制服no胖nobra（这次拼对了！）的现役jc做各种任务了。

现在要吐槽起码也是吐槽零五后了。

