---
title: 真的有把碗打碎也不会发火的父母吗?
url: https://www.zhihu.com/question/672537379/answer/1936964722772649493
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-08 01:39
modified: 2025-08-08 01:39
upvote_num: 0
comment_num: 0
---

我就记得我妈会很急的说"别去动!别拿别拿！"

