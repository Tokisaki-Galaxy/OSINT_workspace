---
title: 你会接纳跟别人同居过的女朋友吗？
url: https://www.zhihu.com/question/13510405489/answer/1984654119965847941
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-17 16:00
modified: 2025-12-17 16:05
upvote_num: 28
comment_num: 4
---

基本上我的交往对象都没有到能和别人同居的年纪，反而是我很有引诱别人来我家住的能力。

我觉得一个劲的强调自己"不介意不介意"，还是有点龟的……

但是等等，这好像是一个挺有趣的类型？！

《问我能不能交往的神待jk其实是离家出走和中年大叔同居了一年的富家大小姐》

如果这样的话好像也不是不可以！

![](./assets/v2-555a9a2186ead910bb3d888877344d12_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1671' height='2388'></svg>)

