---
title: 钱和女人，你选哪个?
url: https://www.zhihu.com/question/1928817803462423608/answer/1953015379921183122
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-21 08:39
modified: 2025-09-21 08:39
upvote_num: 6
comment_num: 1
---

我选姑娘

有了姑娘就有钱了

