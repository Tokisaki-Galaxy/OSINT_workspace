---
title: 直男会喜欢男生吗?
url: https://www.zhihu.com/question/1938592001869199034/answer/1957083537846018748
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 14:04
modified: 2025-10-02 14:04
upvote_num: 14
comment_num: 10
---

会。

我起码被十来个直男说过"你说话也太可爱了吧！"

没有装女生，我进群就说了我是男的！

我曾经还被直男夸过"你声音好好听啊"

不，我能保证这帮傻叼都是直的，不是gay！

啊啊啊啊，太可怕了

![](./assets/v2-2f6ba9c139031768673c328e169b0d5e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

