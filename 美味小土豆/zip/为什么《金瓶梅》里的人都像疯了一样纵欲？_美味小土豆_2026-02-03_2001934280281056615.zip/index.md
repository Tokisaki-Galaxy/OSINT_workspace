---
title: 为什么《金瓶梅》里的人都像疯了一样纵欲？
url: https://www.zhihu.com/question/2000202977185665622/answer/2001934280281056615
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 08:25
modified: 2026-02-03 08:25
upvote_num: 54
comment_num: 9
---

啊？金瓶梅那个还叫纵欲？

