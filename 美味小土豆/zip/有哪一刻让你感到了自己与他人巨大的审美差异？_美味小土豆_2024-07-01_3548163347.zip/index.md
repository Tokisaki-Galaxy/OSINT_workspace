---
title: 有哪一刻让你感到了自己与他人巨大的审美差异？
url: https://www.zhihu.com/question/275132810/answer/3548163347
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-01 18:19
modified: 2024-07-01 18:19
upvote_num: 2
comment_num: 0
---

现在科学复原的恐龙长得越来越弱鸡了。都说侏罗纪世界3的镰刀龙丑，其实私底下我还挺喜欢这头“怪兽”的，可惜在古生物爱好圈里的我也不敢承认。

