---
title: 是否所谓“假小子”型女生和真正男生的兴趣爱好、思维习惯还是有一定差别？
url: https://www.zhihu.com/question/612249432/answer/1946693757308208247
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 21:59
modified: 2025-09-03 21:59
upvote_num: 23
comment_num: 1
---

差别大了，假小子可以说是女人中的女人。

异性浓度巨高

假小子确实大大咧例不假，但是和假小子打篮球时她毫不掩饰不假思索的带着三个球就冲进你怀抱里那股劲莽，贴着你身体拼命扭摆的触感，你是绝对不会把她当成一个男人来看待的。

假小子只是更爱剪短发，但是活泼开朗的短发黑皮美少女偶尔涂了口红有点害羞的朝着你吐舌头脸红的模样，难道你要装作看不见而不是摸摸她的头夸夸她漂亮吗？

就算她假装不好意思的轻轻踢你一脚，也掩饰不住她可爱的笑脸啊

假小子的心思是很敏感的，大大咧咧不是没心没肺，不在意打扮不是对美没有概念，喜欢和男生玩并不是说她真的有一个男人的脑袋。

假小子也会抱着枕头看偶像剧，也会喜欢男生玩俗套的浪漫，她更喜欢你牵着她的手在路上奔跑，在家庭餐厅和你有一搭没一搭的聊着没有营养的话题，希望你能更在意她，希望能被更喜欢啊。

假小子比一般女生还要敏感一些。

她真的会在意你是不是不喜欢男孩子气的她，你是不是更喜欢留长发的女孩子，你会不会讨厌她晒黑的皮肤。

所以如果你要抱着找男人婆的想法就不要去招惹假小子，你从根底上就误解了这一类少女了，她们绝对不是男性的替代品这么无聊的人类，她们是很少女心的短发可爱女孩子啊！

![](./assets/v2-bf01e49bd881c8c1600bb5caf63a3724_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='797' height='1200'></svg>)

  


![](./assets/v2-302c74792900aed8d4ed1d5eefe7f7e7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='1000'></svg>)

  


![](./assets/v2-b97580c20bd210b34f00b26763b554aa_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-3e4e36bd6df79a718d5754d8d793de36_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-67a6cb6b27a91949c508b8fa708ade8e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-3f98ec1f0d4736b37f7edb9c5a943490_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-a0e1ffbf19d1b86c2e00325e8ea48959_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='1280'></svg>)

