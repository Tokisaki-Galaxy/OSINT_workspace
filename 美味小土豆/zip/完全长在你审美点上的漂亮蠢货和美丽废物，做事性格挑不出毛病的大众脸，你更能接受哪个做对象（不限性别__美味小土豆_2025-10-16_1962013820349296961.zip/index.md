---
title: 完全长在你审美点上的漂亮蠢货和美丽废物，做事性格挑不出毛病的大众脸，你更能接受哪个做对象（不限性别?
url: https://www.zhihu.com/question/863390469/answer/1962013820349296961
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-16 04:35
modified: 2025-10-16 04:35
upvote_num: 13
comment_num: 3
---

两个都不选

因为我现实里真的有一个颜值完美长在我审美性癖上的天才美少女cp。

所以我不需要这么愚蠢的假设

