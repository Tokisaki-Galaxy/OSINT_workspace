---
title: 180男生更喜欢抱170cm重63kg的女生还是158cm48kg身材好的女生？
url: https://www.zhihu.com/question/1901948922064253212/answer/1938871184763647015
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 07:55
modified: 2025-08-13 07:55
upvote_num: 13
comment_num: 1
---

为什么不两个都抱一抱呢？

自己不抱过怎么知道哪个更好呢？

偷偷告诉你，170和158的美少女抱起来都很棒的。

