---
title: “性同意权”是女人的特权吗？
url: https://www.zhihu.com/question/1896331546576798466/answer/1987857620770501124
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-26 12:09
modified: 2025-12-26 12:09
upvote_num: 9
comment_num: 7
---

不是，你作为一个男的也不可能饥渴到完全来者不拒吧？

