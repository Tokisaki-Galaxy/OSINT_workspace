---
title: 我爸说你不生他不生世界就走向灭亡，我该怎么反驳他？
url: https://www.zhihu.com/question/1982603470256242814/answer/1987067850792390919
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-24 07:51
modified: 2025-12-24 07:51
upvote_num: 7
comment_num: 6
---

"真的吗？我靠太棒了我要看人类灭亡！"

开玩笑的，我爸暂时还没问过我结婚生孩子的问题，估计当年想抓我入赘的金发笨蛋大小姐给了他不小的心理阴影。

不过我还是蛮期待哪天我爸想起来了问我什么时候考虑结婚要孩子的。

这样我就可以很认真的问他："比我小12岁的hong三代天才美少女和比我小15岁的双马尾地偶jk，你觉得哪个当结婚对象比较合适？"

我爸一定会骂我一顿然后让我那凉快哪待着去。

耶~

![](./assets/v2-664a643a41b385b602db81f822799a06_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='935' height='1200'></svg>)

