---
title: 你最尴尬的一次 cosplay 是什么样的？
url: https://www.zhihu.com/question/269186717/answer/1930345359898572785
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-20 19:16
modified: 2025-07-20 19:16
upvote_num: 2
comment_num: 1
---

出士官长的时候被人拉去混在一堆假面骑士里拍合照

