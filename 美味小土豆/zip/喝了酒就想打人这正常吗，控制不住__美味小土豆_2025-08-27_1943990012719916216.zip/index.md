---
title: 喝了酒就想打人这正常吗，控制不住?
url: https://www.zhihu.com/question/612429873/answer/1943990012719916216
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-27 10:55
modified: 2025-08-27 10:55
upvote_num: 0
comment_num: 0
---

你放五条疯狗冲上去就知道他是不是能控制得住了୧꒰•̀ᴗ•́꒱୨

