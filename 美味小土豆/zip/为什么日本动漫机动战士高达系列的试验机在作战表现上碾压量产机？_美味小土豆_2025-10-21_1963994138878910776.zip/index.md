---
title: 为什么日本动漫机动战士高达系列的试验机在作战表现上碾压量产机？
url: https://www.zhihu.com/question/511979507/answer/1963994138878910776
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 15:44
modified: 2025-10-21 15:44
upvote_num: 7
comment_num: 1
---

讲个很搞笑的事情，现在rx78的数量已经差不多能算是小批量量产型了。

z高达也是。

