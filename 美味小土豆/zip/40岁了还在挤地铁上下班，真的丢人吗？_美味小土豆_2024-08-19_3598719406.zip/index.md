---
title: 40岁了还在挤地铁上下班，真的丢人吗？
url: https://www.zhihu.com/question/547759368/answer/3598719406
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-19 00:10
modified: 2024-08-19 00:10
upvote_num: 1
comment_num: 0
---

有啥丢人的，起码你还在能坐到地铁的大城市

我现在每天下班就是开个小破电动车回隔壁村的宿舍。

