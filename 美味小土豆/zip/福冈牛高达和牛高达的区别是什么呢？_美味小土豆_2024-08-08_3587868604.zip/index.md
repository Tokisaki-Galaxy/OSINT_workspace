---
title: 福冈牛高达和牛高达的区别是什么呢？
url: https://www.zhihu.com/question/663432070/answer/3587868604
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-08 13:16
modified: 2024-08-08 13:16
upvote_num: 4
comment_num: 0
---

多了一个像浮游炮的支架

为了能站得稳所以背了一个很愚蠢的巨大浮游炮当支架，万代为了让它看起来没那么蠢所以给了套新设定。

就这个区别

