---
title: 有哪些常人不知道的「常识」？
url: https://www.zhihu.com/question/39791312/answer/1945247590854690121
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-30 22:12
modified: 2025-08-30 22:12
upvote_num: 6
comment_num: 0
---

机动警察辽译版把av-0翻译成"泽洛"，也就是zero，但其实av-0叫和平使者，它的原型机av-x-0才叫做zero，零式。

