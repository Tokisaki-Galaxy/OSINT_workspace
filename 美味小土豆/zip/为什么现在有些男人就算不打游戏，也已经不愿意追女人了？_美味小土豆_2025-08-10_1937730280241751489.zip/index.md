---
title: 为什么现在有些男人就算不打游戏，也已经不愿意追女人了？
url: https://www.zhihu.com/question/342871336/answer/1937730280241751489
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 04:21
modified: 2025-08-10 04:21
upvote_num: 5
comment_num: 0
---

不打游戏可以买玩具，看电影，刷短视频，看动画，看舞台剧，参加漫展，拼模型，吃好吃的，养宠物，旅游，圣地巡礼，钓鱼。

这个世界上那么多美好的事情哎

