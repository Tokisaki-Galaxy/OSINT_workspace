---
title: 如何短时间内鉴别好姑娘？
url: https://www.zhihu.com/question/19817130/answer/1955256791408575673
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 13:05
modified: 2025-09-27 13:05
upvote_num: 541
comment_num: 56
---

我读书的时候有个很简单粗暴但是很管用的鉴定办法：

看她是不是做作业

是不是能把作业写完

愿意做作业是态度端正

能把作业写完是能力足够。

一个女生无论出来怎么玩，只要她还愿意写作业，就不会是太糟糕的姑娘。

