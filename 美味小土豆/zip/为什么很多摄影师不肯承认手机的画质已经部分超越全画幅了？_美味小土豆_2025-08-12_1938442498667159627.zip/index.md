---
title: 为什么很多摄影师不肯承认手机的画质已经部分超越全画幅了？
url: https://www.zhihu.com/question/1896727971345195798/answer/1938442498667159627
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 03:31
modified: 2025-08-12 03:31
upvote_num: 0
comment_num: 0
---

手机拍人物和模型就是很轻很飘。没有相机来得厚来得重。

觉得手机画质够用你试试拿手机去拍应聘摄影师呗

