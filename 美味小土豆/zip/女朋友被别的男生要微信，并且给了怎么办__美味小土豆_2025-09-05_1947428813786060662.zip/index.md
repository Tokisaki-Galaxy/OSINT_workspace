---
title: 女朋友被别的男生要微信，并且给了怎么办?
url: https://www.zhihu.com/question/593508103/answer/1947428813786060662
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 22:40
modified: 2025-09-05 22:40
upvote_num: 2
comment_num: 0
---

往好处想，你现在就是在ntr别人的女朋友了耶

是不是有点兴奋起来了？！

