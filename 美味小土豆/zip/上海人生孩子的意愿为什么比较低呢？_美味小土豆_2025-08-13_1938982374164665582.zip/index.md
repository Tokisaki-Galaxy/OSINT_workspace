---
title: 上海人生孩子的意愿为什么比较低呢？
url: https://www.zhihu.com/question/664851393/answer/1938982374164665582
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 15:17
modified: 2025-08-13 15:17
upvote_num: 3
comment_num: 0
---

穷呗，上海什么都贵啊

很多上海人是生不起，养不起，婚不起

