---
title: 人们为什么开始喜欢《泰坦尼克号》里面的贵族少爷卡尔？
url: https://www.zhihu.com/question/20194023/answer/1980412652166616622
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-05 23:06
modified: 2025-12-05 23:06
upvote_num: 10
comment_num: 0
---

我小时候就对这句台词印象很深

"我们是贵族，肉丝"

现实里相信这句话的二代有一个算一个都是傻逼。

光是因为这句话我就不喜欢这个二世祖。

