---
title: 为什么中年人体力下降后，打架能力却强于年轻人？
url: https://www.zhihu.com/question/656633608/answer/1939289444218808227
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 11:37
modified: 2025-08-14 11:37
upvote_num: 10
comment_num: 1
---

别搞了，小时候又不是没打过架，中年人被初中生开瓢进医院的例子又不少。

你说中年人焉坏我承认，论打架真的别往中年老脸上贴金了。大部分中年人是骂人劲头十足，等到动手就开始嚷"我要报警！报警！!"

