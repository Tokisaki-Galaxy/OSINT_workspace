---
title: 现在的年轻人喜欢二次元。能不能让献血库与二次元联名并送一些二次元周边产品来积极鼓励年轻人去无偿献血?
url: https://www.zhihu.com/question/1977816971996321027/answer/1979189536530665630
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-02 14:05
modified: 2025-12-02 14:05
upvote_num: 23
comment_num: 0
---

献血送的周边撑死了一个吧唧。

同样的联动活动放奶茶这边只要25元还给你两杯奶茶。

而且献血周边挂出来很蠢的啊。

