---
title: 为什么有的从未锻炼的男性，觉得自己能打过有实力的女性?
url: https://www.zhihu.com/question/2541675317/answer/1976362389613065607
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-24 18:51
modified: 2025-11-24 18:51
upvote_num: 7
comment_num: 0
---

有句说句，如果对面是400斤从来不锻炼的肥宅，我都不一定打得过……

