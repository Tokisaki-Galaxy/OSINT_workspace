---
title: 为什么家长为我们物色的相亲对象都这么丑？
url: https://www.zhihu.com/question/328997057/answer/1980314946777670716
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-05 16:37
modified: 2025-12-05 16:37
upvote_num: 740
comment_num: 24
---

但凡爹妈手里有好的，你小时候就应该有和你一起玩的长得很漂亮的青梅竹马了。

你再仔细想想，你是不是有错过了什么？

