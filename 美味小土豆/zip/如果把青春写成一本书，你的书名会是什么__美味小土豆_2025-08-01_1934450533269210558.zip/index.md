---
title: 如果把青春写成一本书，你的书名会是什么?
url: https://www.zhihu.com/question/652709590/answer/1934450533269210558
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-01 03:09
modified: 2025-08-01 03:09
upvote_num: 7
comment_num: 4
---

《班长和学习委员和副会长和纪律委员和学妹和校外大姐姐和黑皮体育生前女友与我的修罗场》

