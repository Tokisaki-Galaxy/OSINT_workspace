---
title: 大猫生的小猫过段时间要送走，大猫是什么心情？
url: https://www.zhihu.com/question/412869550/answer/1935393712474662271
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-03 17:36
modified: 2025-08-03 17:36
upvote_num: 52
comment_num: 0
---

小猫四个月大还不送走母猫就要开始揍小猫了

