---
title: 假如有一个性转的你，你会喜欢他／她吗？
url: https://www.zhihu.com/question/641988240/answer/1934756775606878899
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-01 23:26
modified: 2025-08-01 23:26
upvote_num: 0
comment_num: 0
---

性转的我?!耶!那就是黑皮高个性格大大咧咧热衷瑟瑟的体育生哎!

那高低要试试我和我自己开一局生死局，看谁会先哭着求饶了!

![](./assets/v2-0dc28375e4d4fe3492c841d083e2b234_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='503' height='1116'></svg>)

