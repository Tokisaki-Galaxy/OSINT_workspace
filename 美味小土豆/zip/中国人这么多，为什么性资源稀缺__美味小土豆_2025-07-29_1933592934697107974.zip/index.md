---
title: 中国人这么多，为什么性资源稀缺?
url: https://www.zhihu.com/question/651938880/answer/1933592934697107974
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-29 18:21
modified: 2025-07-29 18:21
upvote_num: 2
comment_num: 0
---

性资源.都泛滥了好吧，小黄本，小黄文，色情视频，自拍，仿真娃娃，杯子，你一辈子都用不完，哪匮乏了。

