---
title: 如何找到一个 JK 或者 lo 娘当女朋友？
url: https://www.zhihu.com/question/398751658/answer/3612173926
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-01 01:40
modified: 2024-09-01 01:40
upvote_num: 4
comment_num: 2
---

求求你们了，说jk制服吧

找jk做女朋友很容易违法的

