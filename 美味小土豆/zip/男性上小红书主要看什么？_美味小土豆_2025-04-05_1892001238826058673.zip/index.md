---
title: 男性上小红书主要看什么？
url: https://www.zhihu.com/question/2914532252/answer/1892001238826058673
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-04-05 23:50
modified: 2025-04-05 23:50
upvote_num: 4
comment_num: 0
---

我不知道为什么……小红书上发机械设定图流量要比微博高很多，而且气氛也挺好的

