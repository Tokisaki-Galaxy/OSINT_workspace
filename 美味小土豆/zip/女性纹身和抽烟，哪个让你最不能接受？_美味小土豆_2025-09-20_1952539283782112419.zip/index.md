---
title: 女性纹身和抽烟，哪个让你最不能接受？
url: https://www.zhihu.com/question/1924041718677894686/answer/1952539283782112419
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-20 01:07
modified: 2025-09-20 01:07
upvote_num: 12
comment_num: 5
---

这两个我都喜欢

皮肤白皙的纹身妹子一边坐在床上抽事后烟一边用涂了黑色指甲油的脚趾戳你胸口的场景。

还蛮涩的。

![](./assets/v2-eb3067574e38effc4bf70a8b191cb0d7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='938'></svg>)

