---
title: 有哪些学美术的人才懂的梗？
url: https://www.zhihu.com/question/290870821/answer/1948912586843231697
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 00:56
modified: 2025-09-10 00:56
upvote_num: 3
comment_num: 0
---

水泥地上磨铅笔比削笔刀好用

但是被老师发现了会挨骂

