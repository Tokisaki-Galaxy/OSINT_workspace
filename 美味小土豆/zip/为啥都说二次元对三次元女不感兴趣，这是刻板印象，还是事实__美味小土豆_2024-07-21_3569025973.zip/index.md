---
title: 为啥都说二次元对三次元女不感兴趣，这是刻板印象，还是事实?
url: https://www.zhihu.com/question/661883881/answer/3569025973
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 20:24
modified: 2024-07-21 20:24
upvote_num: 2
comment_num: 1
---

![](./assets/v2-f4bb3be4285c0a87c5673ad5b6cb0ca8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

  


![](./assets/v2-312f83dbea7007a8aaebcb6f3b82c908_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='526'></svg>)

  


![](./assets/v2-92134b587776d59263e0404fb54f560a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='903'></svg>)

  


![](./assets/v2-3fce9642865dce3ddd7dd9288e2687a1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

因为二次元真的把对于女性美好的一面给拉爆了。

而且版本更迭还快

不过我女票说我喜欢的角色她都愿意出！舞乙hime都行！她说反正她比妮娜也大不了几岁，还是可以叫我“お父さん”的

所以三次元也是很棒的，不要刻板印象呀。

