---
title: 现在还有真心实意的谈恋爱吗？
url: https://www.zhihu.com/question/667257530/answer/2006694033259516352
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-16 11:39
modified: 2026-02-16 11:39
upvote_num: 8
comment_num: 5
---

有啊，我谈每一段恋爱的时候都是真心实意一心一意的。

我差不多可以给每一个恋爱对象都留下这辈子都难以忘怀的深刻回忆。

