---
title: 如果夏亚在格里普斯战役是开的是高达mk3会怎样？
url: https://www.zhihu.com/question/1924476175478167471/answer/1925707966906103795
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-08 00:09
modified: 2025-07-08 00:09
upvote_num: 20
comment_num: 21
---

你至少得给他一台ex-s或者是mk5。

就是不知道爱丽丝会不会受得了夏亚

