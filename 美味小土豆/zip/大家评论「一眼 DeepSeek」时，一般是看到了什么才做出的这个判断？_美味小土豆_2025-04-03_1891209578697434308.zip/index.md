---
title: 大家评论「一眼 DeepSeek」时，一般是看到了什么才做出的这个判断？
url: https://www.zhihu.com/question/15332668661/answer/1891209578697434308
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-03 19:25
modified: 2025-04-03 19:25
upvote_num: 2
comment_num: 0
---

“当什么什么时，他正在干什么什么什么”——ds特别特别喜欢句式。

”像极了”

”他撕开衣服，露出了什么什么”

齿轮

量子纠缠

“一如n年前的什么什么样子”

“顺便说一句”

