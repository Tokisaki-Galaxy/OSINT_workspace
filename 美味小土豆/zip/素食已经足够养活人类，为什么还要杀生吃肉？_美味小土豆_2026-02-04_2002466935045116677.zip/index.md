---
title: 素食已经足够养活人类，为什么还要杀生吃肉？
url: https://www.zhihu.com/question/329587667/answer/2002466935045116677
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-04 19:42
modified: 2026-02-04 19:42
upvote_num: 20
comment_num: 5
---

纯素食吃不饱，并且很容易饿，而且会四肢无力头晕眼花，力量会明显下降。

这么显而易见的问题有什么好讨论的。

