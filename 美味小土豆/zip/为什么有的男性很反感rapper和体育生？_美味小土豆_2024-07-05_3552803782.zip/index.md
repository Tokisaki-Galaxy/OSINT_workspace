---
title: 为什么有的男性很反感rapper和体育生？
url: https://www.zhihu.com/question/569579122/answer/3552803782
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-05 22:33
modified: 2024-07-05 22:33
upvote_num: 1
comment_num: 0
---

时代真的变了，以前我们是男生愿意和体育生玩，但是女生却很嫌弃体育生。

