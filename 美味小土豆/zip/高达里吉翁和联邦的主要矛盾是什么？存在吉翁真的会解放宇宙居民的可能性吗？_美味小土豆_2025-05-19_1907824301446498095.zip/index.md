---
title: 高达里吉翁和联邦的主要矛盾是什么？存在吉翁真的会解放宇宙居民的可能性吗？
url: https://www.zhihu.com/question/489922505/answer/1907824301446498095
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-19 15:45
modified: 2025-05-19 15:45
upvote_num: 30
comment_num: 0
---

完全不存在。否则一周战争就不是这么打的了。

吉恩想建立纳粹式的人类帝国，对地球和殖民卫星进行全面高压统治，建立一个凌驾于所有政权之上的独裁扎比王朝。

纯粹简单的恶

