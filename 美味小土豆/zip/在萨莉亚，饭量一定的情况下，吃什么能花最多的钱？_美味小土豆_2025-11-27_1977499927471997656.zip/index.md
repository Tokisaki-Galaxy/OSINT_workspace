---
title: 在萨莉亚，饭量一定的情况下，吃什么能花最多的钱？
url: https://www.zhihu.com/question/1951687087217702289/answer/1977499927471997656
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-27 22:12
modified: 2025-11-27 22:12
upvote_num: 12
comment_num: 1
---

蜗牛，烤鱿鱼，小甜点，单点饮料。

这个点法能让一个身高164体重40kg的小鸟胃一个下午吃掉200块钱。

