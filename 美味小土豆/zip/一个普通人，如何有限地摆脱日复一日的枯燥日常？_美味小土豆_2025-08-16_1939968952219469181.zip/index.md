---
title: 一个普通人，如何有限地摆脱日复一日的枯燥日常？
url: https://www.zhihu.com/question/1939962593629413434/answer/1939968952219469181
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 08:37
modified: 2025-08-16 08:37
upvote_num: 1
comment_num: 0
---

不上班，居无定所，离开自己的城市，有一天过一天。

贼拉刺激

