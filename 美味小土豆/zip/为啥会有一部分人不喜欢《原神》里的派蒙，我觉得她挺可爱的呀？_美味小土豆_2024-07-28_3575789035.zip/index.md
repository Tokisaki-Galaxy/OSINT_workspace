---
title: 为啥会有一部分人不喜欢《原神》里的派蒙，我觉得她挺可爱的呀？
url: https://www.zhihu.com/question/554582360/answer/3575789035
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-28 05:49
modified: 2024-07-28 05:49
upvote_num: 2
comment_num: 0
---

游戏里还不错，但是用高德地图的派蒙语音我是真的烦这只矮冬瓜，她，她一直在骂我(｡•ˇ‸ˇ•｡)

