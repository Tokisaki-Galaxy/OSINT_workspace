---
title: 十里坡剑神的可信度有多少？
url: https://www.zhihu.com/question/23242695/answer/3597541421
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-17 17:27
modified: 2024-08-17 17:27
upvote_num: 12
comment_num: 0
---

恶魔城月下，你的武器被死神收走以后可以回去城入口那边杀人鱼练级，那个地方的人鱼会不停的刷出来，如果你有足够的时间可以把自己的等级练得很高。

就是这个地方

![](./assets/v2-de2f4d6ee76800e23e5e299fd927601c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

