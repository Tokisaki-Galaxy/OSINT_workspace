---
title: 如何在新班级里快速确认哪个人是二次元？
url: https://www.zhihu.com/question/419013779/answer/3614872001
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 22:12
modified: 2024-09-03 22:12
upvote_num: 7
comment_num: 0
---

我当年是因为被同桌发现了我的幸运硬币

![](./assets/v2-7e9b16e2d3d1acacc0f4b54eb3ca42d1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='4000' height='3000'></svg>)

