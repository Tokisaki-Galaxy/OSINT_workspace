---
title: 女生可以在家中裸居吗？
url: https://www.zhihu.com/question/848227572/answer/1956014666720453798
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 15:17
modified: 2025-09-29 15:17
upvote_num: 1247
comment_num: 44
---

我cp就爱全裸在家走来走去。

她在家里基本是不穿衣服的，还喜欢光脚踩来踩去。

我看她没有什么不方便的，活得很自在。

只是每次我去她家的时候，她都会全裸开门然后一下抱住我。

这导致了我经常怀疑咱俩到底谁在包养谁这件事情。

