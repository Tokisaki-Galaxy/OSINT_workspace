---
title: 我16，早恋，男朋友一直想要我怎么办？
url: https://www.zhihu.com/question/410490923/answer/2007537665835278657
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-18 19:31
modified: 2026-02-18 20:16
upvote_num: 35
comment_num: 0
---

你反感只是因为你不喜欢他。

你真的很喜欢他就是你胡思乱想了。

没必要反驳

也许你自己也没发现你没那么喜欢她。

