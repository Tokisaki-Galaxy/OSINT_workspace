---
title: 如何评价《机动战士高达GQuuuuuuX》第五集？
url: https://www.zhihu.com/question/1903371524427224714/answer/1903437174617147377
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-07 13:13
modified: 2025-05-07 13:13
upvote_num: 143
comment_num: 23
---

黑三连-1真的是好人，全程打得规规矩矩。

这集倒是完美体现了“不要和高中生打架，她们是真的敢掏刀子捅人的，脑子发热了根本不计较后果！”这句话。

ps：我只有一个疑虑——鲁姆战役生擒雷比尔的战绩没有佣兵部队愿意雇佣他们俩？啊？！

