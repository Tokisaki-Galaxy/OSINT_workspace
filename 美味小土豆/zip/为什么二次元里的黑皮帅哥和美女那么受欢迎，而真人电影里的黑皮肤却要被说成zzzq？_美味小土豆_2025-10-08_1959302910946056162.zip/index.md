---
title: 为什么二次元里的黑皮帅哥和美女那么受欢迎，而真人电影里的黑皮肤却要被说成zzzq？
url: https://www.zhihu.com/question/635314073/answer/1959302910946056162
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-08 17:03
modified: 2025-10-08 17:03
upvote_num: 5
comment_num: 2
---

重点是要好看啊

只要长得好看，肤色性别种族都可以是加分项。

![](./assets/v2-38bb8aa8186e650b70a4e9a6986e8215_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-5cd032d4b8c93727e2755214ba06ddd2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='1536'></svg>)

  


![](./assets/v2-be3f046d54eafcc63a526059bad3f64e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='654'></svg>)

