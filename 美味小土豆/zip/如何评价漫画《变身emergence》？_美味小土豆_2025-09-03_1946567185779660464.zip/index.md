---
title: 如何评价漫画《变身emergence》？
url: https://www.zhihu.com/question/13526142928/answer/1946567185779660464
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 13:36
modified: 2025-09-03 13:36
upvote_num: 1111
comment_num: 49
---

我就说一点

女主逃学以后早上赤身裸体的醒过来第一个反应是自己上学要迟到了，然后意识到自己不用上学了才又安心的躺下去。

这段，没有和神待jk过过夜的人一般是不会意识到这个细节的。

这个场景真的特别真实，作者相当有生活啊。

