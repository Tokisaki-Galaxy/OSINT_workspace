---
title: 女朋友为前任打过胎，那么我的孩子基因会不会纯？
url: https://www.zhihu.com/question/305506966/answer/1947686803487302371
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 15:45
modified: 2025-09-06 15:45
upvote_num: 27
comment_num: 3
---

看到很多人在用严谨的论据证明"先父遗传"是伪科学

但是……他们在意的根本不是科学问题啊

![](./assets/v2-b666ec632a8594ef89db2a342ab62787_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1328' height='1220'></svg>)

