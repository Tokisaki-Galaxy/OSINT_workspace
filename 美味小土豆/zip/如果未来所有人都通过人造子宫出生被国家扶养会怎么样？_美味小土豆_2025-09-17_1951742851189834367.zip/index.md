---
title: 如果未来所有人都通过人造子宫出生被国家扶养会怎么样？
url: https://www.zhihu.com/question/1947979707799827676/answer/1951742851189834367
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-17 20:22
modified: 2025-09-17 20:22
upvote_num: 56
comment_num: 0
---

怎么，这个世界线也要打叫龙吗？

![](./assets/v2-63a218c8f4ecb89e524ab347046bff5b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='900'></svg>)

