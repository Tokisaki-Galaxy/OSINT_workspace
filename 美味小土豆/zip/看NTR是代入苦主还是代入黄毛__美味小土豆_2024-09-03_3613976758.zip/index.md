---
title: 看NTR是代入苦主还是代入黄毛?
url: https://www.zhihu.com/question/463313680/answer/3613976758
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 02:57
modified: 2024-09-03 02:57
upvote_num: 9
comment_num: 1
---

啊？我一般是为了看女主能恶堕到什么地步，还从来没考虑过代入到谁的问题。

不过现在ntr本都快画成是女主和黄毛纯爱本了，能看得出来现在业界的作者和读者都很反感亚撒西男主角。

![](./assets/v2-cbec524fdacb7edd6c0bc5b46df4e2d0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1746'></svg>)

  


![](./assets/v2-af705a350e392c1b5b6b37262163182f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1743'></svg>)

  


![](./assets/v2-e2556e035377727c2e2d8ef77a797018_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1852'></svg>)

  


![](./assets/v2-46657d5e56c572070c77d0f339a6b71a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1913'></svg>)

