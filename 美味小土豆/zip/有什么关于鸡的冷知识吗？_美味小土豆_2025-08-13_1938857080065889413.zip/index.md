---
title: 有什么关于鸡的冷知识吗？
url: https://www.zhihu.com/question/306750589/answer/1938857080065889413
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 06:59
modified: 2025-08-13 06:59
upvote_num: 0
comment_num: 0
---

猫怕鸡。

