---
title: 最近看到好多回答，都会配一张油画然后下面引用一句圣经，这是为啥？
url: https://www.zhihu.com/question/1941053704791892285/answer/1944023385584690764
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-27 13:08
modified: 2025-08-27 13:08
upvote_num: 32
comment_num: 6
---

我只是，想找个随便输入点什么文字的机会，放几张我觉得很好看的涩图——喵门

![](./assets/v2-07d2265f93142a22815bbfd39b212b0a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1344' height='1728'></svg>)

