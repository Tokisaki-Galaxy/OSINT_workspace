---
title: 男人喜欢肉肉的女生还是喜欢苗条的女生？
url: https://www.zhihu.com/question/1912928829917369210/answer/1956062588640133394
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 18:27
modified: 2025-09-29 18:27
upvote_num: 8
comment_num: 3
---

我是那种很喜欢白瘦幼的下头男。

因为白瘦幼有一个很棒的特点——开始长肉以后会巨涩情巨可爱。

因为骨架纤细，再有脂肪加成，整个人都会变得涩气的不得了！

