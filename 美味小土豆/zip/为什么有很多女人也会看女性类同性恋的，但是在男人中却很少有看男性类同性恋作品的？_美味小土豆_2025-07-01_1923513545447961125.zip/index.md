---
title: 为什么有很多女人也会看女性类同性恋的，但是在男人中却很少有看男性类同性恋作品的？
url: https://www.zhihu.com/question/1902720298803009208/answer/1923513545447961125
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-01 22:49
modified: 2025-07-01 22:49
upvote_num: 1677
comment_num: 346
---

好像在这样的百合组合在女性眼里就会很不适，类似男性看到bl一样。

很有趣

![](./assets/v2-02727fa7f25709cccf323475f314cef7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1185'></svg>)

  


  


![](./assets/v2-c40e410bfd746f328b31e23aa90a63a2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1669'></svg>)

