---
title: 如今监控遍地，杀手会不会因此绝迹？
url: https://www.zhihu.com/question/348284601/answer/1943630646128939271
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-26 11:07
modified: 2025-08-26 11:07
upvote_num: 0
comment_num: 0
---

这样不就有研发光学迷彩的意义了嘛。

