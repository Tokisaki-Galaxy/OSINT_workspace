---
title: 假如你一觉醒来发现自己性别变了，并且被告知一个月后才会变回来，你会怎么度过这一个月？
url: https://www.zhihu.com/question/644179003/answer/1957535051513332693
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 19:58
modified: 2025-10-03 19:58
upvote_num: 7
comment_num: 5
---

那我还是躲一个月变回来吧，我不能接受性转以后颜值变低

躲一个月是因为我怕我cp撅我，虽然不会怀孕但应该挺疼的……而且我不想以一个丑女的模样搞百合。

