---
title: 我不理解为啥有的男生只要被拒绝就一下冷淡了？
url: https://www.zhihu.com/question/1952436405394465046/answer/1956442366891254720
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 19:36
modified: 2025-09-30 19:36
upvote_num: 9
comment_num: 3
---

因为被拒绝了还拎不清的死缠烂打会被女生当成战绩挂朋友圈炫耀呀。

揣着明白装什么糊涂。

![](./assets/v2-2af28da64ca0f8202c2c928cdfa2021f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='673' height='1200'></svg>)

