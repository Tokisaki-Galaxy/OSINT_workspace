---
title: 如何评价穿cos服出门这一行为？
url: https://www.zhihu.com/question/309667373/answer/1955712864867324871
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 19:18
modified: 2025-09-28 19:18
upvote_num: 2
comment_num: 0
---

南京路步行街和五角场到了周末经常能看到各种coser，已经不是什么很稀奇的事情了。

