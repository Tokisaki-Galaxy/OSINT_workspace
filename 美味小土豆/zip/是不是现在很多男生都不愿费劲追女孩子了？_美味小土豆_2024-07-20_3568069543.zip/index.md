---
title: 是不是现在很多男生都不愿费劲追女孩子了？
url: https://www.zhihu.com/question/20373104/answer/3568069543
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-20 18:40
modified: 2024-07-20 18:40
upvote_num: 9
comment_num: 1
---

追女孩本来就不应该费用。

那种自相矛盾的追妹话术追妹手册统统都是没有意义的

两个人相处半天就能清楚是不是能看对眼了

但是为什么现实里不是这样的呢？

因为这样就不能利益最大化了

