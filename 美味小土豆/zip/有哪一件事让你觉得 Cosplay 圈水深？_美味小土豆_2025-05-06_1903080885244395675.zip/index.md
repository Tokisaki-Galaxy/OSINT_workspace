---
title: 有哪一件事让你觉得 Cosplay 圈水深？
url: https://www.zhihu.com/question/267099431/answer/1903080885244395675
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-06 13:37
modified: 2025-05-06 13:38
upvote_num: 2
comment_num: 0
---

c圈有什么水深的，一堆以讹传讹的烂事和满天飞的黄谣。

哦，对，还有各种乱七八糟的yy小故事，末了还要拉踩人家出cos的姑娘一下来显示自己洁身自好伟光正。

