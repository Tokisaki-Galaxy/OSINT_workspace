---
title: 为什么现在的年轻人越来越讨厌人情世故了？
url: https://www.zhihu.com/question/634565708/answer/2006722095606953252
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-16 13:30
modified: 2026-02-16 13:31
upvote_num: 17
comment_num: 0
---

年轻人有年轻人自己的人情世故，小圈子的各种恶臭规矩可比酒桌文化油腻多了。

他们只是不和老登们一起玩罢了。

