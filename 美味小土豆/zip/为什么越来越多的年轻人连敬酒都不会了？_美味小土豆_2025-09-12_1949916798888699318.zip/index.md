---
title: 为什么越来越多的年轻人连敬酒都不会了？
url: https://www.zhihu.com/question/5260681164/answer/1949916798888699318
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 19:26
modified: 2025-09-12 19:26
upvote_num: 3
comment_num: 0
---

我老板从来没教过我要给谁谁谁敬酒

她说别人敬你你就喝，别煞笔兮兮的去给别人敬酒，像个弱智一样。

