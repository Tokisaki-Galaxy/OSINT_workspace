---
title: 一个女的约了三四次约不出来是不是要放弃？
url: https://www.zhihu.com/question/302609076/answer/1951373134658778821
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-16 19:53
modified: 2025-09-16 19:53
upvote_num: 35
comment_num: 6
---

喜欢你的女生，她会想尽办法出来见你的，哪怕她妈不让她出门，她都会企图从四楼阳台翻出来找你。

所以约三次都约不出来就是不喜欢你，不要骗自己了。

