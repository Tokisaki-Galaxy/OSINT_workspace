---
title: 如何看待峰哥评价网友四万块养老婆根本不够，如果是他一个月要给女孩十万？
url: https://www.zhihu.com/question/2010303550102729370/answer/2011069595100915155
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-28 13:25
modified: 2026-02-28 13:32
upvote_num: 70
comment_num: 7
---

真心讲，你们真的是把我这种平时花惯小姑娘钱的废物给看楞了……

真是社会栋梁，厉害。

我以为我和姑娘说我用她的备用机就行不用买苹果我不喜欢苹果已经算是很懂事了。

"你看，果然我没说错吧——这个世界上比我优秀的男人有那么多，你干嘛总是说我是最好的……"

我要开始为总是花光小女孩的零花钱这件事忏悔了。

![](./assets/v2-667410830d0bc763ef9d86cc1594ad84_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1024'></svg>)

