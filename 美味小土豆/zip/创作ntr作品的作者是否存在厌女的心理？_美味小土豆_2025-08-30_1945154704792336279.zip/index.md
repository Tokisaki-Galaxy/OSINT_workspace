---
title: 创作ntr作品的作者是否存在厌女的心理？
url: https://www.zhihu.com/question/9596450619/answer/1945154704792336279
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-30 16:03
modified: 2025-08-30 16:03
upvote_num: 7
comment_num: 0
---

现在的ntr作品都快变成女性向漫画了。

无论主角是主妇还是jk，主打的需求就是"从无聊的日常生活中解放出来，享受极致的堕落和解放，成为强大男性的肉欲工具，散发出纯粹雌性的魅力"。

现在ntr的苦主已经变成一种纯粹的工具人了，主要作用就是压抑女主作为纯粹雌性的美。

如果放在知乎上，就是苦主会一个劲的夸女主是"具有有自尊自爱的品格，适合当贤妻良母"

而女主内心渴望的则是有一个强壮的黄毛能撕下她传统的伪装，掐着她纤细白皙的脖颈轻声的在她的耳边辱骂她，把她纯粹的雌性魅力勾引出来，毫无保留的赤裸裸的暴露在饥渴的肉欲野兽面前。

——不得不说，这很戳一部分女性的g点。

不仅谈不上厌女，ntr作者甚至越来越懂女人了。

![](./assets/v2-3e3cd67bad0663b1b22bb860934d94ab_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-a87a58b2b1f835b66ba7b788b8a2a402_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-ae34336938fbfe7e0d0abf26ccb4a49a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-b4d40e22c0894b75a03b74bc7ce7c9f6_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-7992f3877f609f6af86deb696d22ed75_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-5264baaf0cb127495f16d2bd9a5831f4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

