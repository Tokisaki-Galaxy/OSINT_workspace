---
title: 为什么在古代，几千个忠诚可靠，全副武装的常备军就已经是一股不容小视的力量了？
url: https://www.zhihu.com/question/1923391612840542699/answer/2008517871408525491
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-21 12:26
modified: 2026-02-21 12:26
upvote_num: 97
comment_num: 3
---

实际上，一个人能有五个忠诚可靠的人，就有可能创业成功了。

大部分人可能都不清楚真正的忠诚可靠是什么样子的。

