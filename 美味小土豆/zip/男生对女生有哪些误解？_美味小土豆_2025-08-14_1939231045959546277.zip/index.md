---
title: 男生对女生有哪些误解？
url: https://www.zhihu.com/question/305993367/answer/1939231045959546277
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 07:45
modified: 2025-08-14 07:46
upvote_num: 11
comment_num: 21
---

可能有些男生觉得164的女生45kg已经是骨瘦如柴了。

其实164的女生哪怕39kg也是软软的有肉的，不会像柴火一样。

45kg拍照不p一下小肚子甚至会有一点点鼓。

所以很多女生会有身材焦虑

