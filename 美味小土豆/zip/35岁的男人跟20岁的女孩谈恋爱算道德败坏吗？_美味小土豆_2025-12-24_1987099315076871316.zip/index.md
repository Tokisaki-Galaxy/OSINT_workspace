---
title: 35岁的男人跟20岁的女孩谈恋爱算道德败坏吗？
url: https://www.zhihu.com/question/1986905272749422357/answer/1987099315076871316
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-24 09:56
modified: 2025-12-24 09:56
upvote_num: 10
comment_num: 2
---

为什么你们觉得二十岁的女孩还幼稚？

我觉得有些十四岁的小女孩看待事物已经很成熟很有自己的想法了。

