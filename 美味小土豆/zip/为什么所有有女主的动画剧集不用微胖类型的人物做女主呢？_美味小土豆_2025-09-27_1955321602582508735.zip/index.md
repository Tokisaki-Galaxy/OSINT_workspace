---
title: 为什么所有有女主的动画剧集不用微胖类型的人物做女主呢？
url: https://www.zhihu.com/question/1174028914/answer/1955321602582508735
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 17:23
modified: 2025-09-27 17:23
upvote_num: 6
comment_num: 0
---

古利特就是微胖啊，六花就是肉肉的呀。

![](./assets/v2-3b93caaf3a6f69979541e08e7cf6471a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1536'></svg>)

