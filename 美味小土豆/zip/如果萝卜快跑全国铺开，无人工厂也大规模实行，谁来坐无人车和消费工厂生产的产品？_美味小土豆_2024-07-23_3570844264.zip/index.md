---
title: 如果萝卜快跑全国铺开，无人工厂也大规模实行，谁来坐无人车和消费工厂生产的产品？
url: https://www.zhihu.com/question/661489781/answer/3570844264
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-23 13:32
modified: 2024-07-23 13:32
upvote_num: 4
comment_num: 0
---

工厂不可能100%无人的。很多环节要是硬为了做到无人那要付出的成本会比有人多得多。

其实现在的印刷厂就可以认为是半个无人工厂了。但是配页和某些装订工艺还有校色还是需要人工的。

