---
title: 假设所有游戏都关了，学生们都会学习吗？
url: https://www.zhihu.com/question/386258652/answer/1910098228407440878
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-25 22:21
modified: 2025-05-25 22:21
upvote_num: 3
comment_num: 0
---

笑死，只要有地理课本我能打一个晚上的世界大战。

