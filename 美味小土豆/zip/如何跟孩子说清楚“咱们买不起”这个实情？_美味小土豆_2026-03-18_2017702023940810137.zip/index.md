---
title: 如何跟孩子说清楚“咱们买不起”这个实情？
url: https://www.zhihu.com/question/665451884/answer/2017702023940810137
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-18 20:40
modified: 2026-03-18 20:40
upvote_num: 152
comment_num: 6
---

要看是啥东西。

我小学一年级和我妈说能不能给我一亿元我要买个高架桥放校门口。

我妈就顺理成章的揍了我一顿。

因为我说不给我买我就不去上课了。

