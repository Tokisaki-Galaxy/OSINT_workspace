---
title: 真的能遇到同样喜欢二次元的女孩子吗?
url: https://www.zhihu.com/question/2018689344/answer/1939406693424410646
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 19:23
modified: 2025-08-14 19:23
upvote_num: 6
comment_num: 0
---

能，我和我cp就是漫展认识的。

现在我每周日常就是陪她去各地的漫展，她出cos，我帮忙拍照运营账号顺便陪她出cos

然后一起追新番，一起看有没有什么适合出的新角色。她之前沉迷gqxuuuuuc，最近在追更衣人偶和吊带袜天使。

她最近还在恶补高达，大概是gqxuuuuuc后遗症。所以趁她还有兴趣我一直在噱她出秘书小姐，然后她说她想先出喵安。

