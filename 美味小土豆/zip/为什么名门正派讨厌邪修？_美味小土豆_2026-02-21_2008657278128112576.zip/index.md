---
title: 为什么名门正派讨厌邪修？
url: https://www.zhihu.com/question/1918339764853122116/answer/2008657278128112576
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-21 21:40
modified: 2026-02-21 21:40
upvote_num: 10
comment_num: 1
---

没小孩子老了怎么办?

——你可以找一个比你小30岁的萝莉女朋友，然后让她当你妈妈。

![](./assets/v2-6e522024fd3b9c1450554b484b05a6a0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-6a3b9106e9d1bac80ab20abc72c6f9e8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

