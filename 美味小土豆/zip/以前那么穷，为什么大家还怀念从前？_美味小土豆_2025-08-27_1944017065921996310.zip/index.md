---
title: 以前那么穷，为什么大家还怀念从前？
url: https://www.zhihu.com/question/630854014/answer/1944017065921996310
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-27 12:43
modified: 2025-08-27 12:43
upvote_num: 2
comment_num: 0
---

我爸说他们以前没空调没手机没手机没电脑没游乐园。

每天乐趣就是捞龙虾抓知了看电视里的动画

我觉得这种日子太可怕了

