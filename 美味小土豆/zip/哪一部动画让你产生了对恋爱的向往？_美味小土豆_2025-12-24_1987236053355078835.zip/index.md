---
title: 哪一部动画让你产生了对恋爱的向往？
url: https://www.zhihu.com/question/5776680299/answer/1987236053355078835
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-24 18:59
modified: 2025-12-24 18:59
upvote_num: 7
comment_num: 2
---

schooldays

很莫名其妙对吧

而且我看的还是游戏动画。

那会就觉得言叶和世界都好可爱，为什么不能三个人在一起。

真不知道我当时怎么想的，摸不着头脑。

![](./assets/v2-d073a40af9e0fa6204c5067ee10e5005_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='842' height='1200'></svg>)

  


![](./assets/v2-5f4d7030e6773e58dbb34ae160b4a560_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='842' height='1200'></svg>)

  


![](./assets/v2-a55bbdc9c75e7aeaf268f81e4f3e8dcb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='842' height='1200'></svg>)

  


![](./assets/v2-4ac0e87bda3121063fc09bb48527ddf2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='842' height='1200'></svg>)

