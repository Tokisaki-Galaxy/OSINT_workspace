---
title: 论男性一句「我养你」对女性杀伤力有多大?
url: https://www.zhihu.com/question/615951596/answer/1945401758328283291
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 08:25
modified: 2025-08-31 08:25
upvote_num: 2
comment_num: 0
---

她要喜欢你

你一句"你养我吧"对她杀伤力都大。

她要喜欢你

你说什么杀伤力都大

她得喜欢你啊

