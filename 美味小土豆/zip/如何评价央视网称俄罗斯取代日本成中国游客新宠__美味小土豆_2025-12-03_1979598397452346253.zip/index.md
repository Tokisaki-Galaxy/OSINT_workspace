---
title: 如何评价央视网称俄罗斯取代日本成中国游客新宠?
url: https://www.zhihu.com/question/1978085931559957718/answer/1979598397452346253
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-03 17:10
modified: 2025-12-03 17:10
upvote_num: 10
comment_num: 0
---

我旅游可以不选日本，这没什么的，地球上能玩的地方多了。

但是你和我推荐说俄罗斯比日本更适合旅游？

呃……你这样说我只会觉得你不是个好人。

你是觉得斯拉夫疯狗比小鬼子安全?

