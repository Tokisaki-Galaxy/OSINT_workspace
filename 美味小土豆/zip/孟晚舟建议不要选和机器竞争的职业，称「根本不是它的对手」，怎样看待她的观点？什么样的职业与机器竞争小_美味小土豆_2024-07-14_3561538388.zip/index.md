---
title: 孟晚舟建议不要选和机器竞争的职业，称「根本不是它的对手」，怎样看待她的观点？什么样的职业与机器竞争小？
url: https://www.zhihu.com/question/661481682/answer/3561538388
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 14:13
modified: 2024-07-14 14:13
upvote_num: 1
comment_num: 0
---

进过工厂就知道了，机器不能干得活有很多的。

自动驾驶是一个几十年前就有概念的东西，为啥很多人现在才后知后觉？

