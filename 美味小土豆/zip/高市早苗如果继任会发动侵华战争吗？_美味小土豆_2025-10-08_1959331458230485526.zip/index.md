---
title: 高市早苗如果继任会发动侵华战争吗？
url: https://www.zhihu.com/question/1952452694074692732/answer/1959331458230485526
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-08 18:57
modified: 2025-10-08 18:57
upvote_num: 5
comment_num: 0
---

现在是不是有点后悔日本没有核武器了？

![](./assets/v2-1252f140646221e3a699368633f906d1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-058492568833efd894b9033af4322602_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-6ba2666b5f232ced95b1263db87f9d8b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

我知道很多人应该很想看到下面这一幕。

![](./assets/v2-4c6157a8fcf277a1caa415e60cfd73b9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

