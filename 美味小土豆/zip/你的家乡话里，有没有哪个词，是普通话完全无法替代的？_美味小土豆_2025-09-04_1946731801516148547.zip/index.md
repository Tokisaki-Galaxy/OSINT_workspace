---
title: 你的家乡话里，有没有哪个词，是普通话完全无法替代的？
url: https://www.zhihu.com/question/1931444373846983631/answer/1946731801516148547
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-04 00:30
modified: 2025-09-04 00:30
upvote_num: 0
comment_num: 0
---

上海话

一则戆卵

一则昂三

