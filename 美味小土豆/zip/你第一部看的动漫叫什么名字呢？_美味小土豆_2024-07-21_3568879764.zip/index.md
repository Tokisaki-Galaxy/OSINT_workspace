---
title: 你第一部看的动漫叫什么名字呢？
url: https://www.zhihu.com/question/615777447/answer/3568879764
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 16:57
modified: 2024-07-21 17:09
upvote_num: 1
comment_num: 0
---

第一部要么是海之王子要么是天空之城，应该都在1996年之前。

结果导致了我到现在都对“古代遗迹”的异常兴趣。

