---
title: 现在这个社会，说“男生应该比女生多一点点责任感”还对吗？
url: https://www.zhihu.com/question/1977170258663061186/answer/1985360295120613488
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 14:46
modified: 2025-12-19 14:46
upvote_num: 11
comment_num: 1
---

同胞们，同志们，我们身为人类，全世界兄弟姐妹都是一家人啊。

为什么我们不能一同放弃那该死的责任感呢？

谁爱承担谁去承担，为什么要逼迫对方呢？

都活得轻松一点不好吗？

