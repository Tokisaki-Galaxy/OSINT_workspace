---
title: 你敢穿七八十块钱的鞋子去上班吗?
url: https://www.zhihu.com/question/1900800514670691199/answer/1912415369508925938
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-01 07:49
modified: 2025-06-01 07:49
upvote_num: 0
comment_num: 0
---

我穿15块钱的拖鞋上班……

