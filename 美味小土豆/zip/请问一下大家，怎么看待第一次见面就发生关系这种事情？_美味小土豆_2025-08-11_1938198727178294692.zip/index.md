---
title: 请问一下大家，怎么看待第一次见面就发生关系这种事情？
url: https://www.zhihu.com/question/665375504/answer/1938198727178294692
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-11 11:23
modified: 2025-08-11 11:23
upvote_num: 1
comment_num: 1
---

"不上床？那为什么要浪费时间见我一面呢"

![](./assets/v2-7078ae2c444634d3e6b57c2cdd047a25_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='928' height='1232'></svg>)

