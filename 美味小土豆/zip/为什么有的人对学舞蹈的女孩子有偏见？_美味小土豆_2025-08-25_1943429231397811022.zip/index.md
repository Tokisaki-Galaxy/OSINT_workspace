---
title: 为什么有的人对学舞蹈的女孩子有偏见？
url: https://www.zhihu.com/question/442949671/answer/1943429231397811022
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 21:47
modified: 2025-08-25 21:47
upvote_num: 0
comment_num: 1
---

我对练舞蹈的妹子没有任何偏见

我交往过的练舞蹈的妹子都会说

——要不要试试看一字马~

![](./assets/v2-46cb3110713a263cdac1cffb7aca3251_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='799' height='1070'></svg>)

