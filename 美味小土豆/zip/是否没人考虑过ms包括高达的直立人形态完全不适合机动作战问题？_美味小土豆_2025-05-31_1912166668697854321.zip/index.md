---
title: 是否没人考虑过ms包括高达的直立人形态完全不适合机动作战问题？
url: https://www.zhihu.com/question/1889757393988077264/answer/1912166668697854321
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-31 15:21
modified: 2025-05-31 15:21
upvote_num: 21
comment_num: 0
---

所以机械设定师属于动画行业而不是军工行业呀。

贬低玩具来显摆军事知识真的太low了

