---
title: 请资产千万以上的大佬们，说下你们目前的烦恼？
url: https://www.zhihu.com/question/562228131/answer/1979565198558917509
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-03 14:58
modified: 2025-12-03 14:58
upvote_num: 6
comment_num: 2
---

我目前没有任何烦恼

我很烦恼这一点……

