---
title: 假设你的队伍需要一名精灵去冒险，你选日式精灵，还是西式精灵？
url: https://www.zhihu.com/question/634064434/answer/1956624846344680151
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 07:41
modified: 2025-10-01 07:41
upvote_num: 5
comment_num: 1
---

当然选日式黑暗精灵啦！

身体底子巨好，术士还能当近战。

晚上也很好用。

![](./assets/v2-f748e08ab63d1959b4c52bcb4f5639c1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='768'></svg>)

  


![](./assets/v2-6ec2b9222da0e1e8b87cfd1953a152ba_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='768'></svg>)

  


![](./assets/v2-056fffe0db0a2765c2ef2941d18fb682_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1200'></svg>)

  


![](./assets/v2-ba2db6f099c27aea3317235cc06d7378_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1200'></svg>)

