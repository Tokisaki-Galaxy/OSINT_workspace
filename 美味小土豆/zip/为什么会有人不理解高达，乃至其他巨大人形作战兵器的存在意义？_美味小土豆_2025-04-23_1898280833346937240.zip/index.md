---
title: 为什么会有人不理解高达，乃至其他巨大人形作战兵器的存在意义？
url: https://www.zhihu.com/question/274774608/answer/1898280833346937240
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-23 07:43
modified: 2025-04-23 07:43
upvote_num: 3
comment_num: 0
---

你在设计一台巨大人形兵器的时候如果想的是它应该多么多么合理，那么这台人形兵器绝逼没人买

如果你认为设计一台巨大人形兵器不应该只被当成玩具——那你应该和研究永动机的人坐一桌。

