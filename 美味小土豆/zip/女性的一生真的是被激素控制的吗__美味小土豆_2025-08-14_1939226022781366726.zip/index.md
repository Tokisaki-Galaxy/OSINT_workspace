---
title: 女性的一生真的是被激素控制的吗?
url: https://www.zhihu.com/question/638820603/answer/1939226022781366726
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 07:25
modified: 2025-08-14 07:25
upvote_num: 30
comment_num: 0
---

哪怕像我cp那样精神很稳定的女孩子，来大姨妈的时候都会在自己房间里躲起来，然后发短信给我叫我帮她拿东西或者是准备热水袋或者是拿止疼药什么的放门口。

我说为什么不让我拿进去，她说她会控制不住想生气，所以不要理她就好了……

