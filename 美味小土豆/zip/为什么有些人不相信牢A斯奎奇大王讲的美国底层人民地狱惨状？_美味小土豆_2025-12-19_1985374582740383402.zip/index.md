---
title: 为什么有些人不相信牢A斯奎奇大王讲的美国底层人民地狱惨状？
url: https://www.zhihu.com/question/1983544707767366292/answer/1985374582740383402
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 15:43
modified: 2025-12-19 15:43
upvote_num: 19
comment_num: 2
---

说萨雷姆不是乌托邦，它有属于自己阴暗的一面。

这我信

![](./assets/v2-cc2415fbc0ca80fe05c8348f97e08372_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1081' height='1080'></svg>)

说萨雷姆就是废铁镇，你从小到大都在仰望的人生目标，艰辛万苦粉身碎骨也想要爬上去的天堂，其实是一个比废铁镇还可怕的地狱？

![](./assets/v2-feca770d5263652385cf1e2cebbeb519_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1079' height='1491'></svg>)

这就有点戏剧化了。

我并不完全相信，我从来不信任何我自己没看到没了解的一面之词。

"我以为废铁镇只是杜撰出来的，但是这个世界上真的存在萨雷姆，而现在你告诉我废铁镇也是真实存在的，萨雷姆就是废铁镇？这确实很让大家来情绪，不是嘛我的朋友~"

