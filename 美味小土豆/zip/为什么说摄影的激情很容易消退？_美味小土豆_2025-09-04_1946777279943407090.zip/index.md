---
title: 为什么说摄影的激情很容易消退？
url: https://www.zhihu.com/question/521513485/answer/1946777279943407090
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-04 03:31
modified: 2025-09-04 03:34
upvote_num: 1
comment_num: 0
---

从20年到24年

从明日方舟拍到原神

再从蔚蓝档案再拍到绝区零，

从兔女郎拍到比基尼女仆装，

再从妃咲拍到花凛，

从拍全妆到只拍腿

  


我真的已经厌倦单手举相机一边晃一边拍了

