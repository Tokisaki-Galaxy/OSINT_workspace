---
title: 为什么我完全不能理解独生子女认为父母的就应该是自己的？
url: https://www.zhihu.com/question/411023962/answer/1962205834021942010
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-16 17:18
modified: 2025-10-16 17:18
upvote_num: 6
comment_num: 2
---

我爹妈最大的财产就是我

有我就有一切

所以我是我父母的一切

他们的一切都是我的

这不是理所当然的事情嘛

我过年只要回家我家只要看到我这个人就会很开心了，我的存在本身就能让我爹妈很快乐了。

