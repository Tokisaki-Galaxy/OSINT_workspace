---
title: 你觉得女孩该学习做家务吗？还得学做饭菜吗？
url: https://www.zhihu.com/question/1896852314398115640/answer/2009951726132819097
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-25 11:23
modified: 2026-02-25 11:23
upvote_num: 13
comment_num: 1
---

学不学做家务和你是什么性别没关系的。

她/他发自真心爱你的时候什么事情都会去学习做的。

还在网上为"会不会"而争得面红耳赤的人。

大概率都没谈过什么正经恋爱吧……

