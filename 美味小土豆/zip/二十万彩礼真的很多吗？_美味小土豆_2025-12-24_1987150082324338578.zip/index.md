---
title: 二十万彩礼真的很多吗？
url: https://www.zhihu.com/question/657753054/answer/1987150082324338578
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-24 13:18
modified: 2025-12-24 13:18
upvote_num: 25
comment_num: 0
---

呃……我觉得付钱结婚就是一件很莫名其妙的事情了。

然后你还要问我付20万算不算贵？

我觉得付20块都是很失礼的事情。

我不敢想象我要是对着很爱我的姑娘说"我给你钱，你和我结婚吧"，她会有多生气……

