---
title: 现实中女生之间的关系真的像动画《mygo》里一样复杂吗？
url: https://www.zhihu.com/question/7098133126/answer/2012996575648051799
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-05 21:03
modified: 2026-03-05 21:03
upvote_num: 6
comment_num: 1
---

现实世界里女生们的关系更像非洲大草原的鬣狗群。

