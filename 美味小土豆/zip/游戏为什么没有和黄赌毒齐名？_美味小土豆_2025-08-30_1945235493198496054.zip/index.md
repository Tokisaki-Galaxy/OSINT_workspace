---
title: 游戏为什么没有和黄赌毒齐名？
url: https://www.zhihu.com/question/351089498/answer/1945235493198496054
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-30 21:24
modified: 2025-08-30 21:24
upvote_num: 1
comment_num: 0
---

我10年老猎人新大陆苍蓝星何德何能能和老嫖客老毒虫老赌狗坐一桌啊

