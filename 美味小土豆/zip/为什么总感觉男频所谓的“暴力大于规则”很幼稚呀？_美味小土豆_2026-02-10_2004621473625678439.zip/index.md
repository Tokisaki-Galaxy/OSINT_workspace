---
title: 为什么总感觉男频所谓的“暴力大于规则”很幼稚呀？
url: https://www.zhihu.com/question/2003507717051016419/answer/2004621473625678439
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-10 18:23
modified: 2026-02-10 18:23
upvote_num: 11
comment_num: 0
---

规则也是另一个暴力制定下来的。

你想要改变规则，就必须掌握能和它相对抗的暴力。

这是初中政治课就教过的内容吧？

