---
title: 为什么有些人对女生抽烟有偏见？
url: https://www.zhihu.com/question/1938790897073501951/answer/1941097947577181326
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 11:23
modified: 2025-08-19 11:23
upvote_num: 0
comment_num: 1
---

我觉得女生抽烟好好看，超喜欢女生抽烟

![](./assets/v2-5f2e8a0c5791d4710e50a585200ca051_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

  


![](./assets/v2-94c882e21afdce558b5b777714b319e3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1024'></svg>)

  


![](./assets/v2-91494c2b538c5eaaac33a8a915532f5b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='992' height='1200'></svg>)

  


![](./assets/v2-d4b0eb895e552bd5f636dd9052014477_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

  


![](./assets/v2-9886a298760a60a259b0e5d8499c1b50_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

  


![](./assets/v2-12920d3a972cb1d202a148a57a5fbbec_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1148' height='2048'></svg>)

  


![](./assets/v2-f84efa9101c8ec9e21c020f4470be779_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='928' height='1232'></svg>)

  


![](./assets/v2-d089da027d4a7f9fecce5963e7d14808_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='928' height='1232'></svg>)

  


![](./assets/v2-20f6823beb236ff4a5e6878e58a22b80_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1024'></svg>)

