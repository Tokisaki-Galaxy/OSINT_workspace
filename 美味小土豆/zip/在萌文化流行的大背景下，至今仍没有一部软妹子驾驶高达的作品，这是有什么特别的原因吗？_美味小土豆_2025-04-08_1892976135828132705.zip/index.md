---
title: 在萌文化流行的大背景下，至今仍没有一部软妹子驾驶高达的作品，这是有什么特别的原因吗？
url: https://www.zhihu.com/question/37167186/answer/1892976135828132705
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 16:24
modified: 2025-04-08 16:24
upvote_num: 108
comment_num: 19
---

不算水魔

开陆战g的卡莲，卡莲不是萌妹但也是巨乳美女大姐姐啊

还有开nt1的克里斯，克里斯算漂亮大姐姐吧

还有开zgundam的露露卡

对了，你是不是忽略了uc第一疯批萌萝莉，人家开的可是正经的高达

![](./assets/v2-c00480bcf5e31cf3bc02488a13c9826a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1280' height='1871'></svg>)

