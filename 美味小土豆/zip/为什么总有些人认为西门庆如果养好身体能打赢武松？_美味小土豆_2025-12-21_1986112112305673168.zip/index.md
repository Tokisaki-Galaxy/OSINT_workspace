---
title: 为什么总有些人认为西门庆如果养好身体能打赢武松？
url: https://www.zhihu.com/question/322755077/answer/1986112112305673168
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-21 16:33
modified: 2025-12-21 16:33
upvote_num: 5
comment_num: 4
---

老虎的掌力大约是一吨左右

那么能打死老虎的武松掌力起码也是一吨。

武松身高大约是1米85-2米5之间，平均一下算1米9好了。

也就是说武松的面板和假面骑士空我初生形态是一样的。

你让西门大官人打武松？

你怎么不让蝙蝠怪人去打武松！

![](./assets/v2-ddf360d9d171fa66daaa360fedbff472_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1773' height='2364'></svg>)

