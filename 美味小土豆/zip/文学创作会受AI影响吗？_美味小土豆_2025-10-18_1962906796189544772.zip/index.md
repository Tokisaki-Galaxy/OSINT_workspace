---
title: 文学创作会受AI影响吗？
url: https://www.zhihu.com/question/1954537110850745893/answer/1962906796189544772
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-18 15:44
modified: 2025-10-18 15:44
upvote_num: 2
comment_num: 0
---

以前我觉得呕吐式写文法会让文笔会看起来很幼稚。

ai写文变多以后我发现体验派的呕吐式写作法是一种很宝贵的写作方式。

