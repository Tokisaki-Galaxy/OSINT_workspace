---
title: 一段正常且健康的恋爱应该是什么样子的呢？
url: https://www.zhihu.com/question/595051644/answer/1947479641066537043
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 02:02
modified: 2025-09-06 02:02
upvote_num: 45
comment_num: 0
---

两个人遇到问题的时候会同心协力的一起解决问题，而不是一个人去解决问题另外一个人在一旁抱怨。

