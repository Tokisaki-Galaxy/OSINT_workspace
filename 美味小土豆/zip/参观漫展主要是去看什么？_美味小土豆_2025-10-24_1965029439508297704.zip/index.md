---
title: 参观漫展主要是去看什么？
url: https://www.zhihu.com/question/666404451/answer/1965029439508297704
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-24 12:18
modified: 2025-10-24 12:18
upvote_num: 7
comment_num: 0
---

去漫展重要的不是去看。

而是去给别人看。

