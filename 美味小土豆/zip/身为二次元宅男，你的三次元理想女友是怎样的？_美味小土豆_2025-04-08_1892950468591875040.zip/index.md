---
title: 身为二次元宅男，你的三次元理想女友是怎样的？
url: https://www.zhihu.com/question/64103360/answer/1892950468591875040
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 14:42
modified: 2025-04-08 14:46
upvote_num: 68
comment_num: 11
---

什么都能聊得来的社恐型学霸疯批雌小鬼

讨厌野比大雄，喜欢铁球，会一起玩高达天线猜猜猜，虽然是00后但是会出90年代的冷门动画cos，认得出80年代的三大ova。在她旁边听动画她能反应过来“你在看xxx吧？我也要看我也要看！”

对不起，我好像真的有这样的朋友……

![](./assets/v2-59bc5be22c64f33a03effb0893e0e96d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

  


![](./assets/v2-270f98b4a5df78ba845d7715f2b38fcf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

  


![](./assets/v2-b6cac6251205313643fe897cca2f5773_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

