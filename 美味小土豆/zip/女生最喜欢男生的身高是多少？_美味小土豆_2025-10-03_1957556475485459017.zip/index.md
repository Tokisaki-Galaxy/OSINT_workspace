---
title: 女生最喜欢男生的身高是多少？
url: https://www.zhihu.com/question/363382492/answer/1957556475485459017
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 21:23
modified: 2025-10-03 21:23
upvote_num: 11
comment_num: 3
---

185以上198以下

真的，女人对身高的追求就像在猪市买猪一样。

能多一点都觉得是占了天大的便宜。

