---
title: 怎样把躺平的年轻人拉起来？
url: https://www.zhihu.com/question/665418546/answer/1944383555661694419
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-28 12:59
modified: 2025-08-28 12:59
upvote_num: 0
comment_num: 0
---

没收他们所有的房子，停掉父母的养老金。

