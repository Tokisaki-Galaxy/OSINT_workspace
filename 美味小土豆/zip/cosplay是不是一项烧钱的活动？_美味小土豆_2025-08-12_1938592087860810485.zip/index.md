---
title: cosplay是不是一项烧钱的活动？
url: https://www.zhihu.com/question/1903425478112548221/answer/1938592087860810485
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 13:26
modified: 2025-08-12 13:26
upvote_num: 0
comment_num: 0
---

要是出冷门角色衣服道具不能回血那就很烧钱了。哪怕闲鱼上买也要500左右的。加上门票吃饭车费妆娘，一天900就没了。

