---
title: 为什么做生意的都说生意不好做?
url: https://www.zhihu.com/question/638143974/answer/3550066187
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-03 13:58
modified: 2024-07-03 13:58
upvote_num: 11
comment_num: 0
---

说生意好做甲方就会压价，朋友就会借钱，员工就会要求涨工资，还会有你这样想进来分一杯羹的朋友，百害而无一利。

况且如果对方这么说不挣钱了你还是要入局的话，那你亏光了就不是别人的错了。

