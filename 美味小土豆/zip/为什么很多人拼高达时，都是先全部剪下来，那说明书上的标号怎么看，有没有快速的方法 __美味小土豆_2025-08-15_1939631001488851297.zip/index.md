---
title: 为什么很多人拼高达时，都是先全部剪下来，那说明书上的标号怎么看，有没有快速的方法 ?
url: https://www.zhihu.com/question/567596814/answer/1939631001488851297
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 10:14
modified: 2025-08-15 10:14
upvote_num: 2
comment_num: 0
---

我拼过将近30盒老hg的eva了，现在都不敢全剪下来再拼。

