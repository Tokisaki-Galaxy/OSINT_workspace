---
title: 你什么时候意识到自己没见过世面？
url: https://www.zhihu.com/question/49019714/answer/3605000812
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 23:14
modified: 2024-08-24 23:14
upvote_num: 3
comment_num: 0
---

“握草歼十那么大？啊？！”

“握草这是歼11？太恐怖了！”

“握草握草握草这是轰六？我踏马的！牛逼牛逼牛逼！和自然博物馆的恐龙一样哎！”

我朋友：“求求你了你个土鳖别再说了啊啊啊啊”

