---
title: 男人的快乐有多简单？
url: https://www.zhihu.com/question/266275474/answer/1892004117666304622
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-06 00:02
modified: 2025-12-05 16:32
upvote_num: 64
comment_num: 1
---

我发现很多男人都有这个行为，包括我自己

——你不去搭理他们让他们自己找事干的时候，他们就会边干边切到自动播放模式，开始哼歌，而且会越哼越开心。

快乐就那么简单。

