---
title: 男生会跟主动但不喜欢的女生发生关系吗?
url: https://www.zhihu.com/question/1933457633408419523/answer/1942119926799262879
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-22 07:04
modified: 2025-08-22 07:04
upvote_num: 2
comment_num: 1
---

不会

我喜欢瘦的，黑皮，长细腿，好看的女生

我不喜欢的一定是我觉得不好看的。

我还是希望能吃好一点。

