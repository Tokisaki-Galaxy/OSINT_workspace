---
title: 你为什么要坚持运动？
url: https://www.zhihu.com/question/657833184/answer/3610309431
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-30 04:00
modified: 2024-08-30 04:00
upvote_num: 2
comment_num: 0
---

运动很开心呀。尤其是跑步，跑步跑完会让人很有自信。

一种很神奇的体验

尤其是当你的同龄人已经被痛风，高血压，骨质疏松所困扰。

而你还能在校园里超越下那些年轻的运动少女们时。

这种体验真得很棒！

![](./assets/v2-2f24980d202bc14efacc75dfd75c354b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='975'></svg>)

  


![](./assets/v2-0eff0f85f4988a20725589654957ea43_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='975'></svg>)

  


![](./assets/v2-e5e9af5c50cdbc7ba0c49b814631d578_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='975'></svg>)

  


![](./assets/v2-3e806a9e228a7213ee02f1fcc4f3d671_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='975'></svg>)

