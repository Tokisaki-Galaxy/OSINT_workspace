---
title: 为什么有些男性认为追求女性只需要付出和诚意就够了？
url: https://www.zhihu.com/question/1988397724060648010/answer/1988640004466033412
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-28 15:58
modified: 2025-12-28 15:58
upvote_num: 11
comment_num: 3
---

否则呢？难道你要告诉他们其实被爱是没有任何道理的，喜欢你就是喜欢你，没人喜欢你怎么努力都没用的，网上所有怎么教你谈恋爱的教程都是废话，任何人的恋爱经验都只适用于他自己，被爱就是个纯玄学，不存在任何解题思路也没有标准答案，和努力更是没有任何关系吗？

会挨揍的哦

![](./assets/v2-6f103234eb235361c9161c7cc1df13cd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='1024'></svg>)

