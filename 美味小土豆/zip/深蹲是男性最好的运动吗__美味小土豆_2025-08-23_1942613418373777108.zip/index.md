---
title: 深蹲是男性最好的运动吗?
url: https://www.zhihu.com/question/1921198234367399209/answer/1942613418373777108
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 15:45
modified: 2025-08-23 15:46
upvote_num: 8
comment_num: 1
---

首先……我不知道。

其次，以前田径队每天都要求深蹲和倒吊在攀爬架上做仰卧起坐。

后来交往过的妹子都会骂我是牲口

哭着骂的

抓着床单骂的

蹬着黑丝小脚一边求饶一边骂的

都有

还有就是我膝盖很容易拉伤。

