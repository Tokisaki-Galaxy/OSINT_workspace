---
title: 为什么很多军事爱好者认为军事宅推崇的机甲不如现实的飞机坦克？
url: https://www.zhihu.com/question/26722162/answer/3597548934
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-17 17:36
modified: 2024-08-17 17:36
upvote_num: 3
comment_num: 0
---

我本职就是做机械设定的，大型人形兵器要是有哪怕一丁点军事实用化的可能我现在都不会是“玩具设计师”！

