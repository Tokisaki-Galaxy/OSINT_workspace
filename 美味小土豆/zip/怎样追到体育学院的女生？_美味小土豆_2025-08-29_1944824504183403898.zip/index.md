---
title: 怎样追到体育学院的女生？
url: https://www.zhihu.com/question/406594048/answer/1944824504183403898
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-29 18:11
modified: 2025-08-29 18:12
upvote_num: 10
comment_num: 0
---

比她跑的快

这招有奇效

当年我两个田径队女友都是用这个办法追到的

