---
title: 为什么网上拼使劲抨击彩礼，现实里面又不抗争到底？
url: https://www.zhihu.com/question/9357162469/answer/1938440188377432623
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 03:22
modified: 2025-08-12 03:22
upvote_num: 0
comment_num: 0
---

我310我抗争啥

