---
title: 是我太计较还是男生真的不懂情绪价值？
url: https://www.zhihu.com/question/1932810216677840020/answer/2001987435119273139
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 11:56
modified: 2026-02-03 11:56
upvote_num: 8
comment_num: 0
---

"本来就超烦躁"

"瞬间火大"

"现在还在冷战中"

——你这个人完全一点点的情绪价值都没有，怎么好意思疯狂向别人索要情绪价值的……

