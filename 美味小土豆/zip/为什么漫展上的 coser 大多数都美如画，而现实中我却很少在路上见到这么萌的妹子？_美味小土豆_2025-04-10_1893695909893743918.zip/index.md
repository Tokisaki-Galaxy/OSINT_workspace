---
title: 为什么漫展上的 coser 大多数都美如画，而现实中我却很少在路上见到这么萌的妹子？
url: https://www.zhihu.com/question/266626088/answer/1893695909893743918
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-10 16:04
modified: 2025-04-10 16:04
upvote_num: 3
comment_num: 0
---

来上海南京路步行街，双休日路上萌妹子一堆。

