---
title: 在中国搭讪有多难？？
url: https://www.zhihu.com/question/31376553/answer/1940795984008425632
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 15:23
modified: 2025-08-18 15:23
upvote_num: 13
comment_num: 1
---

你万圣节穿身好点的西装打扮阿鲁卡多去南京路发南瓜棒棒糖。

可以搭讪到很多姑娘。

