---
title: 如何判断一个人是上海人？
url: https://www.zhihu.com/question/529098791/answer/1939750066614150393
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 18:07
modified: 2025-08-15 18:07
upvote_num: 2
comment_num: 2
---

踢他一脚，看他开口是不是"册那"或者"娘额逼"。

