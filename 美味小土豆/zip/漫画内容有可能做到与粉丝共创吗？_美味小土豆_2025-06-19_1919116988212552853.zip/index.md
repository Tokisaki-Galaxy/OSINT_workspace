---
title: 漫画内容有可能做到与粉丝共创吗？
url: https://www.zhihu.com/question/1898031655790305823/answer/1919116988212552853
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-19 19:39
modified: 2025-06-19 19:39
upvote_num: 9
comment_num: 0
---

那么这些粉丝瞬间就会变成作者的甲方

几百几千个甲方，还各自有各自的想法

想想就恐怖

