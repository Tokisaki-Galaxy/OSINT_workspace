---
title: 当下的经济形势，你更倾向于创业还是打工？为什么？
url: https://www.zhihu.com/question/655918561/answer/1955385342107559185
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 21:36
modified: 2025-09-27 21:36
upvote_num: 2
comment_num: 0
---

创业是自杀，打工是慢性自杀。

我选择吃软饭

