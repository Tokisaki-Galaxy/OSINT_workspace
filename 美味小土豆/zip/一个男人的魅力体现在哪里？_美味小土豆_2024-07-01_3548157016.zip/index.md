---
title: 一个男人的魅力体现在哪里？
url: https://www.zhihu.com/question/266276255/answer/3548157016
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-01 18:12
modified: 2024-07-01 18:12
upvote_num: 0
comment_num: 0
---

穿着油污的工作服拆歼10航炮管的时候。

