---
title: 3D打印出来的零件结实耐用不？
url: https://www.zhihu.com/question/650888361/answer/3558509467
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 13:18
modified: 2024-07-11 13:18
upvote_num: 0
comment_num: 0
---

3D打印零件的强度比不上环氧树脂。你用这个标准去类比就行了

