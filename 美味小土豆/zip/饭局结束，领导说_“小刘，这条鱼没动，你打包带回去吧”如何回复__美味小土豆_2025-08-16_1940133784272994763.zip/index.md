---
title: 饭局结束，领导说:“小刘，这条鱼没动，你打包带回去吧”如何回复?
url: https://www.zhihu.com/question/614393859/answer/1940133784272994763
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 19:32
modified: 2025-08-16 19:32
upvote_num: 1
comment_num: 0
---

我以前在公司年纪最小，他们什么好饭菜都会让我打包。

当然是说谢谢然后愉快的带走呀

