---
title: 工业克苏鲁什么意思?
url: https://www.zhihu.com/question/648573938/answer/1928714961993073165
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-16 07:18
modified: 2025-07-16 07:18
upvote_num: 2
comment_num: 0
---

很多对第三世界国家来说很急需的小型军用设备制造厂。在中国，淘宝上就能攒出来大部分的制造设备和材料，还不贵。

