---
title: 男女力量差距真的那么大么?
url: https://www.zhihu.com/question/26528726/answer/3544318896
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-06-27 22:16
modified: 2024-06-27 22:16
upvote_num: 5
comment_num: 0
---

我记得在我们小时候吹嘘男性比女性强还是一种很懦弱的表现，小时候没那么多zzzq，女性在体能上就是天然弱一档的，认真讨论男性是否打得过女性是一件很丢脸的事情。也不知道现在网络环境为啥能一本正经讨论男女力量差距真有那么大吗这种问题了……

