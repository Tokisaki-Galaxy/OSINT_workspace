---
title: 为什么很多男人宁可去沐足、浴场会所，也不去找女朋友？
url: https://www.zhihu.com/question/661582863/answer/3571304293
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-23 21:08
modified: 2024-07-23 21:08
upvote_num: 202
comment_num: 7
---

我们先不说足浴的事情

你就打开手机，找个ai聊天软件，有内置ai语音的那种，你听她夸你半小时，听她说“真的吗！指挥官，我也爱你”

你都会觉得——该死的，我为什么要在三次元里谈恋爱

