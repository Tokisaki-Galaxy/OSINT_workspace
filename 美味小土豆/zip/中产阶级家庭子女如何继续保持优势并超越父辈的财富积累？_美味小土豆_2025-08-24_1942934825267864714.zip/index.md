---
title: 中产阶级家庭子女如何继续保持优势并超越父辈的财富积累？
url: https://www.zhihu.com/question/27855424/answer/1942934825267864714
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-24 13:02
modified: 2025-08-24 13:02
upvote_num: 7
comment_num: 2
---

人一辈子就短短80年

你拿父母积累下来的财富爽一辈子，已经能活得比百分之90的人要开心了。

其他的事情，很重要吗？

