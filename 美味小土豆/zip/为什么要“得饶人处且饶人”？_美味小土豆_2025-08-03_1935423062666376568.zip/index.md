---
title: 为什么要“得饶人处且饶人”？
url: https://www.zhihu.com/question/54330855/answer/1935423062666376568
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-03 19:33
modified: 2025-08-03 19:33
upvote_num: 1
comment_num: 0
---

"你要是弄不死他，那就别弄他"

