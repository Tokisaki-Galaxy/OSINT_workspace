---
title: 为什么别人一眼就知道你是老实人?
url: https://www.zhihu.com/question/644979426/answer/1965719574977687914
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 10:01
modified: 2025-10-26 10:01
upvote_num: 43
comment_num: 16
---

md，那我倒想知道了，为什么我明明在哪里都很有礼貌，态度也很好，偏偏经常有老登对我说"你这个人不真诚"……

