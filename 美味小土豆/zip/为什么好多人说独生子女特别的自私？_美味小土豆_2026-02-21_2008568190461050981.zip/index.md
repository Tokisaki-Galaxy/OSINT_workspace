---
title: 为什么好多人说独生子女特别的自私？
url: https://www.zhihu.com/question/562238943/answer/2008568190461050981
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-21 15:46
modified: 2026-02-21 15:46
upvote_num: 38
comment_num: 3
---

独生子女没有"我的食物要分你一半"的分享概念。

我的就是我自己一份的，你想要我给你多买一份。

