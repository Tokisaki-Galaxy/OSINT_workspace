---
title: 今天被一句话整破防了：“也许你老公从没爱过你，只是当年他没有更好的选择而已”，这是真的吗？
url: https://www.zhihu.com/question/1892358245798102033/answer/1988171722319471891
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-27 08:57
modified: 2025-12-27 08:57
upvote_num: 4
comment_num: 0
---

所谓"结婚不要找太漂亮的"

不就是这个意思嘛

这句话真的是谁信谁傻逼

