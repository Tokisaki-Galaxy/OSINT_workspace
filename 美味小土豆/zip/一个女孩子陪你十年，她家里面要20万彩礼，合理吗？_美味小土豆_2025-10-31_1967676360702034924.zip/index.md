---
title: 一个女孩子陪你十年，她家里面要20万彩礼，合理吗？
url: https://www.zhihu.com/question/533879429/answer/1967676360702034924
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-31 19:36
modified: 2025-10-31 19:36
upvote_num: 35
comment_num: 1
---

假如我陪了一个女孩十年，四舍五入我至少放弃了100个女孩

为什么我还要给她钱?

你们成天都在问些什么不讲道理的问题啊

