---
title: 在男性平均身高越来越高的情况下，完美身高185是否跌落神坛，190成为完美身高？
url: https://www.zhihu.com/question/492940786/answer/1945577722068862577
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 20:04
modified: 2025-08-31 20:04
upvote_num: 9
comment_num: 2
---

190身高目前还属于"我还没试过190的！让我试一试"的程度。

大概和臭豆腐榴莲坐一桌。

