---
title: 你会仅因为女朋友要十万多的彩礼，而转头花十多万去娶相亲女吗？
url: https://www.zhihu.com/question/1975521137170609369/answer/1989663038995988801
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-31 11:43
modified: 2025-12-31 11:43
upvote_num: 14
comment_num: 1
---

如果你都混到连结婚都要花钱的逼样了，那么这个破婚是非结不可吗？

都问你要十万，是女朋友还是相亲女有区别吗？

这口气争到最后你还是花钱买老婆。

娶谁有区别吗？

