---
title: 电影《美人鱼》的派对美女，为了获得一块价值区区800万的手表，纷纷跳进游泳池抢夺，她们不觉得丢人吗？
url: https://www.zhihu.com/question/2008322085559243530/answer/2010816704788329950
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 20:41
modified: 2026-02-27 20:42
upvote_num: 13
comment_num: 2
---

别说八百万，给八万块钱我就能让你见识一下前游泳队员潜水捞手表的绝活

