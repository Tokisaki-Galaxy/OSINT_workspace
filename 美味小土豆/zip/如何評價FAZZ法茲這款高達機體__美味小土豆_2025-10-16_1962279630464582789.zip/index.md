---
title: 如何評價FAZZ法茲這款高達機體?
url: https://www.zhihu.com/question/2449773605/answer/1962279630464582789
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-16 22:12
modified: 2025-10-16 22:15
upvote_num: 47
comment_num: 8
---

这玩意就是符合0089年科技的，套了个高达壳子的舰炮级钢加农。

应该和公牛坐一桌

![](./assets/v2-af2589aeba4520fb348392b4b8e26dec_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='765' height='1197'></svg>)

  


它擅长的是精准炮击。

本星舰队估计也是被它的外观给唬住了，居然会呼叫这支炮击小队去迎击一架准塞可缪型的小型化精神力高达。

只能说本星舰队的蠢货既不了解fazz还不认识mkv。

ps:法兹的炮击能力在uc0089年也堪称逆天，搭配ex-s和z+本来就应该是天下无敌的。埃尔斯攻防战能被本星舰队打成这个样子，已经属于很烂了。

