---
title: 都说身高高的男生受欢迎，但我188cm为什么从来没有异性注意过我?
url: https://www.zhihu.com/question/507411884/answer/1945883698542150047
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 16:20
modified: 2025-09-01 16:20
upvote_num: 16
comment_num: 3
---

我和你说，长得高又不好看的男生

在女生眼里会比正常身高的男生更丑

因为她们是从下往上看你的，这是个颜值死亡角度

