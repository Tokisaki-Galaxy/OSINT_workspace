---
title: 如何评价百度贴吧“新男权吧”？
url: https://www.zhihu.com/question/6879057422/answer/1955637473829978927
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 14:18
modified: 2025-09-28 14:18
upvote_num: 6
comment_num: 2
---

女拳会千方百计想着怎么去压榨男人

而男人即使打拳也不会去琢磨怎么让女人出钱出人。

你能相信女拳说出"大不了我就花钱找男人"这种话吗？

男拳就觉得自己说出"大不了我花钱找女人"，就已经是邪恶透顶了。

有点可爱。

