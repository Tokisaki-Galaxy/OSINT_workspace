---
title: 外国人如何看待中国人一定要吃热饭的习俗？
url: https://www.zhihu.com/question/1936124024263513900/answer/1949553195517974293
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-11 19:21
modified: 2025-09-11 19:21
upvote_num: 13
comment_num: 1
---

兄弟连小说里，每次他们从前线撤回来，听到的最治愈的一句话就是

"去洗个热水澡，吃个热餐吧"

