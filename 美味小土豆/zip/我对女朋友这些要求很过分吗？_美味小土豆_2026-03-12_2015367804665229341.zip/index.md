---
title: 我对女朋友这些要求很过分吗？
url: https://www.zhihu.com/question/656580157/answer/2015367804665229341
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-12 10:05
modified: 2026-03-12 10:05
upvote_num: 35
comment_num: 2
---

那你干脆把她脚踝锁起来，让她在家里不许穿衣服，腿上帮个郊狼，平时不接你电话你就电她，没收她的房门钥匙，把她微信里的男性朋友都删光么好了。

反正也没什么本质区别了。

