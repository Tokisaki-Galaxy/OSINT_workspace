---
title: 如何看待“开私人飞机的富人不带头环保，我一普通人为啥要环保”的观念？
url: https://www.zhihu.com/question/989978881/answer/9837285387
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-10-20 05:06
modified: 2024-10-20 05:06
upvote_num: 5
comment_num: 0
---

一个普通人就算不环保，只要他不违法乱纪，正常生活，又能对地球造成多大的伤害呢？

