---
title: 追求一个女的，一年多了。对方一直不愿意和我交往。我不想追了。但是还是不甘心怎么办?
url: https://www.zhihu.com/question/1955896057671160785/answer/1956454989217138000
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 20:26
modified: 2025-09-30 20:26
upvote_num: 5
comment_num: 6
---

你早就不喜欢她了。你只是放不下自己的沉默成本。

要不你和她吵一架吧，虽然很可笑但总比你将来想起来就会懊恼要好。

