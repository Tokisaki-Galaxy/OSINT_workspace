---
title: 到底什么是聊骚?
url: https://www.zhihu.com/question/2442878166/answer/1928764945522235320
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-16 10:36
modified: 2025-07-16 10:36
upvote_num: 0
comment_num: 0
---

"卡着一种很奇怪的声线变换100种方式声情并茂的辱骂对方……"

