---
title: 这样的画真的不值1r吗？
url: https://www.zhihu.com/question/606863235/answer/1932423688906572379
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-26 12:55
modified: 2025-07-26 12:55
upvote_num: 3
comment_num: 0
---

哎！你画的很有特色啊!颜色和线条都很有个人特点。

以这张画来说我愿意开300。

加油画下去啊！真的还蛮期待你以后会画成什么样子的

