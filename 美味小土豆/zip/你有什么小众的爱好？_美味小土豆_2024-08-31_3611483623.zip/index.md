---
title: 你有什么小众的爱好？
url: https://www.zhihu.com/question/21510834/answer/3611483623
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-31 10:07
modified: 2024-08-31 10:07
upvote_num: 7
comment_num: 0
---

收集各种二次元角色的鞋子，还有jk制服的小领结。

就是觉得做工好的cos鞋很漂亮很可爱。比如高雄赛车女郎的白色高跟鞋，褐色光亮漆皮的方头jk小皮鞋，凯尔希的那个一半透明的高跟鞋。

还有jk制服的小领结，感觉特别可爱，所以各类颜色的收集了好多款

算是一种周边收藏吧

所以朋友现在每次展结束都直接把鞋和衣服直接给我了

![](./assets/v2-2d6d0177b99531e26fee9a6cb34330ef_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

