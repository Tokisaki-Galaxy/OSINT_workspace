---
title: 怎么做好Cosplay摄影？
url: https://www.zhihu.com/question/21518480/answer/1955329883883440111
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 17:56
modified: 2025-09-27 18:16
upvote_num: 13
comment_num: 1
---

别老是忘记带鞋子

彩瞳前一天晚上一定要记得放进包里，这东西巨容易掉。

千万记得提醒她不要前一天晚上才修假毛。

私房照一定要用单独的卡。

展前那晚不要把新衣服弄脏！c服是不太能过水的！

出兔女郎的话多备两双丝袜，如果钩丝了特别明显。

![](./assets/v2-f0c90806d579d7d95c3c6f337aa7a453_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='801' height='1200'></svg>)

