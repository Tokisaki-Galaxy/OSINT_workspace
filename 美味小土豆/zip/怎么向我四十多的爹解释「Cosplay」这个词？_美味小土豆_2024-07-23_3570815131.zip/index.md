---
title: 怎么向我四十多的爹解释「Cosplay」这个词？
url: https://www.zhihu.com/question/614209520/answer/3570815131
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-23 13:03
modified: 2024-07-23 13:03
upvote_num: 177
comment_num: 4
---

我上初中的外甥问我知不知道什么是cosplay

我给他看了我手机里小女友出的小鸟女警和花凛原皮

然后我现在每年又要多带一个人去漫展了

