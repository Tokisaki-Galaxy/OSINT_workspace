---
title: 李在明提议建设首尔到北京的高铁，为什么我们反而不提这事了？
url: https://www.zhihu.com/question/1988185121870864953/answer/1989293981838894646
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-30 11:17
modified: 2025-12-30 11:17
upvote_num: 261
comment_num: 35
---

不是有人提议过把渤海湾围起来变成淡水湖吗？

这下好了，有两全其美的法子了。

![](./assets/v2-4f700121f23dc1205a1563103ae58198_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='904' height='614'></svg>)

