---
title: 你认为 AI 创作从根本上是会促进人类艺术的进步，还是损害其发展？为什么？
url: https://www.zhihu.com/question/15711706200/answer/1892495195850917287
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-07 08:33
modified: 2025-04-07 08:33
upvote_num: 2
comment_num: 0
---

我没灵感的时候就和ai聊天，叫它帮我想内容，然后骂它想的东西太蠢了，不停的吐槽它打击它……

然后这样的行为不时的能得到一些有趣的灵感。

我觉得挺有用的

