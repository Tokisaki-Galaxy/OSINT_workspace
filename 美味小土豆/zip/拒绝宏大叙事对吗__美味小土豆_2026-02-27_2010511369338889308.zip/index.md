---
title: 拒绝宏大叙事对吗?
url: https://www.zhihu.com/question/1971131360895828508/answer/2010511369338889308
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 00:27
modified: 2026-02-27 00:27
upvote_num: 13
comment_num: 2
---

应该关心一下的。

如果哪天，你身边的所有人都在狂热的输出宏大叙事。

那就说明应该收拾细软跑路了。

如果没有，那不要和对方起争执就行了。

