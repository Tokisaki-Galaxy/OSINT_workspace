---
title: 真正的上海本地人是不是只剩下没多少了？到不久远的将来就要被彻底换种了？
url: https://www.zhihu.com/question/1942181447021606635/answer/1942594077024559804
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 14:28
modified: 2025-08-23 14:28
upvote_num: 3
comment_num: 0
---

上海人都融不进本地人圈子，外面来的还想着换种？

