---
title: 如果国家不禁止黄，女性最怕哪种后果  ？
url: https://www.zhihu.com/question/1950923401221870851/answer/1952088650675369948
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-18 19:16
modified: 2025-09-18 19:16
upvote_num: 4
comment_num: 0
---

"那就没办法通过举报把服务更好价格更低的给封杀了"

