---
title: 健身爱好者需要禁欲吗？
url: https://www.zhihu.com/question/10503521324/answer/2015797426636747808
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-13 14:32
modified: 2026-03-13 14:32
upvote_num: 49
comment_num: 2
---

当过运动员就知道了，教练只会和你说"晚上放几次，集中精神"，而不会和你说"憋着"。

