---
title: 你为什么不追女生？
url: https://www.zhihu.com/question/346881155/answer/1937098170736808199
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-08 10:29
modified: 2025-08-08 10:29
upvote_num: 3
comment_num: 0
---

不要去追对你没有好感的女孩子

