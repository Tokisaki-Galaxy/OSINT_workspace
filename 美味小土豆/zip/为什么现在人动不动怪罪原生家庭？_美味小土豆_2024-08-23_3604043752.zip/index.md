---
title: 为什么现在人动不动怪罪原生家庭？
url: https://www.zhihu.com/question/657416948/answer/3604043752
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-23 22:05
modified: 2024-08-23 22:05
upvote_num: 12
comment_num: 0
---

看完这个回答我只有一个感想

好父母带出来的小孩和坏父母带出来的小孩简直像两个物种一样，他们本质上是无法交流和共情的。

