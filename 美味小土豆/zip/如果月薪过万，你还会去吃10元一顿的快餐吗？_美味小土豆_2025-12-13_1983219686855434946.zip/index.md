---
title: 如果月薪过万，你还会去吃10元一顿的快餐吗？
url: https://www.zhihu.com/question/1952199622438150237/answer/1983219686855434946
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-13 17:00
modified: 2025-12-13 17:00
upvote_num: 10
comment_num: 0
---

口袋里有钱就不能吃牛肉拉面和臭豆腐了吗？(இωஇ )

