---
title: 为什么对于「贞洁」的网络讨论，几乎都针对女性？ 在国外也是吗？
url: https://www.zhihu.com/question/1900519729451468544/answer/2015369975888625843
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-12 10:14
modified: 2026-03-12 10:14
upvote_num: 7
comment_num: 0
---

因为女人能生孩子呀，这么简单的问题。

不考虑后代的话，贞洁本来就没有意义了。

