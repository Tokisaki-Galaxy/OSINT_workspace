---
title: 为什么说不要在慢热的女生身上浪费时间？
url: https://www.zhihu.com/question/12700448031/answer/1915750573803800559
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-10 12:42
modified: 2025-06-10 12:42
upvote_num: 0
comment_num: 0
---

她不是慢热，只是不喜欢你

