---
title: 和女朋友出去全是我花钱，感觉心里不舒服怎么办？
url: https://www.zhihu.com/question/385887871/answer/1967796501251072438
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-01 03:34
modified: 2025-11-01 03:34
upvote_num: 6
comment_num: 0
---

你这个性转一下不就是中年穷逼白嫖女大生还要对方出钱养他的嘛。

是不是听起来就很搞笑了？

你要再贱一点不如考虑卖屁股赚钱给她花。

