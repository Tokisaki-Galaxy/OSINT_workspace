---
title: 80年代的国营饭店“绝不无故殴打顾客”是否属实？
url: https://www.zhihu.com/question/411534421/answer/1978906231839168308
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 19:20
modified: 2025-12-01 19:20
upvote_num: 1287
comment_num: 22
---

你现在去黄浦区的德兴馆总店，还能体验到九十年代国营饭店的余晖。

我们上海老阿姨就是这么硬气。

