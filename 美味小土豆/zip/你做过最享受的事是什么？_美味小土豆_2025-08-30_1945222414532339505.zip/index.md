---
title: 你做过最享受的事是什么？
url: https://www.zhihu.com/question/1932754116104398665/answer/1945222414532339505
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-30 20:32
modified: 2025-08-30 20:32
upvote_num: 16
comment_num: 2
---

没有压力的一天。

一个人

傍晚时分

脱光了衣服

躺在酒店

一打冰啤酒，一打海鲜拼盘，一盒三文鱼，一盒甜虾。

一部搞笑电影

真的舒服

