---
title: 为什么现在感觉和女生聊天特别的累？
url: https://www.zhihu.com/question/304173290/answer/1949930526170383467
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 20:21
modified: 2025-09-12 20:21
upvote_num: 73
comment_num: 3
---

有没有可能，纯聊天就是很累

有没有可能，追姑娘就不应该纯聊天开局。

你们应该反思的是到底是什么时候被pua的应该聊天开局这个思想钢印的

