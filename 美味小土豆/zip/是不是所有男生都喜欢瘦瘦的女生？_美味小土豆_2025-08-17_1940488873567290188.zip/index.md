---
title: 是不是所有男生都喜欢瘦瘦的女生？
url: https://www.zhihu.com/question/1939259808189490233/answer/1940488873567290188
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 19:03
modified: 2025-08-17 19:03
upvote_num: 92
comment_num: 31
---

对不起。

我真的很喜欢那种164高，40kg重，小腿和我手臂一样粗，手臂纤细得仿佛一折就断的小鸟腿美少女。

出cos真的好看！

