---
title: 怎么样判断一个女生能不能追?
url: https://www.zhihu.com/question/665558069/answer/1961835153895686697
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-15 16:45
modified: 2025-10-15 16:45
upvote_num: 39
comment_num: 0
---

她愿不愿意靠在你身上?

她愿不愿意牵着你的手过马路？

她愿不愿意坐在你腿上和你聊天?

她愿不愿意带着钱找你出来玩？

她愿不愿意整晚陪你在马路上溜达聊天?

如果都愿意

那你们就可以拉扯一下了

