---
title: 体育生被踢裆后有机会反抗吗？
url: https://www.zhihu.com/question/1939096444708577300/answer/1953834041523565638
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-23 14:52
modified: 2025-09-23 14:52
upvote_num: 19
comment_num: 1
---

什么体质的裆都受不了全力一脚啊。

我被踢到的话至少有三秒钟的硬直，这种时候你只要别追加倒地连击就一定能跑掉，否则被我抓住的话……

我还是能反击的。

