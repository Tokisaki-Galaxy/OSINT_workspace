---
title: 假设女性能够完全做到经济独立、思想独立，那要男性来干什么？
url: https://www.zhihu.com/question/1900271409474811272/answer/1945795758088511522
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 10:30
modified: 2025-09-01 10:30
upvote_num: 5
comment_num: 0
---

我也希望女性能真的思想独立经济独立。

把男人解放出来。

他们口袋里的钱有很多人想赚~

集美们口袋里的钱也别藏着掖着~

