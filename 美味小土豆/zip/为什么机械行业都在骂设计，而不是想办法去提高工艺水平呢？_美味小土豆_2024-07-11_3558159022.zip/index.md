---
title: 为什么机械行业都在骂设计，而不是想办法去提高工艺水平呢？
url: https://www.zhihu.com/question/647838663/answer/3558159022
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 08:19
modified: 2024-07-11 08:19
upvote_num: 1
comment_num: 10
---

因为生产很清楚的知道什么事情做不到。而设计通常觉得自己无所不能

