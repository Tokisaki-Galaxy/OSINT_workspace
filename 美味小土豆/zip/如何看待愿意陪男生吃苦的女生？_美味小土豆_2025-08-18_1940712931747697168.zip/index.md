---
title: 如何看待愿意陪男生吃苦的女生？
url: https://www.zhihu.com/question/657727595/answer/1940712931747697168
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 09:53
modified: 2025-08-18 09:53
upvote_num: 35
comment_num: 1
---

她不是愿意吃苦

她只是觉得和你在一起无论怎么样都很开心。

这种女孩不好好珍惜会遭雷劈的。

