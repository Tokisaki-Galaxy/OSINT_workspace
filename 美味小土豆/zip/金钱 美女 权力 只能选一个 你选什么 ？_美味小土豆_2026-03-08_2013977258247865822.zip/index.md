---
title: 金钱 美女 权力 只能选一个 你选什么 ？
url: https://www.zhihu.com/question/2013445671940805507/answer/2013977258247865822
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-08 13:59
modified: 2026-03-08 13:59
upvote_num: 5
comment_num: 1
---

美女

为什么你们默认一个美女不能拥有金钱和权利？

