---
title: 禁止早恋有什么好处吗？
url: https://www.zhihu.com/question/1929860340792927086/answer/1963879916815754358
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 08:10
modified: 2025-10-21 08:16
upvote_num: 23
comment_num: 3
---

会让早恋变成一件很刺激的事情。

你想想，白天你和你可爱的小女朋友在学校里只能装作互不熟悉的冷漠同桌。

而放学以后你们两个悄悄找一个没有人的小花园就能热烈的拥吻，光是单纯的接吻就会觉得是打破了不可饶恕的禁忌，觉得是把老师的屁话全部都踩在了脚下

越是稚嫩的恋爱，就越是需要有名为敌人的养分，来滋生出甜美的果实呀。

![](./assets/v2-6c3125b6f14d3820cbd15acdfdc36912_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

