---
title: 为什么男生大部分喜欢瘦小的女生 女生大部分喜欢强壮的男生？
url: https://www.zhihu.com/question/6161748711/answer/2015536217580667966
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-12 21:14
modified: 2026-03-12 21:14
upvote_num: 629
comment_num: 154
---

大部分女生并不喜欢强壮的

她们能接受的强壮上限是这种身材

![](./assets/v2-12c672ce9ad74b634db3a9e8af408026_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1067'></svg>)

下面这种身材她们就觉得很吓人了，需要有更高的颜值作为加分了

![](./assets/v2-1de9d03d7a0087319cd1e7a3d00f6e42_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1422'></svg>)

而下面这种男人觉得"这样才叫强壮"的身材，她们是万万不会接受的

![](./assets/v2-0f1d37639174b1c4219c75eac85b77cf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='772' height='1242'></svg>)

另外

她们更喜欢的是这种身材。

![](./assets/v2-446c51e2774e6192c681d7b7ddc51f6e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='672' height='760'></svg>)

