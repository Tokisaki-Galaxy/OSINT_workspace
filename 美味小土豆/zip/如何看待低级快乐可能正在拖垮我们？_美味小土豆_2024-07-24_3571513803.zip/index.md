---
title: 如何看待低级快乐可能正在拖垮我们？
url: https://www.zhihu.com/question/467339536/answer/3571513803
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-24 03:27
modified: 2024-07-24 03:27
upvote_num: 3
comment_num: 0
---

低级快乐——让自己舒服，放松

高级快乐——让自己紧张起来，随时接受压榨。

