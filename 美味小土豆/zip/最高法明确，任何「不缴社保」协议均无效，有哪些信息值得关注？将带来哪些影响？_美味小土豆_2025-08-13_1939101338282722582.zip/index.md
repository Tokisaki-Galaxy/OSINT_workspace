---
title: 最高法明确，任何「不缴社保」协议均无效，有哪些信息值得关注？将带来哪些影响？
url: https://www.zhihu.com/question/1934605365196059415/answer/1939101338282722582
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 23:09
modified: 2025-08-13 23:09
upvote_num: 1
comment_num: 0
---

"真的是好事情哪轮得到你"

