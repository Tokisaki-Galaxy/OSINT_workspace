---
title: 女孩为什么不喜欢老实人?
url: https://www.zhihu.com/question/474759130/answer/3587870533
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-08 13:18
modified: 2024-08-08 13:18
upvote_num: 0
comment_num: 0
---

女性喜欢在相对安全的情况下让男性带着做坏事

不安全一点也可以，只要你有足够的能力兜底女性会更喜欢

