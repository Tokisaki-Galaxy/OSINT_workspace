---
title: 如何去判断一个女生到底喜不喜欢你？
url: https://www.zhihu.com/question/393423115/answer/1947196071676715198
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 07:15
modified: 2025-09-05 07:15
upvote_num: 5
comment_num: 0
---

你试试看问妹子愿不愿意帮你掏耳朵，两只耳朵都掏。

这个一件只有关系很亲密的人才愿意做的日常小事。

