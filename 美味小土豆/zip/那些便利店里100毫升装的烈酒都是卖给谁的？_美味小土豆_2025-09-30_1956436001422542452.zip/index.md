---
title: 那些便利店里100毫升装的烈酒都是卖给谁的？
url: https://www.zhihu.com/question/5865294081/answer/1956436001422542452
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 19:11
modified: 2025-09-30 19:11
upvote_num: 7
comment_num: 0
---

情侣出去开房需要一点酒精助兴的话，不可能包里满满当当的带着好几瓶酒

这种时候这种小瓶装就很方便了。用来调鸡尾酒也不会太浪费，也不怕喝不完。

![](./assets/v2-b6ecab0cc819c644c8765839d1a054b8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='1000'></svg>)

