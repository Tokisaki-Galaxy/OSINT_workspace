---
title: 为什么国内的大多数父母，都很反对孩子养宠物？
url: https://www.zhihu.com/question/652621802/answer/1971679982406305527
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-11 20:45
modified: 2025-11-11 20:45
upvote_num: 2
comment_num: 1
---

少

