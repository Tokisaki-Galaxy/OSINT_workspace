---
title: 如何看待温州二次元爱好者的手办被老婆和双方父母联合摧毁？
url: https://www.zhihu.com/question/662103064/answer/3568972654
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 19:02
modified: 2024-07-21 19:02
upvote_num: 57
comment_num: 1
---

真的太可怜了，没看完就关了。

别再逼逼不结婚老了怎么办了。今天能砸你手办，老了就会拔你氧气管

