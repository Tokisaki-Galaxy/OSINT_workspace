---
title: 如果你的父母生了重病，你很缺钱，但在你准备凑钱时，你被异世界召唤了，你会拼尽全力去帮助召唤你的势力吗？
url: https://www.zhihu.com/question/1994916675124998748/answer/1995513565659018827
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-16 15:11
modified: 2026-01-16 15:13
upvote_num: 56
comment_num: 1
---

现在立刻马上送我回去，我不接受任何承诺和讨价还价。

否则这个异世界就有两个魔王了

哦，不，还是一个魔王

只有一个魔王了

