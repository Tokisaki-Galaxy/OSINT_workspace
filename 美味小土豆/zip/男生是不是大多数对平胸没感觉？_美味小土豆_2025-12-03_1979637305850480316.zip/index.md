---
title: 男生是不是大多数对平胸没感觉？
url: https://www.zhihu.com/question/1967421882807620905/answer/1979637305850480316
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-03 19:45
modified: 2025-12-03 19:45
upvote_num: 7
comment_num: 1
---

对不起，我是萝莉控，我很喜欢160身高贫乳纤细身材的小女孩。

![](./assets/v2-30b2aa336dac205c023260bae2adc106_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-47548f5cdfb304c0abf950e6aae25859_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='900' height='1200'></svg>)

