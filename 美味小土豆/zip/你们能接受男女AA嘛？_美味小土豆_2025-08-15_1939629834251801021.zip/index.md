---
title: 你们能接受男女AA嘛？
url: https://www.zhihu.com/question/1888159178905870461/answer/1939629834251801021
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 10:09
modified: 2025-08-15 10:09
upvote_num: 1
comment_num: 0
---

追求100%公平的aa那还是不要谈恋爱了。

