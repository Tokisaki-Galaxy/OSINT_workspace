---
title: 现在手办行业那么火,三年后会不会衰落？
url: https://www.zhihu.com/question/581817414/answer/3574675339
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-26 22:31
modified: 2024-07-26 22:31
upvote_num: 0
comment_num: 0
---

要看男女对立是不是会继续下去。

会的话这生意至少还能再赚个五六年吧

