---
title: 世界观究竟要如何设定才能让陆地战舰，巨型机甲这些东西变得合理？
url: https://www.zhihu.com/question/5549549922/answer/129511761180
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-22 13:52
modified: 2025-03-22 13:52
upvote_num: 3
comment_num: 1
---

学eva，学各类超级系机器人动画，不要讲道理。

现在已经不是真实系机器人流行的年代了，越讲道理越显得可笑。

