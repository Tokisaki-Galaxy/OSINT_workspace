---
title: 假如给你十万元，要在四个月内追到一个女生，主要用在吃喝玩乐上，你会怎么花？
url: https://www.zhihu.com/question/641334242/answer/1955336433381414309
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 18:22
modified: 2025-09-27 18:22
upvote_num: 12
comment_num: 0
---

蛮难的

不是钱的问题，也不是时间的问题

而是要追特定目标就是很难。

因为她第一眼看不上你的话就是看不上了。

接下来你花再多的钱也只是体验舔狗时光罢了。

