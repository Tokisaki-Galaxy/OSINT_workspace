---
title: 表姐家有几千万，为什么找她借50万她却说没有钱呢？
url: https://www.zhihu.com/question/528034884/answer/3550031596
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-03 13:25
modified: 2024-07-03 13:25
upvote_num: 2
comment_num: 0
---

我老板八位数的身价，公账里有大七位数，但是单纯借钱的话，他自己拿十万块都够呛

