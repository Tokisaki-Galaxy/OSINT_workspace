---
title: 为啥子精神小妹都那么瘦？
url: https://www.zhihu.com/question/438687594/answer/1940700394364834353
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 09:03
modified: 2025-08-18 09:03
upvote_num: 0
comment_num: 0
---

有没有可能

年轻的小姑娘就是会很瘦

