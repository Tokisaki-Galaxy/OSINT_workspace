---
title: 为什么现在很多女孩不愿意和男生aa?
url: https://www.zhihu.com/question/398902015/answer/1946965756425279003
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-04 16:00
modified: 2025-09-04 16:00
upvote_num: 1319
comment_num: 103
---

因为女生心里想的是：

"我想把钱攒着和喜欢的男生一起出去玩时再用，如果他没钱，我就请他吃饭，所以我不想在你身上花任何一分钱，这些钱都是要和我喜欢的他在一起的时候用的钱。"

