---
title: 有没有在高达中的角色死了让大家感到难受的?
url: https://www.zhihu.com/question/391017170/answer/1939006662867420565
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 16:53
modified: 2025-08-13 16:53
upvote_num: 1
comment_num: 0
---

魔女妈妈

她死的时候我确实愣住了。差不多和学姐断头一样。

啊？原来这片子是打算死人的啊!

![](./assets/v2-fdf24d44f2668b02c8074e2b1c3f5ddc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='1280'></svg>)

  


![](./assets/v2-8a07534ff0d049e00c06f8e31058c58f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

