---
title: 怎样可以快速检验两个人三观一致？
url: https://www.zhihu.com/question/278812587/answer/1940482072234951837
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 18:36
modified: 2025-08-17 18:36
upvote_num: 4
comment_num: 0
---

看两个人的下限是否一致。

两个人在坏的一面上想法是否合拍。

