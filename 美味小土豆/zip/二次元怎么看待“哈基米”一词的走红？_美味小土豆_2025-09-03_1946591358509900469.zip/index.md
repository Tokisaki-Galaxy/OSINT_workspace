---
title: 二次元怎么看待“哈基米”一词的走红？
url: https://www.zhihu.com/question/614578752/answer/1946591358509900469
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 15:12
modified: 2025-09-03 15:12
upvote_num: 1
comment_num: 0
---

jk都能往身上穿了，一个词原本是什么意思早就不重要了。

