---
title: 大男子主义的男孩子为什么大都招女孩子嫌？
url: https://www.zhihu.com/question/621011025/answer/1943448290139017801
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 23:02
modified: 2025-08-25 23:02
upvote_num: 1
comment_num: 0
---

任何一种属性都不会招女生嫌

女生嫌你只是因为你，其他都是借口

不要一本正经的去分析女人讨厌什么属性，没意义的，还很像小丑。

女人根本不讲道理的

