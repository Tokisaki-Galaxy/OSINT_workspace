---
title: 为什么贾政说袭人这个名字刁钻？
url: https://www.zhihu.com/question/282114321/answer/1962237315708596333
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-16 19:23
modified: 2025-10-17 16:00
upvote_num: 473
comment_num: 29
---

我爸从我qq列表的名字就能判断出我哪些朋友是正经coser，哪些是福利姬，还有哪些是他不好意思明着教育我的只能说"你交朋友慎重一点"的小姐姐。

ps：我爹妈至今都认为我是很纯良的小男孩，只是有点二次元上头的中二小鬼。

ps2：我不是男娘。

顺便，我qq和微信的名字都是法兹，知道我为人的死宅朋友说我这个名字也挺刁钻的。

![](./assets/v2-d6fd0c380ac1e5a96e8b4747f21569ff_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1530' height='1977'></svg>)

