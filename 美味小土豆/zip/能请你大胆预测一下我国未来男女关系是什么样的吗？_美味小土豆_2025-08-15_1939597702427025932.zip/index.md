---
title: 能请你大胆预测一下我国未来男女关系是什么样的吗？
url: https://www.zhihu.com/question/666738677/answer/1939597702427025932
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 08:02
modified: 2025-08-15 08:06
upvote_num: 0
comment_num: 0
---

首先，我真的挺期待看到这一幕变成现实的，哈哈哈哈哈乐死了

![](./assets/v2-980e6088d744f0b683f71d9185ad1e9a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='992' height='1322'></svg>)

其次，我真的很期待未来能打起来!

我要看血流成河~

![](./assets/v2-51d4ded65f0ff8e40d5132792c329355_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

