---
title: 恐怖片多以学生妇女这样的弱势群体为主角，若采用身怀绝技、临危不乱、冷静理智的主角（如蝙蝠侠）可行吗？
url: https://www.zhihu.com/question/613609449/answer/118460148688
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-07 10:35
modified: 2025-03-07 10:35
upvote_num: 4
comment_num: 0
---

地狱老师里如果没有男主，就是标准的伊藤润二恐怖漫画，但是加了男主和白衣观音经还有封印着霸鬼的鬼手，所以这是部搞笑色情恐怖漫画

