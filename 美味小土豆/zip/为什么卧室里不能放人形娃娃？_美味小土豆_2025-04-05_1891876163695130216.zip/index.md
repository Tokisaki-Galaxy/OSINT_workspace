---
title: 为什么卧室里不能放人形娃娃？
url: https://www.zhihu.com/question/444263854/answer/1891876163695130216
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-05 15:33
modified: 2026-01-04 10:10
upvote_num: 1535
comment_num: 44
---

我以前打工的咖啡店仓库里有一个很漂亮硅胶娃娃，不知道谁有病给她换了身女仆装放了把椅子坐在里面当仓库管理员。我第一次进仓库转身看到她的时候被她吓得腿都软了！！

