---
title: 为什么 Cosplay 圈不允许评价长相？
url: https://www.zhihu.com/question/27475395/answer/1938221073087829962
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-11 12:51
modified: 2025-08-11 12:51
upvote_num: 2
comment_num: 0
---

圈子里的喷颜会留下污点被回旋镖呗。

不相干的游客喷的可难听了

