---
title: 战列舰对男生的诱惑有多大？
url: https://www.zhihu.com/question/3737413066/answer/1892983851548115421
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 16:55
modified: 2025-04-08 16:55
upvote_num: 13
comment_num: 0
---

我这辈子能想到的最涩情的场面就是驾驶柯西，从港口低空掠过停泊在洋面上的大和号的时候，全周天显示屏上标记出下面巨大的舰影——“超无畏级宇宙战舰-yamato”。

色疯了我靠！！

