---
title: 为什么总有人认为练格斗就无敌了？
url: https://www.zhihu.com/question/471430519/answer/1943332515554267384
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 15:22
modified: 2025-08-25 15:22
upvote_num: 23
comment_num: 0
---

格斗能教你收着力打，实用性很高。

不会格斗技你遇到坏人照着脑壳一锤下去。

好了，人生结束咯!

钟馗有功夫才能降服女鬼

没功夫这女鬼就被超度了

