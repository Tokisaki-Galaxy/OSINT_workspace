---
title: 男子当街殴打女子，退伍军人飞踹制止，这一事件引发了怎样的社会反响？
url: https://www.zhihu.com/question/1955935620225542117/answer/1956656217976989594
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 09:46
modified: 2025-10-01 09:46
upvote_num: 13
comment_num: 0
---

有些男的平时内心就是这么个精神状态：天天想着能对别人合法施暴，一旦自以为自己占据了道德制高点就会变得极其凶残，用正义铁拳霸凌弱者可以说是他一无是处的人生里为数不多的高光时刻，足以让他反复回味品鉴吹嘘一生。

这种人就是纯烂人，和他是什么职业无关。

![](./assets/v2-c833ece4b777a7e3e42a95e981fabf95_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='959'></svg>)

  


![](./assets/v2-8f0a3e56655228ec15d10df7bd7ac9e2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='958'></svg>)

