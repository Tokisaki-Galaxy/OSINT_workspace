---
title: 如何评价人民网文章《请给AI起个好名》？
url: https://www.zhihu.com/question/2017921081520989611/answer/2019994531458720209
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-25 04:30
modified: 2026-03-25 04:30
upvote_num: 20
comment_num: 0
---

不是，ai的中文不就是人工智能吗？

就像as叫强袭机兵

ms叫机动战士一样

也不会有人有病到给这些简称再取一个名字吧……

