---
title: 二次元应该反对 coser 擦边吗？
url: https://www.zhihu.com/question/15152796908/answer/1945886868261569885
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 16:33
modified: 2025-09-01 16:33
upvote_num: 1
comment_num: 0
---

我喜欢二次元就是因为涩图和二游cosplay。

所以擦边coser我100%欢迎。

你们反对就反对吧。

我抱着穿超小比基尼的流萤回酒店了~

