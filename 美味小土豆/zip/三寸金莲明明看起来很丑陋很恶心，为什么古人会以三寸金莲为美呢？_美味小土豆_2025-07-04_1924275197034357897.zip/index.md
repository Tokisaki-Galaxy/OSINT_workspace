---
title: 三寸金莲明明看起来很丑陋很恶心，为什么古人会以三寸金莲为美呢？
url: https://www.zhihu.com/question/14809724583/answer/1924275197034357897
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-04 01:15
modified: 2025-07-04 01:15
upvote_num: 103
comment_num: 26
---

首先，我百分百批判缠足这种反人类恶习，其次，我个人认为三寸金莲这玩意很恶心

最后，我认为人形生物上，尖小脚还是有美感的。

![](./assets/v2-18aaf1a8e947135379c07bea33a11876_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-8fdf3de09052151c895ebbfb567b9d10_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1821' height='2048'></svg>)

