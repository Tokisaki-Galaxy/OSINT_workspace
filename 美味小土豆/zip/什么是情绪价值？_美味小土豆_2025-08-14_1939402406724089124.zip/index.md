---
title: 什么是情绪价值？
url: https://www.zhihu.com/question/326968879/answer/1939402406724089124
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 19:06
modified: 2025-08-14 19:06
upvote_num: 0
comment_num: 0
---

"不管你死活的顺着你说话"

