---
title: 很多私企老板破产了为什么要自杀呢？
url: https://www.zhihu.com/question/35458401/answer/3556594628
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-09 17:59
modified: 2024-07-09 17:59
upvote_num: 55
comment_num: 1
---

自杀的老板很多是上了高杠杆或者把资金流爽完了。

单纯赔光了自己家产的不到跳楼自杀的地步

