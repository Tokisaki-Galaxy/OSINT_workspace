---
title: 言论称「高端女性服装的上衣，一般不设口袋」是否属实？
url: https://www.zhihu.com/question/36178019/answer/1942595141958342534
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 14:32
modified: 2025-08-23 14:32
upvote_num: 3
comment_num: 1
---

是的……

我前老板和现老板出门都是什么都不带，然后让我拎包的。

她的衣服从上到下基本都没口袋。

她要什么就开口问我

"我手机呢？"

"我鞋子呢?"

"我水呢?"

"我笔么呢？"

"你人呢？!"

