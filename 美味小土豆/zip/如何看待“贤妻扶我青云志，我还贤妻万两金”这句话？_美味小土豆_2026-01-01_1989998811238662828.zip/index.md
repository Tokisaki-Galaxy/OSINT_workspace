---
title: 如何看待“贤妻扶我青云志，我还贤妻万两金”这句话？
url: https://www.zhihu.com/question/1891508164182144750/answer/1989998811238662828
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-01 09:58
modified: 2026-01-01 09:58
upvote_num: 44
comment_num: 1
---

她能扶你青云志，那么看重的就绝对不是万两金。

以为万两金就能买下扶你上青云的恩情，就很天真了。

会这么想就说明你压根就没抽到过ssr级别的贤妻。

