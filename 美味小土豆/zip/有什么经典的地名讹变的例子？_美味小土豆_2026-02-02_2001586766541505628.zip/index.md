---
title: 有什么经典的地名讹变的例子？
url: https://www.zhihu.com/question/1913348034005300352/answer/2001586766541505628
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-02 09:24
modified: 2026-02-02 09:24
upvote_num: 3
comment_num: 2
---

上海浦东的东方路以前叫文登路，而文登路的前身叫坟墩路。

感觉浦东以前都没啥正经路名

