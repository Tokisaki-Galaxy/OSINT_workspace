---
title: 我是女孩 真的会有人因为我抽烟讨厌我吗？
url: https://www.zhihu.com/question/661731954/answer/2001981590029475957
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 11:33
modified: 2026-02-03 11:33
upvote_num: 27
comment_num: 0
---

我喜欢一个人，会觉得她抽烟的样子很美。

我讨厌一个人，哪怕她穿着女仆装上门给我做饭我也会礼貌的拒绝。

这和抽不抽烟本身没啥关系。

