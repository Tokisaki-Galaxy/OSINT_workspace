---
title: 为什么帆樯出去的人总自以为知道了世界的真相呢？
url: https://www.zhihu.com/question/1976804665929786068/answer/1977112246053273818
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-26 20:31
modified: 2025-11-26 20:31
upvote_num: 8
comment_num: 0
---

世界的真相我不知道。

但是"你哪来那么多涩图啊？"这个问题，我倒是可以回答。

![](./assets/v2-78e32d66216744ce50a696265bf8d99a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1152' height='1152'></svg>)

  


![](./assets/v2-0d88927c2a09bc047e2c3145916d16f1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1200'></svg>)

  


![](./assets/v2-17e32eeeee956293f1dd0debc522ddc7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='900'></svg>)

