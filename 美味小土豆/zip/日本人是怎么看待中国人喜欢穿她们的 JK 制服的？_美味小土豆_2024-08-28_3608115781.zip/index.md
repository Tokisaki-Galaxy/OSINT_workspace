---
title: 日本人是怎么看待中国人喜欢穿她们的 JK 制服的？
url: https://www.zhihu.com/question/395996183/answer/3608115781
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-28 00:14
modified: 2024-08-28 00:14
upvote_num: 4
comment_num: 0
---

我曾经也以为日本人一眼就能分辨出真jk和伪jk

直到我和朋友去日本参cm,她是现役女大，jk打扮，我一路都是社畜装。

谁能想到那坑货带了整整五套不重样的jk制服和三顶不同款式的假毛!从短发jk到金发辣妹无所不包!

每天她都会找我们附近人最多的地方让我等她，然后她看到就会向我挥手，嘴里叫着“おじさん”的就跑过来，然后到我面前一把搂住住我胳膊，开朗的说“お待たせ，一緒に行きましょう～おじさん♡”

两天后我们就被警察盘问了！（｀Δ´）！

事后我捏着她脸问她，“你是不是在搞我，是不是在搞我!९(།︵།) ”

她说“我就是想试试日本人能不能识破我的jk伪装(★^O^★)”

![](./assets/v2-95bc67997b57b052115713a9b5e2ef59_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1003'></svg>)

  


![](./assets/v2-19a5b888fac392b94a1d5834c472a69b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

