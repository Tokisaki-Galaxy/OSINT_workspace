---
title: 你认为美腿最突出的特征是什么？
url: https://www.zhihu.com/question/1977712282940219507/answer/1995085225651364653
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-15 10:49
modified: 2026-01-15 10:49
upvote_num: 12
comment_num: 0
---

长和细啊

其他比例都能后天调整，但是小腿骨长度和脚踝粗细是天生的，这个没有抽到ssr就是没有。

