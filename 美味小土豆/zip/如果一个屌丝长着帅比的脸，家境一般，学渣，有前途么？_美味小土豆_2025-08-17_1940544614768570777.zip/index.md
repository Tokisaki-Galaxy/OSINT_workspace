---
title: 如果一个屌丝长着帅比的脸，家境一般，学渣，有前途么？
url: https://www.zhihu.com/question/27809333/answer/1940544614768570777
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 22:44
modified: 2025-08-17 22:44
upvote_num: 7
comment_num: 0
---

如果他还抽烟，爱装忧郁

女生们会叫他"落魄贵公子"

家境一般？

他的脸就是支付宝

有的是大小姐私底下偷偷给他花钱

