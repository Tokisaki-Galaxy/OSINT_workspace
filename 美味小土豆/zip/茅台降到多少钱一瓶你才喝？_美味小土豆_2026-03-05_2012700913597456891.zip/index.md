---
title: 茅台降到多少钱一瓶你才喝？
url: https://www.zhihu.com/question/660296860/answer/2012700913597456891
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-05 01:28
modified: 2026-03-05 01:28
upvote_num: 8
comment_num: 0
---

这玩意也就贵的时候喝起来显得没那么愚蠢。

要是便宜了鬼才会去喝这玩意……

