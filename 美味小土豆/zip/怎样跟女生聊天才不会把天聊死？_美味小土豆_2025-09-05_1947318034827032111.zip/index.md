---
title: 怎样跟女生聊天才不会把天聊死？
url: https://www.zhihu.com/question/519909415/answer/1947318034827032111
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 15:19
modified: 2025-09-05 15:20
upvote_num: 6
comment_num: 0
---

我不会选择聊天，我会直接发语音

如果她无感，那么我就直接放弃。

如果她喜欢，那么随便聊什么都可以，因为你只要不停的说话，她就会想办法让话题进行下去。

