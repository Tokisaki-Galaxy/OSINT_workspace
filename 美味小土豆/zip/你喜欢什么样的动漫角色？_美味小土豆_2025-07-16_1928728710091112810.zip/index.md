---
title: 你喜欢什么样的动漫角色？
url: https://www.zhihu.com/question/656922645/answer/1928728710091112810
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-16 08:12
modified: 2025-07-16 08:12
upvote_num: 8
comment_num: 0
---

2199里副舰长真的超级有人格魅力

![](./assets/v2-3567cd2f3ed68fe5174c9b584bc790b2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='731' height='487'></svg>)

