---
title: 比起168/172的高个子女生，男生真的都像营销号说的那样更喜欢160左右的女生吗？
url: https://www.zhihu.com/question/616699037/answer/1992170264918771322
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-07 09:46
modified: 2026-01-07 09:46
upvote_num: 19
comment_num: 3
---

我什么身高都喜欢

185的纤长

178的高挑

150的娇小

145可以抱起来🌿

如果你钟爱兔女郎，那我真心推荐180以上的妹子。

不是腿神也起码是腿仙。

