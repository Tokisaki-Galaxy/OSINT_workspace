---
title: 有没有推荐的致郁的，黑深残的动画？
url: https://www.zhihu.com/question/370017225/answer/1956480550761109407
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 22:08
modified: 2025-09-30 22:08
upvote_num: 1
comment_num: 0
---

机动警察剧场版3，废弃物十三号

![](./assets/v2-260933c042e5918a1970527594b6b3e8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

