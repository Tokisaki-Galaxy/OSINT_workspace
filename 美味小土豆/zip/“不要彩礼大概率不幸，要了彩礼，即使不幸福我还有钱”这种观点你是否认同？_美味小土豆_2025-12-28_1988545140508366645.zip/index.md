---
title: “不要彩礼大概率不幸，要了彩礼，即使不幸福我还有钱”这种观点你是否认同？
url: https://www.zhihu.com/question/1971498748149465609/answer/1988545140508366645
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-28 09:41
modified: 2025-12-28 09:41
upvote_num: 8
comment_num: 0
---

如果会不幸的话，我的建议是不嫁，而不是像个代孕妓女一样委曲求全的伸这个手。

![](./assets/v2-2411822e416bf2edc8233bf0da4ac900_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='512' height='1024'></svg>)

