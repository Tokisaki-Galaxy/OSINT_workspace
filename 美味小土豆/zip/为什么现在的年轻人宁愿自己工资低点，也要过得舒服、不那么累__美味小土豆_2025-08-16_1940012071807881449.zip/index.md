---
title: 为什么现在的年轻人宁愿自己工资低点，也要过得舒服、不那么累?
url: https://www.zhihu.com/question/636907409/answer/1940012071807881449
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 11:28
modified: 2025-08-16 11:28
upvote_num: 55
comment_num: 5
---

每个月四五千，每天工作量一小时，每天下班了能回家吃饭。

没有业绩压力

不会被老板骂

不担心失业

没有加班没不用背锅

每个月爹妈再贴个3000。

这种日子你不要？！

