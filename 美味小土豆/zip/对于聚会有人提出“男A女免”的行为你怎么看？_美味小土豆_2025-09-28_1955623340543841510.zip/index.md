---
title: 对于聚会有人提出“男A女免”的行为你怎么看？
url: https://www.zhihu.com/question/408424495/answer/1955623340543841510
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 13:22
modified: 2025-09-28 13:22
upvote_num: 1
comment_num: 0
---

"你一会是要开impart吗？我能不能先和你带来的姑娘组队?"

