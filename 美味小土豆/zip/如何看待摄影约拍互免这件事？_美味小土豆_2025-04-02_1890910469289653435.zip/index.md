---
title: 如何看待摄影约拍互免这件事？
url: https://www.zhihu.com/question/434172001/answer/1890910469289653435
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-02 23:36
modified: 2025-04-02 23:36
upvote_num: 262
comment_num: 5
---

约拍，互免，只有一种情况——你们两个是朋友。

拍完收工两个人一起快快乐乐吃饭聊天吹水。

除此以外的绝大部分都是吹牛逼。

