---
title: 什么样的女生一看就知道没谈过恋爱？
url: https://www.zhihu.com/question/41251486/answer/1957541330680017751
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 20:23
modified: 2025-10-03 20:23
upvote_num: 37
comment_num: 2
---

你亲她的时候她会像根木头一样傻呆呆的站在那里

还会睁着眼睛不可置信的看着你。

亲完还会小声嘀咕"好羞耻啊……"

可爱倒是很可爱。

