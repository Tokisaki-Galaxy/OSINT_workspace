---
title: 你愿意娶一个大龄剩女吗?
url: https://www.zhihu.com/question/8091559587/answer/2014704546295849352
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-03-10 14:09
modified: 2026-03-10 14:09
upvote_num: 9
comment_num: 1
---

我曾经连18岁的私立医院院长千金的求婚都拒绝了。

那我说我不会娶大龄姐姐应该不算双标吧。

