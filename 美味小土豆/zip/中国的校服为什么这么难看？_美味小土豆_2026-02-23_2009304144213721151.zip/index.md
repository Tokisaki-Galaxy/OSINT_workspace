---
title: 中国的校服为什么这么难看？
url: https://www.zhihu.com/question/23164144/answer/2009304144213721151
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-23 16:30
modified: 2026-02-23 16:30
upvote_num: 38
comment_num: 5
---

只有我觉得放学后的现役jk，穿着她自己的本校校服，在酒店的镜子前里叼着发带扎头发的样子很好看嘛？

