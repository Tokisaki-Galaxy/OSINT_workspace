---
title: 女生练什么防身术可以一招制敌？
url: https://www.zhihu.com/question/664818322/answer/1948955196601369014
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 03:45
modified: 2025-09-10 03:45
upvote_num: 8
comment_num: 0
---

撒丫子跑，不要跑直线，一边绕圈跑一边用最大的声音喊救命！

这招真的真的能救命。

我教过很多姑娘这招，绕圈跑，灵活性够高运气够好能让大体型的男人崴了脚。

