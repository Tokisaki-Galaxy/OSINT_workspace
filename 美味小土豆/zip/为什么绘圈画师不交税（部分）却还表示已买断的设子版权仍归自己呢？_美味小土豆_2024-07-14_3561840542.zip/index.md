---
title: 为什么绘圈画师不交税（部分）却还表示已买断的设子版权仍归自己呢？
url: https://www.zhihu.com/question/658846219/answer/3561840542
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 20:48
modified: 2024-07-14 20:48
upvote_num: 0
comment_num: 0
---

买断是买断的钱，使用是使用的钱。确实本来就不一样的

你们不签合同的嘛？

