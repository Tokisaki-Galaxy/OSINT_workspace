---
title: 底层男人真的不配被爱吗？
url: https://www.zhihu.com/question/650368025/answer/1975309059142997169
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-21 21:06
modified: 2025-11-21 21:06
upvote_num: 73
comment_num: 0
---

大部分普通人，他们需要的不是爱恋，而是纯粹的关爱。

如果你能分得清这两种感情的话。

那么普罗大众都值得被爱。

