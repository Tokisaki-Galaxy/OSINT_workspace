---
title: 饺子导演和宫崎骏哪个艺术地位更高？
url: https://www.zhihu.com/question/13094791172/answer/1955366704000534177
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 20:22
modified: 2025-09-27 20:22
upvote_num: 3
comment_num: 0
---

天空之城对日本商业动画的影响力至今还在。

这片的内核和表现形式至少影响影了两代中日动画人。

而魔童不具备这个实力，它是一部有自己特色的，独立表达观点的动画。

