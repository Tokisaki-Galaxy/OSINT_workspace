---
title: 什么样的男生让你感觉很愚蠢？
url: https://www.zhihu.com/question/67597815/answer/1956637304912326798
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 08:31
modified: 2025-10-01 08:31
upvote_num: 7
comment_num: 0
---

聊个魅魔都要抖机灵转进历史人物身上然后滔滔不绝开始键政的圆头胖子种

