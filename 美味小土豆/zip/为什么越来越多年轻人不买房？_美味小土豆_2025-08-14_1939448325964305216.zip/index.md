---
title: 为什么越来越多年轻人不买房？
url: https://www.zhihu.com/question/641154083/answer/1939448325964305216
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 22:08
modified: 2025-08-14 22:08
upvote_num: 43
comment_num: 5
---

我爸妈四套房，我爷爷奶奶两套房，我外婆一套房。

我爸是独生子，我妈是独生女。

不买了，我够了，不给银行当奴隶了

