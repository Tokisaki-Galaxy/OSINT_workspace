---
title: 擦边行业为什么男性占比这么少？
url: https://www.zhihu.com/question/657104733/answer/1937345255012794369
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-09 02:51
modified: 2025-08-09 02:51
upvote_num: 41
comment_num: 0
---

推上男女擦边一半一半。你觉得少是因为你没找到关键词。

男喘女喘这个赛道也是一半一半。推上喘百科列的很清楚，一查就知道。

ps：推上很多男的还会去挤占女性赛道。所以我怀疑性别♂的擦别群体可能数量要比♀还多一点点……

