---
title: 如何评价高市早苗竞选口号:japan is back！？
url: https://www.zhihu.com/question/1952512368241283105/answer/1953845944396277179
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-23 15:39
modified: 2025-09-23 15:39
upvote_num: 1
comment_num: 0
---

tmd，居然不是

「世界よ！我、帰ってきた！」

烂！烂完了

