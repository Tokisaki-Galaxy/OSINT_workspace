---
title: 你怎么理解温铁军说的想躺平就回农村，割韭菜割不着，还生活成本低这个意思？
url: https://www.zhihu.com/question/665278437/answer/3609047144
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-28 21:07
modified: 2024-08-28 21:07
upvote_num: 7
comment_num: 2
---

农村生活开销确实小，但是要躺平要住得舒服也不是特别容易的

首先不要相信互联网上说的农村几百一千的就能一间屋借一年。这种房子确实有，但是大多都在交通十分不方便并且对城市里的人来说条件很恶劣的地方。而且这种屋子很有可能电路老化，你还要重新找人接新的线，但是很有可能没电工愿意上门。

以浙江举例，城市躺平人想要在农村住得舒服至少要找农村新楼，并且至少是卫生间全装修好的其他还是毛胚的新楼。

![](./assets/v2-2f13f3e2bbb1b474a54c55eaef2805ab_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-7c632532442d26b6a19243e456f1673f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-a872a6139b2df18497a5886b900708b1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

这样的楼在浙江农村的房租价格是3500-4000一个月，大约300平米，还带一个200平米左右的院子。

这种楼最合适的是好几个做互联网工作，不在意工作地点的朋友一起合租。6-7个人的话每个人每个月几百块的房租，每个人40多平米的生活空间，住得很舒服了。

在这样的农村每个月的生活开销刨开房租大约是1500左右，前提是得自己做饭，这边每天买菜的话50元就够4个人有菜有肉有汤的吃饱，平均下来就是每个人12元，一个月360元。电费大约是用电高峰季节一个人300-400，平日是100左右。毕竟城里人空调电脑一个都不能少，大家一起开还会因为用电量大而上梯段，所以电费不会比城市便宜太多。

然后你还剩下800可以买衣服买零食买日用品，这点钱在浙江农村的小镇上买日用品足够了。

但是如果你们都不会做饭并且要叫外卖的话就比较痛苦了。首先农村真的很难叫外卖，我们这边已经是城市和农村的交界了，我们到镇上只有三公里。

![](./assets/v2-ec43d02b91a3c9d931af6dc5f67f0b56_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='4000' height='3000'></svg>)

  


![](./assets/v2-627de8281dd2ebadc57cfaecff21ba96_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

离市区只有六公里

![](./assets/v2-e705ceb7bd1ceb435afc97394cc3f00a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-798db5c6c8b3ece0f8376fe08ada43c1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

但是能选的外卖也寥寥无几，而且晚上十一点以后基本就没有人愿意送了。这边的外卖价格并不比大城市便宜多少，一顿20块总归要的，并且各种小饭店也不便宜。晚上如果肚子饿了就只能自己骑车出去找吃的，如果超过晚上10点就只能开车去市区的便利店或者夜排档了，然后相对的每个月的伙食费支出也要多出个四五百块。

所以在农村想要过得舒服的基本开销就是一个月2500元，外加能凑到至少4个志同道合的朋友以及一份可以居家的工作。

如果满足了这些条件，你自己又身体健康，平日里又不爱往热闹的地方凑。那么在农村生活还是很舒服的。

我现在就在浙江农村的小工厂打工，一个月工资2000，包吃包住。我老板借了两栋新装修好的农村自建房当宿舍楼。

![](./assets/v2-0bd6595751407de7b9acb31e3f29f618_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='3000' height='4000'></svg>)

我每天的工作就是开着三轮车去找老乡收计件，开着三轮车去丢大件垃圾，开着电动车去买菜。

![](./assets/v2-f5d0ea26ade9c25b96af3d30cc1dc25c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-a2b07785516dfd28fd4216aeba2840f4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-30df028bf55c089bf30b123b18f9e374_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

天气好的时候一路的景色都很漂亮，同样的工作量在农村确实会觉得更轻松。

![](./assets/v2-70b0467bdc7b1c4c116ec6c7186f3f57_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-8c93fde9f2247ad5174cc7db34c7945d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-7c5043620ee43462efdf048af976881e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-0d79d519f5623d70754c5c5b80843b3c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-11337a5b4f00f66ef06498989ff487da_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-f248f424c9a103d04994db04ce1a80db_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

我最喜欢的风景就是天气好的时候，在黄昏下，开车去大卖场的桥上，迎着火红夕阳。整个人身心都被治愈了。（可惜今天没有夕阳）

![](./assets/v2-115bf28c824d81b222a9db438078971b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-06bed117f4566d5c865aec598599595d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-3888fa7b4444f2e0e141e31cceb0891b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-4d5822762305ed199e8c3367dff3c1d4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-23bbc3fb6b1ce3929a91ab2029cecc6f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

我只能说农村生活有好有坏，但肯定不像网上说的那样是躺平圣地，毕竟基本开销还是要的，条件也有点苛刻。

