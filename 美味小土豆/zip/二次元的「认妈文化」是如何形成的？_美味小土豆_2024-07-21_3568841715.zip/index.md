---
title: 二次元的「认妈文化」是如何形成的？
url: https://www.zhihu.com/question/587339724/answer/3568841715
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 16:07
modified: 2024-07-21 16:12
upvote_num: 101
comment_num: 16
---

我曾经也觉得这样很变态

但是有一次我的小女朋友出明日奈，漫展结束我躺在她的黑丝大腿上，她温柔的摸着我的脑袋，我就鬼使神差的喊了她一句“お母さん” 

她似乎小小的惊讶了一下，然后更加温柔的抚摸着我的头

天，当时我整个人被一种巨大的羞耻感和治愈力所包围

啊啊啊，jk妈妈真的太棒了（捂脸）

![](./assets/v2-eca7375180cd17eb52d2c85e49dfc162_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

