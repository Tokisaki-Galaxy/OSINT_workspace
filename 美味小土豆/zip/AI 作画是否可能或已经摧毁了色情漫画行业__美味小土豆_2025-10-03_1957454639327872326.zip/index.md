---
title: AI 作画是否可能或已经摧毁了色情漫画行业?
url: https://www.zhihu.com/question/1912365216836059225/answer/1957454639327872326
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 14:39
modified: 2025-10-03 14:46
upvote_num: 8
comment_num: 3
---

有些已经没有什么流量的老番老二游角色和邪门角色，就靠ai佬产粮了。

![](./assets/v2-7c6e10f475b32c07d87bf4da2af675db_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2267' height='1619'></svg>)

  


![](./assets/v2-045c7879247b3c74c325d93d4233a53f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='468'></svg>)

  


![](./assets/v2-1444f1d55ea7c93c65a35e0528c6ec52_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='515'></svg>)

  


![](./assets/v2-27ac1bd7534350ed6fcd38dd7811e169_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='654'></svg>)

  


![](./assets/v2-6734a0d90b350b2e065ce01682d06d28_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='876'></svg>)

  


![](./assets/v2-db4d19390a942a09027ca14dbdc79ad4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='768'></svg>)

  


![](./assets/v2-890017d9912ee0eb2dd45f7b720aaa9b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='713' height='738'></svg>)

  


![](./assets/v2-a0f1d0da433e98ff08e56263c8bf3aba_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

