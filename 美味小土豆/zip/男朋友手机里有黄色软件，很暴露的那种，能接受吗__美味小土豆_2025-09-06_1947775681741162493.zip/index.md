---
title: 男朋友手机里有黄色软件，很暴露的那种，能接受吗?
url: https://www.zhihu.com/question/1918261830729576505/answer/1947775681741162493
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 21:38
modified: 2025-09-06 21:38
upvote_num: 106
comment_num: 7
---

你不是不能接受黄色软件

你只是不能接受把他和性联想在一起，这会让你觉得恶心。

可能你自己都没意识到

——你也许没那么喜欢他

