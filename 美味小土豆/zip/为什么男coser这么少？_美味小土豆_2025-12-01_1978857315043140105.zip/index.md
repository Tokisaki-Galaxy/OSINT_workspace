---
title: 为什么男coser这么少？
url: https://www.zhihu.com/question/655699626/answer/1978857315043140105
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 16:05
modified: 2025-12-01 16:05
upvote_num: 19
comment_num: 0
---

我想想哦

我出过红a，长江骑士，创战的意大利种马，士官长，假面骑士G3X，假面骑士空我，银灰，星熊（捂脸），生化危机5的克里斯，萨姆……其他乱七八糟的暂时想不起来了。

