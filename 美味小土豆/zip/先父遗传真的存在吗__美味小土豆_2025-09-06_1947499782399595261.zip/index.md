---
title: 先父遗传真的存在吗?
url: https://www.zhihu.com/question/457840355/answer/1947499782399595261
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 03:22
modified: 2025-09-06 03:22
upvote_num: 2
comment_num: 0
---

我认为不存在

但是这根本不重要

多少人能接受自己将要娶到手的老婆曾经被人天天灌成小泡芙呢？

用科学道理根本没办法让他释怀的呀

![](./assets/v2-b666ec632a8594ef89db2a342ab62787_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1328' height='1220'></svg>)

