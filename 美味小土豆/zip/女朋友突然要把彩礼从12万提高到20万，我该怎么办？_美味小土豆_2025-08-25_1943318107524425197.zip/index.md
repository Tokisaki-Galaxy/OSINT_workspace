---
title: 女朋友突然要把彩礼从12万提高到20万，我该怎么办？
url: https://www.zhihu.com/question/504782537/answer/1943318107524425197
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 14:25
modified: 2025-08-25 14:25
upvote_num: 0
comment_num: 0
---

怎么跑路的办法回答里很多人都教你了。

跑路前记得约她在公共场合再谈一次，想办法把她手机砸掉。

