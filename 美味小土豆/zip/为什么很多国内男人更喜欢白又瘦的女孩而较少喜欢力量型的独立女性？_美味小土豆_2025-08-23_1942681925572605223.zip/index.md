---
title: 为什么很多国内男人更喜欢白又瘦的女孩而较少喜欢力量型的独立女性？
url: https://www.zhihu.com/question/1895947245683189757/answer/1942681925572605223
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 20:17
modified: 2025-08-23 20:17
upvote_num: 1
comment_num: 0
---

人这一辈子至少应该和黑皮体育生生死决斗一场！

  


  


![](./assets/v2-c380116f78dc455f1c64677a27c88608_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='679' height='1200'></svg>)

  


![](./assets/v2-d91ea49afbd3af2766591627e5302e07_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='679' height='1200'></svg>)

