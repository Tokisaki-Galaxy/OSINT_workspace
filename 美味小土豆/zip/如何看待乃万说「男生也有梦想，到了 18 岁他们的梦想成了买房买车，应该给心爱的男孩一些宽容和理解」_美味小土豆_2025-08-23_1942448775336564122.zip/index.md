---
title: 如何看待乃万说「男生也有梦想，到了 18 岁他们的梦想成了买房买车，应该给心爱的男孩一些宽容和理解」？
url: https://www.zhihu.com/question/458072558/answer/1942448775336564122
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 04:51
modified: 2025-08-23 04:51
upvote_num: 3
comment_num: 0
---

其实很多人是没有梦想的

能想到买房买车的都算是有人生目标的了

