---
title: 越正经的女人越容易做出疯狂的事吗？
url: https://www.zhihu.com/question/660387583/answer/3605786329
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-25 20:57
modified: 2024-08-25 20:57
upvote_num: 9
comment_num: 0
---

“被上班族大叔约出去过夜参加impact还带着c服的福利姬小姐姐居然是班级里不起眼的学习委员?!”

现实里知道发生这种事情还是挺震惊的。要换我是憧憬她的男同学我也宕机

![](./assets/v2-d44000827b429e3f5ac051e32d7c828a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1105'></svg>)

