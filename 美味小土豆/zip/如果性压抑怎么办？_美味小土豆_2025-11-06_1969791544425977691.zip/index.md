---
title: 如果性压抑怎么办？
url: https://www.zhihu.com/question/1967019436310503606/answer/1969791544425977691
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-06 15:41
modified: 2025-11-06 15:41
upvote_num: 18
comment_num: 5
---

我不知道啊……我连性压抑是什么概念都没搞清楚。

我这种每天做爱每天还会胡思乱想的人是不是已经没救了？

我在知乎发张黑丝图都会转头求我cp穿上黑丝来一发。

我的性欲奖励机制是不是已经坏掉了。

![](./assets/v2-0b67cde0d419180b3b68f9188644d691_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1440' height='1920'></svg>)

