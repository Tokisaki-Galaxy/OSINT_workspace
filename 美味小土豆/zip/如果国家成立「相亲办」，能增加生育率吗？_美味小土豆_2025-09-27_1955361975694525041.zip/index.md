---
title: 如果国家成立「相亲办」，能增加生育率吗？
url: https://www.zhihu.com/question/1954209165183516839/answer/1955361975694525041
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 20:03
modified: 2025-09-27 20:03
upvote_num: 4
comment_num: 0
---

先把初中生的生理卫生课教明白了再说吧……

