---
title: 真的有男生看少女乐队吗?
url: https://www.zhihu.com/question/1903249312479188759/answer/1957579042174768864
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-03 22:53
modified: 2025-10-03 22:53
upvote_num: 8
comment_num: 3
---

我光拍过的少女乐队cosplay就有水团，星团，缪斯，纽带，母鸡卡和女武神了。

