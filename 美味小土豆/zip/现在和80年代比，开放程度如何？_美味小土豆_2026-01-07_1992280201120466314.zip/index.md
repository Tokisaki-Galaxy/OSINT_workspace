---
title: 现在和80年代比，开放程度如何？
url: https://www.zhihu.com/question/22289788/answer/1992280201120466314
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-07 17:03
modified: 2026-01-07 17:03
upvote_num: 152
comment_num: 1
---

那天我在投屏b站的机械战警，我爸路过的时候坐着一起看了小一会。

看到血浆镜头打码的时候他不屑的吐槽了一句"这片以前电视台放都不打码的"。

