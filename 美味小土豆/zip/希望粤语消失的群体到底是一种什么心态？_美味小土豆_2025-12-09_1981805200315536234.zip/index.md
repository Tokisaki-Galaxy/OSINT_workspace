---
title: 希望粤语消失的群体到底是一种什么心态？
url: https://www.zhihu.com/question/346732530/answer/1981805200315536234
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-09 19:19
modified: 2025-12-09 19:19
upvote_num: 21
comment_num: 2
---

虽然我也会喷广东人自嗨，但是打心底里说我不希望粤语消失。

因为粤语要消失了下一个肯定是上海话。

