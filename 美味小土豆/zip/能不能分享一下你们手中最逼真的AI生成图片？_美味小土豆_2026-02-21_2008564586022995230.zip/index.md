---
title: 能不能分享一下你们手中最逼真的AI生成图片？
url: https://www.zhihu.com/question/1908222873073606856/answer/2008564586022995230
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-21 15:31
modified: 2026-02-21 15:31
upvote_num: 48
comment_num: 3
---

b站看到的，不知道为啥我超喜欢这张图的气氛

![](./assets/v2-d4cb03f747be0825313ab66a0951a040_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2364' height='1618'></svg>)

