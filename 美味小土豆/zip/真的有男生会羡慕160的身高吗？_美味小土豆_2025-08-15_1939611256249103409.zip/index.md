---
title: 真的有男生会羡慕160的身高吗？
url: https://www.zhihu.com/question/1936342786682106402/answer/1939611256249103409
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 08:55
modified: 2025-08-15 08:55
upvote_num: 4
comment_num: 0
---

我初中的时候是真的羡慕过160的男生。

我觉得他们白白净净斯斯文文的。和150的女生站在一起简直郎才女貌。

他们像哈利波特和赫敏，而我则是那个摄魂怪，又黑又长……

