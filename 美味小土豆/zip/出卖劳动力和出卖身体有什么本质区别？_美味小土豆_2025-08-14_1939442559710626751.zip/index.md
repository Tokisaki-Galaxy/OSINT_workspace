---
title: 出卖劳动力和出卖身体有什么本质区别？
url: https://www.zhihu.com/question/630160386/answer/1939442559710626751
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 21:45
modified: 2025-08-14 21:45
upvote_num: 1
comment_num: 0
---

说没有本质区别的人愿不愿意把"我嗦卵我光荣"写在衣服前面？

相对的我可以把"我劳动我光荣"写在T恤前面。

