---
title: 一个练过功夫的姑娘能打过一个没练过的男人吗？
url: https://www.zhihu.com/question/35637600/answer/3594397632
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-14 17:42
modified: 2024-08-14 17:42
upvote_num: 1
comment_num: 1
---

以前给一个妹子当陪练，她比我轻一半，矮我一个多头。

我对她说的最多的一句话是

“用力，用力啦，再用力，你行的……好吧先休息会，刚刚看到你鼻涕泡都要爆炸了”

