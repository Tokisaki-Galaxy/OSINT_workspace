---
title: 部分女性选择自愿独身、不结婚，是因为中国女性独立觉醒了吗？
url: https://www.zhihu.com/question/659579128/answer/3554712684
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-08 02:18
modified: 2024-07-08 02:18
upvote_num: 1
comment_num: 0
---

不鼓吹男女对立，但是不结婚的女性越多我这行越好做。所以现实里我一直顺着周围的女性朋友说“对，结婚伺候男人干嘛”

