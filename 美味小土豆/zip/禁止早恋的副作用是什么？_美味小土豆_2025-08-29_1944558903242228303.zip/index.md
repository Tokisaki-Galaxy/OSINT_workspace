---
title: 禁止早恋的副作用是什么？
url: https://www.zhihu.com/question/618885757/answer/1944558903242228303
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-29 00:36
modified: 2025-08-29 00:36
upvote_num: 2298
comment_num: 21
---

讲一个很有趣的现象

禁止早恋会让学校和老师成为学生情侣play的一部分。

