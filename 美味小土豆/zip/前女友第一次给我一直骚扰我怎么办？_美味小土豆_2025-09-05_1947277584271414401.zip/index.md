---
title: 前女友第一次给我一直骚扰我怎么办？
url: https://www.zhihu.com/question/8956818244/answer/1947277584271414401
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 12:39
modified: 2025-09-05 12:39
upvote_num: 0
comment_num: 1
---

所以我才说，处女真的很麻烦啊

