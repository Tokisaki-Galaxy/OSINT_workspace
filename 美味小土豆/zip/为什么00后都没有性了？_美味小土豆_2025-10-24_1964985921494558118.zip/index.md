---
title: 为什么00后都没有性了？
url: https://www.zhihu.com/question/5740013329/answer/1964985921494558118
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-24 09:25
modified: 2025-10-24 09:25
upvote_num: 1512
comment_num: 196
---

啊？

开什么玩笑

00后一年的性生活都可以抵得上80后半辈子的了。

