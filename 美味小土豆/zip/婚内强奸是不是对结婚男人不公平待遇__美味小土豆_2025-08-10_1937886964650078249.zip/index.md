---
title: 婚内强奸是不是对结婚男人不公平待遇?
url: https://www.zhihu.com/question/1937367784561579334/answer/1937886964650078249
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:44
modified: 2025-08-10 14:44
upvote_num: 28
comment_num: 0
---

你可以不结婚呀~kira

