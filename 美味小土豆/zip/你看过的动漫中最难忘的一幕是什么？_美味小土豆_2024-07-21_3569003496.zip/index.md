---
title: 你看过的动漫中最难忘的一幕是什么？
url: https://www.zhihu.com/question/612437658/answer/3569003496
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 19:51
modified: 2024-07-21 19:51
upvote_num: 3
comment_num: 0
---

![](./assets/v2-96b01567a6a68a85627ca4e913a015ef_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-94d40e59162874358a70c219096e174c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-031b9600adb86749de31e0b08f3da3ef_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

