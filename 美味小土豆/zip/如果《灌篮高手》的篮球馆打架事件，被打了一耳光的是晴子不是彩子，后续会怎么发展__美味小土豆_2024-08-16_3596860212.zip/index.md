---
title: 如果《灌篮高手》的篮球馆打架事件，被打了一耳光的是晴子不是彩子，后续会怎么发展?
url: https://www.zhihu.com/question/349825422/answer/3596860212
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-16 22:54
modified: 2024-08-16 22:54
upvote_num: 1
comment_num: 0
---

那湘北队真得要解散了，搞不好樱木还要被退学……那个场合下谁能拦得着他？！啊！

