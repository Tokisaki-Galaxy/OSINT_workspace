---
title: 动漫圈有哪些值得一看的「冷门神作」？
url: https://www.zhihu.com/question/577704105/answer/1911019007907172806
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-28 11:20
modified: 2025-05-28 11:20
upvote_num: 7
comment_num: 1
---

我说个在国内很冷门的11区国民级神作

宇宙战舰大和号2199

