---
title: 如果给你月薪增加一万，但每天都要被人格侮辱十分钟，你是否愿意？
url: https://www.zhihu.com/question/645883227/answer/1976261672026005660
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-24 12:11
modified: 2025-11-24 12:11
upvote_num: 8
comment_num: 1
---

为什么不行?你要知道，跪在地上口十分钟都拿不到一万块的呀。

啊？是一个月？

那算了……

