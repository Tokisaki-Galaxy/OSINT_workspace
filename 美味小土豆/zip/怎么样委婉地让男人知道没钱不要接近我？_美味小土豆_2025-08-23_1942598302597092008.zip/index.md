---
title: 怎么样委婉地让男人知道没钱不要接近我？
url: https://www.zhihu.com/question/578315163/answer/1942598302597092008
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-23 14:45
modified: 2025-12-03 20:58
upvote_num: 1
comment_num: 0
---

直说就行啦

我这种穷逼就真的很怕被妹子当成有钱人那样盘。

你尴尬我也尴尬。

