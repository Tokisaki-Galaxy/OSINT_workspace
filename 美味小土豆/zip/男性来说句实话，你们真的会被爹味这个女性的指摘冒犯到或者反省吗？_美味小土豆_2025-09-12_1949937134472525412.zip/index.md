---
title: 男性来说句实话，你们真的会被爹味这个女性的指摘冒犯到或者反省吗？
url: https://www.zhihu.com/question/4783425609/answer/1949937134472525412
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 20:47
modified: 2025-09-12 20:47
upvote_num: 6
comment_num: 1
---

说我爹味的妹子最后都会喊我爸爸

我有点害怕这个词了

