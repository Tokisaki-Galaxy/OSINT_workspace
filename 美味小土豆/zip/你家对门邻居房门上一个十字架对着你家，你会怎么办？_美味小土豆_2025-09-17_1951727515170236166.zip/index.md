---
title: 你家对门邻居房门上一个十字架对着你家，你会怎么办？
url: https://www.zhihu.com/question/1936739699055100695/answer/1951727515170236166
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-17 19:21
modified: 2025-09-17 19:21
upvote_num: 6
comment_num: 2
---

对着十字架插根郎枪吧。

反正一时半会的他也想不出应对办法

![](./assets/v2-90e68b808e603d4dc219ac167fdb6458_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1422'></svg>)

