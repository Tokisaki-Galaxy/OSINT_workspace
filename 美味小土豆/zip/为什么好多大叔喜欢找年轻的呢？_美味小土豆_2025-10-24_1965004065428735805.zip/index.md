---
title: 为什么好多大叔喜欢找年轻的呢？
url: https://www.zhihu.com/question/8881520651/answer/1965004065428735805
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-24 10:37
modified: 2025-10-24 10:46
upvote_num: 10
comment_num: 2
---

那我问你，你爱吃哪块?

![](./assets/v2-1a7aae39eb21f6ba2d399b98210a982a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='4096'></svg>)

另外提醒一下各位老登，你们憧憬的年轻，应该是17-20岁这个年龄段。

20岁往上的小姑娘很多就维持不住你们脑中憧憬的年轻紧致的肉体了。

所以好好加油吧，不要努力错对象了~

