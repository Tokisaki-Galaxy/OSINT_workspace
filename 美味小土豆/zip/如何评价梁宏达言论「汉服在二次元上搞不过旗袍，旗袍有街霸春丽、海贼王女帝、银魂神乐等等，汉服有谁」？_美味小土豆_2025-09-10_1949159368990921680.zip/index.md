---
title: 如何评价梁宏达言论「汉服在二次元上搞不过旗袍，旗袍有街霸春丽、海贼王女帝、银魂神乐等等，汉服有谁」？
url: https://www.zhihu.com/question/1948909149137137727/answer/1949159368990921680
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 17:16
modified: 2025-09-10 17:16
upvote_num: 14
comment_num: 2
---

汉服怎么骚得过门帘子

能比肩现在的二次元旗袍的，至少也是兔女郎装了。

二次元文化里汉服和旗袍已经是两个领域的东西了

![](./assets/v2-cfa51fe32327a7c1e3646c09b1150447_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

  


![](./assets/v2-5584817ba178d0df3af4dca2b4db5c53_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='896' height='1400'></svg>)

  


![](./assets/v2-cd26f03321b8463c2d7d58cea68a3863_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='900'></svg>)

  


![](./assets/v2-0c73809fe17746bbf7ed1286f69d47b1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'></svg>)

  


![](./assets/v2-b8b4b485ff5e730c952ba7d338c301ae_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='1036'></svg>)

  


  


![](./assets/v2-434a32f62840f834d447c0bbcbd87241_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='685' height='1200'></svg>)

  


![](./assets/v2-a174babda4f4dc0c3b1aadb57e6d1004_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

  


![](./assets/v2-51f965bb3e636cf8d1151a78a2581029_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

  


![](./assets/v2-ce527eaf62e0c3faf811c49c795983b3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

