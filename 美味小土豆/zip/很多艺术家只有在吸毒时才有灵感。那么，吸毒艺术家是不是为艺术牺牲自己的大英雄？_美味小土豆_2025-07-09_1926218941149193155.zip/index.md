---
title: 很多艺术家只有在吸毒时才有灵感。那么，吸毒艺术家是不是为艺术牺牲自己的大英雄？
url: https://www.zhihu.com/question/1917001645235081271/answer/1926218941149193155
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-09 09:59
modified: 2025-07-09 09:59
upvote_num: 1
comment_num: 0
---

放屁，吸毒我不知道。但是我喝高了的时候所有的"灵感"都是自high，全是垃圾。

