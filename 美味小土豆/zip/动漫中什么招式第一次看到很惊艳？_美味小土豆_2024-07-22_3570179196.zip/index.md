---
title: 动漫中什么招式第一次看到很惊艳？
url: https://www.zhihu.com/question/283965856/answer/3570179196
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-22 21:16
modified: 2024-07-22 21:16
upvote_num: 6
comment_num: 0
---

从小看奥特曼，昭和奥特曼大家都知道，招式都是一板一眼的。小时候第一次看到巧爷的骚操作真的是惊艳到终生难忘

![](./assets/v2-852ba705a51ab574083019e73a470814_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

