---
title: 优质男大部分真的都在大学里被女生预定了吗？
url: https://www.zhihu.com/question/657376611/answer/1937899808741364520
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 15:35
modified: 2025-08-10 15:35
upvote_num: 0
comment_num: 0
---

大学晚了

女生高中就开窍了，很多高中的时候就被预定走了

