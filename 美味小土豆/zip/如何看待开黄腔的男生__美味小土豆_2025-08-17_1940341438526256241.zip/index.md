---
title: 如何看待开黄腔的男生?
url: https://www.zhihu.com/question/601994600/answer/1940341438526256241
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 09:17
modified: 2025-08-17 09:17
upvote_num: 6
comment_num: 0
---

开黄腔是要凑在耳边，背着别人，轻轻说出来的。

