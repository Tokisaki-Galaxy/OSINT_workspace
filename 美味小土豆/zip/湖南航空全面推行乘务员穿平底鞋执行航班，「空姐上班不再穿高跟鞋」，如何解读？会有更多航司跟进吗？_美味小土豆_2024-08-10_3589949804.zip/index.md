---
title: 湖南航空全面推行乘务员穿平底鞋执行航班，「空姐上班不再穿高跟鞋」，如何解读？会有更多航司跟进吗？
url: https://www.zhihu.com/question/663576128/answer/3589949804
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-10 12:27
modified: 2024-08-10 12:27
upvote_num: 0
comment_num: 0
---

盐城

