---
title: 长得漂亮真的很重要吗？
url: https://www.zhihu.com/question/505809133/answer/1939278672545707073
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 10:54
modified: 2025-08-14 10:54
upvote_num: 0
comment_num: 0
---

很重要

说实话么你又不爱听

