---
title: 高个子女生真的不适合cos吗?
url: https://www.zhihu.com/question/1934267825083622776/answer/1934713317965960208
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-01 20:33
modified: 2025-08-01 20:33
upvote_num: 1188
comment_num: 36
---

高一米八的妹子要是出兔女郎在漫展上巨吸睛的好嘛!

