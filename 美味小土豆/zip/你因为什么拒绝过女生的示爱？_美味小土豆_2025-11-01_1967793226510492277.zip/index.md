---
title: 你因为什么拒绝过女生的示爱？
url: https://www.zhihu.com/question/626528327/answer/1967793226510492277
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-01 03:21
modified: 2025-11-01 03:21
upvote_num: 34
comment_num: 8
---

是冲着结婚去的，拒绝

想体验传统式恋爱的，拒绝

不好看的，拒绝

目测体重超过55kg的，拒绝

超过25岁的，无论什么条件都拒绝

是处女吗？是处女拒绝

看了看好像我要求不是特别高。

