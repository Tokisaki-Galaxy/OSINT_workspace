---
title: 国内为什么抵制早恋？比中国更抵制早恋的国家有哪些？
url: https://www.zhihu.com/question/457644696/answer/1986121119711900336
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-21 17:09
modified: 2025-12-21 17:09
upvote_num: 17
comment_num: 3
---

"你每天吃穿不愁，不用考虑生计，日常还能和初中生小姑娘牵手逛街亲嘴做爱"

你觉得成年人会乐意看到你这么开心？

![](./assets/v2-65a0a346c952ed1bbd2f0541449b9577_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

