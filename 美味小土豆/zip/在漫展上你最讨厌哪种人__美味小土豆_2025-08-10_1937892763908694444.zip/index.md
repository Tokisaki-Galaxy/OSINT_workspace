---
title: 在漫展上你最讨厌哪种人?
url: https://www.zhihu.com/question/613115238/answer/1937892763908694444
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 15:07
modified: 2025-08-10 15:07
upvote_num: 1
comment_num: 0
---

招呼都不打的就抽我身上的道具拿来把玩

