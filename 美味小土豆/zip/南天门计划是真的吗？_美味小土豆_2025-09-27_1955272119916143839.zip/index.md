---
title: 南天门计划是真的吗？
url: https://www.zhihu.com/question/492694856/answer/1955272119916143839
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 14:06
modified: 2025-09-27 14:06
upvote_num: 4
comment_num: 0
---

南天门计划要是真的，那nasa和中国航天就应该防备一下十一区的星一号作战计划和次世代机动战士开发计划了。

![](./assets/v2-fa143ea89c40bae0adb679e1efde7d7c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='1620'></svg>)

  


![](./assets/v2-adaf58ca8622b3d908298522f1919ac0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1919' height='1439'></svg>)

  


![](./assets/v2-e7c5d51b2a765cb54448a75d29c74723_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1067'></svg>)

