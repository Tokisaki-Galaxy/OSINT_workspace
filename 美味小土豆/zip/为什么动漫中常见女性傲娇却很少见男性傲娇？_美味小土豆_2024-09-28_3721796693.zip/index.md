---
title: 为什么动漫中常见女性傲娇却很少见男性傲娇？
url: https://www.zhihu.com/question/668055547/answer/3721796693
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-28 19:18
modified: 2024-09-28 19:18
upvote_num: 11
comment_num: 0
---

各种各样的宿敌

“哼！我不是来救你的，我只是不想看到你被这样的杂鱼干掉，你必须死在我的手里！”

这样的傲娇很多很多啊。

光奥特曼里就有一堆

