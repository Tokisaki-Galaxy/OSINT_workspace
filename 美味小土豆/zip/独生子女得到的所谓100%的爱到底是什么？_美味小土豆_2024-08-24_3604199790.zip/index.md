---
title: 独生子女得到的所谓100%的爱到底是什么？
url: https://www.zhihu.com/question/556714928/answer/3604199790
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 02:35
modified: 2024-08-24 02:35
upvote_num: 5
comment_num: 0
---

我一直告诫我自己“在外面绝对不能闯祸，如果我闯了什么大祸，会连累我爹妈砸锅卖铁的”

我好像从来没想过我爹妈会不救我这个情况……

