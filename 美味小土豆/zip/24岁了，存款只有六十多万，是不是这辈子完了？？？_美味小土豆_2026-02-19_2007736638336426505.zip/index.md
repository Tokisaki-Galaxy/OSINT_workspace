---
title: 24岁了，存款只有六十多万，是不是这辈子完了？？？
url: https://www.zhihu.com/question/680125812/answer/2007736638336426505
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-19 08:41
modified: 2026-02-19 08:41
upvote_num: 17
comment_num: 0
---

24岁就这么会装会气人你这辈子确实完了

