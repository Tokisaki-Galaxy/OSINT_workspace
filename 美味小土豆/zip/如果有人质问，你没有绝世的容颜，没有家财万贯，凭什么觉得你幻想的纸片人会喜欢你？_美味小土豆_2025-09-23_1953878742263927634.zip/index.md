---
title: 如果有人质问，你没有绝世的容颜，没有家财万贯，凭什么觉得你幻想的纸片人会喜欢你？
url: https://www.zhihu.com/question/5022088405/answer/1953878742263927634
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-23 17:49
modified: 2025-09-23 17:49
upvote_num: 7
comment_num: 2
---

因为我的纸片人oc是综合了我各个前女友的特征缝合出来的。

黑皮，双马尾，疯批，雌小鬼，能成为我的妈妈。

我这一刻和她提分手，她下一刻就能杀掉我。

![](./assets/v2-813164f7aa153c809b7e4b1cc5e883a6_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='800'></svg>)

