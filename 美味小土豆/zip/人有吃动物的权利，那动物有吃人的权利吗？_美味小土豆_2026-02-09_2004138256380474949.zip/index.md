---
title: 人有吃动物的权利，那动物有吃人的权利吗？
url: https://www.zhihu.com/question/7661067035/answer/2004138256380474949
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-09 10:23
modified: 2026-02-09 10:23
upvote_num: 14
comment_num: 0
---

动物吃你之前不会和你讲它有没有权利的，它吃你就吃你了，很自由的

不过你有打死它的权利呀。

你自己放弃这个权利让动物自由的吃是你的自由。

但是我们人类是有为了不被吃而打死动物的权利的。

