---
title: 上海人真的都比较有钱吗？
url: https://www.zhihu.com/question/312160591/answer/1940350724560122160
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 09:54
modified: 2025-08-17 09:54
upvote_num: 0
comment_num: 0
---

上海人求稳不求富。

所以不会看起来很有钱，也不会乱花钱。

在上海，胡乱花钱的人叫冲头，会被鄙视的。

