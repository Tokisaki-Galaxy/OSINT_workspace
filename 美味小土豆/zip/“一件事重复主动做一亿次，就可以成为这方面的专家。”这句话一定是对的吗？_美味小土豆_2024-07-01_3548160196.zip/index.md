---
title: “一件事重复主动做一亿次，就可以成为这方面的专家。”这句话一定是对的吗？
url: https://www.zhihu.com/question/611144972/answer/3548160196
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-01 18:16
modified: 2024-07-01 18:16
upvote_num: 5
comment_num: 0
---

这绝对是一句屁话。如果你做一件事情一开始就抱有“一件事情重复做一亿次就一定能做好”，那大概率会失败，因为你已经决定不动脑子了。

