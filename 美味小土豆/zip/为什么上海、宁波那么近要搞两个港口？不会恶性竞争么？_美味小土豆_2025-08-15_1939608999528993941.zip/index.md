---
title: 为什么上海、宁波那么近要搞两个港口？不会恶性竞争么？
url: https://www.zhihu.com/question/26251763/answer/1939608999528993941
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 08:47
modified: 2025-08-15 08:47
upvote_num: 5
comment_num: 3
---

首先，先有的北仑港，北仑是很好的深水港。

其次，上海的洋山港是抢的浙江的，洋山港在舟山旁边，两个港还蛮远的。

最后，北仑港+上海港只是暂时够用

