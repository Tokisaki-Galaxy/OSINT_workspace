---
title: 鸡那么脏，那为啥鸡巢几乎没有蟑螂？
url: https://www.zhihu.com/question/1908102066179663619/answer/1937780182900531364
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 07:39
modified: 2025-08-10 07:39
upvote_num: 4
comment_num: 0
---

昆虫=愚蠢的人类

鸡=爱吃人类而且眼神很好捕猎欲异常旺盛的暴虐霸王龙

