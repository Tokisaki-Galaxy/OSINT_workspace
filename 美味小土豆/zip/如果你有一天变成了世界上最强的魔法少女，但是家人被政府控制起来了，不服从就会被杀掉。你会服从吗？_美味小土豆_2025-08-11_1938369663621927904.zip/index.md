---
title: 如果你有一天变成了世界上最强的魔法少女，但是家人被政府控制起来了，不服从就会被杀掉。你会服从吗？
url: https://www.zhihu.com/question/6637285591/answer/1938369663621927904
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-11 22:42
modified: 2026-03-12 16:45
upvote_num: 1511
comment_num: 92
---

"呐~首相大人，偷偷的告诉你，你的家人，已经全部被杀掉了哟，女儿~妻子~全部，全部都死掉了呢。可怜的小妹妹，一直哭着在喊爸爸救命直到断气呢，太太那不甘心的样子，真的好好笑呀~

再给你们一分钟哦~现在，要好好想办法努力让全人类活下来呀"

啊……我居然还能念完这段台词，好久没配音了（捂脸）

![](./assets/v2-5dd1ae57517d1a48d7e21353c8122fd5_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='2048'></svg>)

  


[![](./assets/v2-667423c59ad39a5cc6ce756da03624f7_720w.jpg)如果哪天变成了魔法少女我一定要自己念台词https://www.zhihu.com/video/2015468293008414342](https://link.zhihu.com/?target=https%3A//www.zhihu.com/video/2015468293008414342)

