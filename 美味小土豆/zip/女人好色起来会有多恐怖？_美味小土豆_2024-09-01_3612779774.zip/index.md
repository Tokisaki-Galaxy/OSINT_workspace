---
title: 女人好色起来会有多恐怖？
url: https://www.zhihu.com/question/660463597/answer/3612779774
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-01 19:59
modified: 2024-09-01 20:03
upvote_num: 9
comment_num: 1
---

我高中时的前女友，爱称床上小轰龙，x高小亚衣。

[女朋友是体育生是一种什么体验？](https://www.zhihu.com/question/63067145/answer/3611173887?utm_psn=1813667142735904769)

玩过怪猎和知道上原亚衣老师的应该都懂。

对肉欲的渴望到了恐怖的地步，无非也就是和tigrex一样了！

——————————这个是轰龙———————

![](./assets/v2-379a9001890079713587147c6a443dba_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1984' height='1125'></svg>)

  


![](./assets/v2-0a63bcfb91b16ea0e3a71331dc6f5e0d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='628'></svg>)

————————这个是亚衣老师———————

![](./assets/v2-4d64df86ed6419b461346ac83a7c7eb7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='510' height='404'></svg>)

。

