---
title: 为什么很多年轻女性喜欢自称脾气不好?
url: https://www.zhihu.com/question/323936090/answer/1936403315190640853
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-06 12:28
modified: 2025-08-06 12:28
upvote_num: 3
comment_num: 0
---

其实，只要不是自称脾气不好还要硬跟过来。而是能接受别人扭头就走或者是"她太古怪了，不要带她一起"的话，我觉得这是一个很好的优点。

