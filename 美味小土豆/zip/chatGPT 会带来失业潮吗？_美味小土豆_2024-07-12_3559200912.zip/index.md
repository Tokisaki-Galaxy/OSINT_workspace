---
title: chatGPT 会带来失业潮吗？
url: https://www.zhihu.com/question/582933780/answer/3559200912
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-12 07:05
modified: 2024-07-12 07:05
upvote_num: 1
comment_num: 0
---

这是我的工作

![](./assets/v2-8069a8d2d7de6c750952b3edf4cdb7b9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1328' height='144'></svg>)

这是我的工作里ai能完成的部分

![](./assets/v2-29a1168913d74dfcf5cefe8f986b91bf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1357' height='385'></svg>)

我现在愿望就是顾客能对第一条更宽容一点。ai出图真的让设计的速度变快了很多，也少了很多和画师沟通的环节，更重要的是节约了“我是作者，这是我的作品，你们不许瞎改我的作品”的沟通环节。如果顾客这里能对ai更宽容一点，就可以用ai做商业企划了，本来需要一整个团队来完成的内容，现在一个人就能完成了。但是现在顾客对于ai的态度，这样的事情做的时候只能遮遮掩掩的，希望ai在这方面的进化速度能更快一点吧。

以及不知道什么时候ai可以攻克我工作后面的流程，这样我就能从黑心老板这里跳槽自己开公司了。

