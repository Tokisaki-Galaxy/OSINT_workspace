---
title: 试问，一个男孩子愿意放下面子为女孩子买卫生巾是真爱吗?
url: https://www.zhihu.com/question/536188565/answer/3575624608
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-27 22:35
modified: 2024-07-27 22:35
upvote_num: 1
comment_num: 0
---

帮女生买卫生巾都算“放下面子”的话，买验孕棒的时候怎么办？带面罩吗？

