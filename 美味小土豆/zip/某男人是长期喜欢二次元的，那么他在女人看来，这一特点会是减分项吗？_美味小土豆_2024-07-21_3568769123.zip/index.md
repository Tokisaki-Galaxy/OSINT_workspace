---
title: 某男人是长期喜欢二次元的，那么他在女人看来，这一特点会是减分项吗？
url: https://www.zhihu.com/question/615787880/answer/3568769123
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 14:35
modified: 2024-07-21 14:35
upvote_num: 4
comment_num: 3
---

不加分不减分。重点看他其他的成分。

os：根据我的经验，用机器人动画头像的人要比用动漫美少女头像的人更杠一点。

没有任何歧视，单纯就事论事。

