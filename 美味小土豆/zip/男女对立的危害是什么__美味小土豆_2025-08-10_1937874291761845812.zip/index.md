---
title: 男女对立的危害是什么?
url: https://www.zhihu.com/question/1933438301198590643/answer/1937874291761845812
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 13:53
modified: 2025-08-10 13:53
upvote_num: 11
comment_num: 0
---

有些行业会收入大减少

补课机构，学校，幼儿园，承办婚礼的机构，婚照等等。

好像伯爵旅拍已经破产了？

