---
title: 这种游戏角色放在90年代是否会有争议？
url: https://www.zhihu.com/question/1936784259949003429/answer/1938151703158429248
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-11 08:16
modified: 2025-08-11 08:20
upvote_num: 4
comment_num: 1
---

我15年玩的恶魔城月下，我爸和我说这是97年的游戏

然后玩着玩着我发现里面的梦魇是直接露奈子的!

后来又翻到了我爹的漆原智志的画集……哇，九十年代真的好黄!

![](./assets/v2-b7dc8ab518eb278464b6ce085e809d3b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='3000' height='4000'></svg>)

对了我爸还说过当年电视台放的宇宙骑士全裸变身是不剪的……

