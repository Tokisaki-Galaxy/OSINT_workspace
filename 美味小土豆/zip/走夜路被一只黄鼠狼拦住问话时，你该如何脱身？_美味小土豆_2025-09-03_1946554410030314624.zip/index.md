---
title: 走夜路被一只黄鼠狼拦住问话时，你该如何脱身？
url: https://www.zhihu.com/question/440965402/answer/1946554410030314624
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 12:45
modified: 2025-09-03 12:45
upvote_num: 241
comment_num: 7
---

黄鼠狼？

快，快点问我那句话，我现在就脱！

![](./assets/v2-03e85a9ffa6e38b14fec732049ee6cd1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='683' height='1200'></svg>)

