---
title: 为什么李新野如此渴望女人，哪怕他再有钱也找不到对他好的美女？
url: https://www.zhihu.com/question/1977426181553934621/answer/1979222103434760310
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-02 16:15
modified: 2025-12-02 16:15
upvote_num: 83
comment_num: 1
---

因为女人就是这么混沌的。

她对你好可能是因为任何原因，也有可能是不因为任何原因。

拿钱买爱是这个世界上最抽象的事情。

约等于你放弃了被爱的可能性了。

