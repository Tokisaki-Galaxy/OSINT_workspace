---
title: 有没有你们认为很飒的动画女生（附图），你觉得她最飒的一幕是什么?
url: https://www.zhihu.com/question/367364577/answer/1956090673095742396
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 20:19
modified: 2025-09-29 20:19
upvote_num: 1
comment_num: 1
---

![](./assets/v2-62873ff70e8e5fae701374159d499971_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

  


![](./assets/v2-a013785ff638a3a16f39d9036cf8b331_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

有句说句，我爸推荐漫画的品味真的很高

