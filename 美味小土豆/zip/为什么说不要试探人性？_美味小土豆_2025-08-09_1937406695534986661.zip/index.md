---
title: 为什么说不要试探人性？
url: https://www.zhihu.com/question/561103298/answer/1937406695534986661
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-09 06:55
modified: 2025-08-09 06:55
upvote_num: 77
comment_num: 0
---

因为很多预设都是假定了一个很操蛋的场景，都是冲着把正常人逼疯了逼急了去的，末了再来一句"看，人性就是经不起考验的"。

那我还要说"我不认可你任何傻逼预设和假定！"

