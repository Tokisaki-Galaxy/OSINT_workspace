---
title: 小红书很多人说男人低于180长的再帅也不是大帅哥，是真的吗?
url: https://www.zhihu.com/question/1951180782430290217/answer/1967664221195079768
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-31 18:48
modified: 2025-10-31 18:48
upvote_num: 7
comment_num: 0
---

帅比180重要的多的多的多!

帅可以让你即使身高不到170，生活也能多姿多彩。

但是只有180不行。

