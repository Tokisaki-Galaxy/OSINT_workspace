---
title: 金亨泰用 AI 画明日香贺图，惹怒《尼尔》设计师松田义，这反映了 AI 绘画在艺术界存在哪些争议？
url: https://www.zhihu.com/question/2011102376086491344/answer/2013979412605968856
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-08 14:08
modified: 2026-03-08 14:08
upvote_num: 126
comment_num: 9
---

你哪怕文笔再差，写情书用ai生成的给女朋友，她也是会生气的……

