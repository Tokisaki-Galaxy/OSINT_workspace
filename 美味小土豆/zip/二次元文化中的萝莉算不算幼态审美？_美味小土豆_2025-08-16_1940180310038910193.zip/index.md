---
title: 二次元文化中的萝莉算不算幼态审美？
url: https://www.zhihu.com/question/657067396/answer/1940180310038910193
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 22:37
modified: 2025-08-16 22:37
upvote_num: 270
comment_num: 47
---

上次我说我喜欢这样娇小可爱，一只手就能抱起来的乖巧女孩子。

你们就骂我是变态！

![](./assets/v2-800a1d6d8ef9a71cd8e385b9b92b663d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-a6e358b6e2626b727463fce94c188ad4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-4b6641932a7c01275098472b544c5c69_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-f6d258e8a28b963a921a6308e25354bd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-4c54c1080715a6fa924636fd73160831_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1200'></svg>)

  


![](./assets/v2-961eff428d4072a421d40fc97058e725_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1024'></svg>)

  


![](./assets/v2-e8bc9793ad548ce5b4348df3f7ac8452_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1200'></svg>)

