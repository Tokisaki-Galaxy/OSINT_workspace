---
title: 每一个男的都或多或少庆幸自己是男的吧?
url: https://www.zhihu.com/question/12868412715/answer/1956068652777469198
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 18:51
modified: 2025-09-29 18:51
upvote_num: 9
comment_num: 3
---

我庆幸我妈给我的颜值身高和我爸给我的生活条件以及我从小无忧无虑的童年还有想得很开的性格。

我无论是男是女都能活得很好。

