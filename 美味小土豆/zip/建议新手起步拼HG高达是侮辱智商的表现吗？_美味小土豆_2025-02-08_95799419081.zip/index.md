---
title: 建议新手起步拼HG高达是侮辱智商的表现吗？
url: https://www.zhihu.com/question/381519796/answer/95799419081
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-02-08 14:59
modified: 2025-02-08 14:59
upvote_num: 1
comment_num: 0
---

玩玩具首先是要玩得开心，一把钳子就能舒服拼完一个的体验才是根本，所以我一般都推荐新人买hguc和ce的新生系列。

