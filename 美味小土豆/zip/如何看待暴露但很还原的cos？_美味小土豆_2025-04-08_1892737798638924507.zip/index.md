---
title: 如何看待暴露但很还原的cos？
url: https://www.zhihu.com/question/314612400/answer/1892737798638924507
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 00:37
modified: 2025-04-08 00:37
upvote_num: 2
comment_num: 0
---

穿再暴露穿兔女郎装也要挂透明肩带——因为这点，所以很多coser都给人一种硬装碧池大姐姐的可爱感。

