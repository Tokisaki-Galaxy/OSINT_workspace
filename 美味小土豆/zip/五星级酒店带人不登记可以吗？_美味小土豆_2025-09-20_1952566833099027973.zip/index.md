---
title: 五星级酒店带人不登记可以吗？
url: https://www.zhihu.com/question/605447402/answer/1952566833099027973
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-20 02:56
modified: 2025-09-20 02:56
upvote_num: 8
comment_num: 0
---

五星级酒店你从大堂去电梯是没有人会问你的。

所以有些穷逼开impart就会找五星级酒店。

只要不被隔壁举报就很安全。

