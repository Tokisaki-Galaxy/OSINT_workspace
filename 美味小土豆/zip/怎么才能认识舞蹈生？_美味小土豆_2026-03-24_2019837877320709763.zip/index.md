---
title: 怎么才能认识舞蹈生？
url: https://www.zhihu.com/question/636848308/answer/2019837877320709763
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-24 18:07
modified: 2026-03-24 18:07
upvote_num: 386
comment_num: 13
---

这事情蛮简单的，我从小总结出来的经验：

你想认识礼仪队的妹子就让自己也进礼仪队，你想认识舞蹈生就让自己也进舞蹈社，啊，进模特班也可以。

想认识coser最好的办法就是自己去当男coser。

你自己能混进这个圈子了想认识哪个就能认识哪个。

