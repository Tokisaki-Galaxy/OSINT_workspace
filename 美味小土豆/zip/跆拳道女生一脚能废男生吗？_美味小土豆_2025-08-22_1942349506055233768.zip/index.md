---
title: 跆拳道女生一脚能废男生吗？
url: https://www.zhihu.com/question/4253468531/answer/1942349506055233768
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-22 22:16
modified: 2025-08-22 22:16
upvote_num: 13
comment_num: 0
---

抓住跆拳道女生的脚往上一提就是一字马

还挺方便的……

"少女啊，你是即食罐头吗？"

