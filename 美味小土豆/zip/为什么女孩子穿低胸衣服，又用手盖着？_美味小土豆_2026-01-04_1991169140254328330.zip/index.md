---
title: 为什么女孩子穿低胸衣服，又用手盖着？
url: https://www.zhihu.com/question/607762777/answer/1991169140254328330
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-04 15:28
modified: 2026-01-04 15:28
upvote_num: 115
comment_num: 13
---

真的，还是遮一下好。

每次遇到穿低胸衣服的妹子大大咧咧的挺着雪白的奈子肆无忌惮的抬头和我聊天的时候……

我都只能尴尬的把目光别到一旁去。

会下意识遮住的真是小天使了。

