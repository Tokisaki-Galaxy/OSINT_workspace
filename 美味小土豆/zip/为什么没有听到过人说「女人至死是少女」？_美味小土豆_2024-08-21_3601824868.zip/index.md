---
title: 为什么没有听到过人说「女人至死是少女」？
url: https://www.zhihu.com/question/585400980/answer/3601824868
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-21 19:36
modified: 2024-08-21 19:36
upvote_num: 3
comment_num: 1
---

因为男性可以只靠折腾自己就让自己开心

而能折腾自己让自己开心而不是靠折腾别人让自己开心的女性都是天使，我愿她们一生都是少女。

