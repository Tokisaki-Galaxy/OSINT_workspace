---
title: 不懂为什么批判白幼瘦?
url: https://www.zhihu.com/question/14581894068/answer/1939823327385452806
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 22:58
modified: 2025-08-15 22:58
upvote_num: 3
comment_num: 0
---

白瘦幼超可爱的，小小软软的一只，腿又直又细，纤细的手腕仿佛没有骨头一样，平坦的小腹加上洁白的皮肤，就像丝绸一样柔软。

像洋娃娃一样可爱，像小鸟一样乖巧。

男人就是喜欢这一款呀。

看，讲实话么你又要急。

![](./assets/v2-47f6fd90fc4d7d69fb18c0a792e1e7f4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

  


![](./assets/v2-fcdc23318a4051a9349dc8b85b6f1764_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

