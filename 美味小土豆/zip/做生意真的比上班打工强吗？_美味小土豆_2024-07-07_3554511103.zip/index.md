---
title: 做生意真的比上班打工强吗？
url: https://www.zhihu.com/question/327874416/answer/3554511103
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-07 20:56
modified: 2024-07-07 20:56
upvote_num: 2
comment_num: 0
---

打工只有死工资，做生意可能会有大量的资金流。有的人在生意失败前起码能爽一波资金流，这种爽度就不是上班能比拟得了。所以有些人一而再的失败但还是会一而再的沉迷创业。

