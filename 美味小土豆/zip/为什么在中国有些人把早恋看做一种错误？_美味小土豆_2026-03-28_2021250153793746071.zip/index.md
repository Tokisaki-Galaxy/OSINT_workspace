---
title: 为什么在中国有些人把早恋看做一种错误？
url: https://www.zhihu.com/question/498837809/answer/2021250153793746071
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-28 15:39
modified: 2026-03-28 15:39
upvote_num: 6
comment_num: 2
---

因为在某些人眼里，在校女生就是为那些成为合格牛马的做题家准备的奖品。

所以对于那些在成为合格牛马前就想提前偷吃的人。

某些人当然会怒不可遏的觉得他们罪该万死咯~

