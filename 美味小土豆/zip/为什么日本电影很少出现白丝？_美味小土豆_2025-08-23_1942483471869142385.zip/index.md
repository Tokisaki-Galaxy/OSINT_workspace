---
title: 为什么日本电影很少出现白丝？
url: https://www.zhihu.com/question/658268545/answer/1942483471869142385
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 07:09
modified: 2025-08-23 07:09
upvote_num: 16
comment_num: 0
---

白丝要腿很瘦很直才行。

除了cosplay必须还原角色，一般不会这么折腾自己。

