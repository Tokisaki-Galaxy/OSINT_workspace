---
title: 为什么当代年轻人喜欢摆烂？
url: https://www.zhihu.com/question/1896352266681819821/answer/1934433599077189151
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-01 02:01
modified: 2025-08-01 02:01
upvote_num: 12
comment_num: 0
---

如果你给的活靠谱，流程明确，工资开得正常，干活不瞎折腾人。年轻人还是很乐意干的，甚至会努力一下看看自己能不能做得更好。

自己就很烂了就不要抱怨年轻人摆烂了，年轻人只是不想让自己过得也很烂

