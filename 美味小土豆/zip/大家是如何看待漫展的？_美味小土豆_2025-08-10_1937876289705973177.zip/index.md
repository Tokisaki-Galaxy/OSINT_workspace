---
title: 大家是如何看待漫展的？
url: https://www.zhihu.com/question/659313444/answer/1937876289705973177
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:01
modified: 2025-08-10 14:01
upvote_num: 1
comment_num: 0
---

同好交流会

很开心的同好交流会

兼xx城市三日游

漫展又可以交到朋友还能得到别人的认可，超开心的

