---
title: 四川乐山公交车标语惹争议「贞洁，是女孩最高贵的嫁妆」，后半句是「贞洁，是男孩最高贵的聘礼」，怎么看？
url: https://www.zhihu.com/question/2020047258821862804/answer/2021191028015637266
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-28 11:44
modified: 2026-03-28 11:54
upvote_num: 0
comment_num: 0
---

看来是真的有人急了……

![](./assets/v2-83890fea9a5a1b31da42a3aedad33e58_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

