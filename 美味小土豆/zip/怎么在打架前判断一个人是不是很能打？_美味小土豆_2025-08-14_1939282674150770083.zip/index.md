---
title: 怎么在打架前判断一个人是不是很能打？
url: https://www.zhihu.com/question/24037838/answer/1939282674150770083
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 11:10
modified: 2025-08-14 11:10
upvote_num: 0
comment_num: 0
---

我判断不出来的

一般第一拳没把我呼地上，我就知道尚有一战之力！

