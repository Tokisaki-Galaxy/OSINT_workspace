---
title: 四十岁的人还在玩高达模型是不是很幼稚？
url: https://www.zhihu.com/question/518864296/answer/1935388622330242705
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-03 17:16
modified: 2025-08-03 17:16
upvote_num: 15
comment_num: 0
---

世界模型大赛得奖的很多都是四五十岁朝上的老登。

这帮人有钱有经验啊

