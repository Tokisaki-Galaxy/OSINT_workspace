---
title: 为什么总有人认为应试教育不会牺牲想象力和求知欲？
url: https://www.zhihu.com/question/12708071267/answer/1962996799578052333
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-18 21:41
modified: 2025-10-18 21:41
upvote_num: 8
comment_num: 0
---

一个会认为"应试教育会摧毁我的想象力"的人

通常也会是一个把"你凭什么觉得我的想法就错的?就因为我没读过书吗？"挂在嘴边的人。

这种人的想象力大多数时候都是一无是处的臆想。

