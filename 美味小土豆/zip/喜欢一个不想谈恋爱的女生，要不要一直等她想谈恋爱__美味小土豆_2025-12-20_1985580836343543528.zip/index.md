---
title: 喜欢一个不想谈恋爱的女生，要不要一直等她想谈恋爱?
url: https://www.zhihu.com/question/632024053/answer/1985580836343543528
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-20 05:22
modified: 2025-12-20 05:22
upvote_num: 9
comment_num: 0
---

TMD，世界上有那么多人类，你们就一定要吊死在一棵树上吗？！

还一直等她，你是长生种吗？啊？

连续两个这样莫名其妙的问题了！

先去搭讪100个人类，然后再来谈"我真的很喜欢她"这件事啊！

