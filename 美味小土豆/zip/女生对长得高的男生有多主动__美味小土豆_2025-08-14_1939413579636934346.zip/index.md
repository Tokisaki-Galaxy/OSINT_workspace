---
title: 女生对长得高的男生有多主动?
url: https://www.zhihu.com/question/652005397/answer/1939413579636934346
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 19:50
modified: 2025-08-14 19:50
upvote_num: 9
comment_num: 0
---

光长得高没用的。否则上海小姑娘最喜欢的应该是啦啦宝都的自由高达。

但只要你颜值正常，打扮干净得体，声音还能好听那么一点点。

哎~那身高就很占优势了!

