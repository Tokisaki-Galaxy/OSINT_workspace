---
title: 那些给hentai动漫配音的声优不会尴尬吗？
url: https://www.zhihu.com/question/388144862/answer/1937559749521543766
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-09 17:04
modified: 2025-08-09 17:04
upvote_num: 6
comment_num: 0
---

这玩意属于初次念会很羞耻了。

羞耻的重点是会质疑自己的声音是不是很恶心

一旦受众接受你的声音，就会越开越放开，而且会觉得很解压。

然后就会开始越来越变态

