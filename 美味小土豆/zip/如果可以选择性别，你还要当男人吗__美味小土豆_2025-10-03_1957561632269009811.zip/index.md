---
title: 如果可以选择性别，你还要当男人吗?
url: https://www.zhihu.com/question/12394454510/answer/1957561632269009811
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 21:44
modified: 2025-10-03 21:44
upvote_num: 5
comment_num: 2
---

我交往过的妹子有三分之一都说过想撅我

所以如果能选择性别的话，我还是选男的。

我才不要被她们撅得哭着求饶呢……

