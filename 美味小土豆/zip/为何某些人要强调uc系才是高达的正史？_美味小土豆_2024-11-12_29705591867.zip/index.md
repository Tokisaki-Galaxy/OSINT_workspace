---
title: 为何某些人要强调uc系才是高达的正史？
url: https://www.zhihu.com/question/37870993/answer/29705591867
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-11-12 21:38
modified: 2024-11-12 21:38
upvote_num: 0
comment_num: 0
---

说uc是正史，那么你是光头派还是军武派？你认为白色要塞是先打敖德萨再去的贾布罗还是先去贾布罗再参加的敖德萨？第一台RX78到底是RX78-1还是RX78-0？局地型高达到底哪冒出来的

uc正史？妈的uc自己都天天吃书！

