---
title: 你在游戏中见过颜值最高的杂兵有哪些?
url: https://www.zhihu.com/question/449194855/answer/1892955731080226188
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 15:03
modified: 2025-04-08 15:06
upvote_num: 747
comment_num: 34
---

老三国吞食天地2的三美啊！！

![](./assets/v2-8f975967e5acc501eebc3ef7cd1c0f0f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1697' height='1199'></svg>)

