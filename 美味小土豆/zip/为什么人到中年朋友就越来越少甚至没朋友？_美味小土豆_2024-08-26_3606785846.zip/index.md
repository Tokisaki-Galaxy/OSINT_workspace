---
title: 为什么人到中年朋友就越来越少甚至没朋友？
url: https://www.zhihu.com/question/365256729/answer/3606785846
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-26 19:21
modified: 2024-08-26 19:21
upvote_num: 4
comment_num: 0
---

人到中年，同龄的里面还愿意空下来单纯和你聊梦想聊爱好聊曾经的过往而不带任何目的的朋友就是会越来越少的

