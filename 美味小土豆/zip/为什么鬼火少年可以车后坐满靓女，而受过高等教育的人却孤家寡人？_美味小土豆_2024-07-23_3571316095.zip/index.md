---
title: 为什么鬼火少年可以车后坐满靓女，而受过高等教育的人却孤家寡人？
url: https://www.zhihu.com/question/422103372/answer/3571316095
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-23 21:21
modified: 2024-07-23 21:21
upvote_num: 6
comment_num: 0
---

别再拿知乎的重生小说脑补现实了

受过高等教育的校草和学霸在初中就能在甜品店和美少女一起赶作业并且谈着甜甜的恋爱了。

你没有是你自己的问题，这个锅高等教育和鬼火少年都不背

