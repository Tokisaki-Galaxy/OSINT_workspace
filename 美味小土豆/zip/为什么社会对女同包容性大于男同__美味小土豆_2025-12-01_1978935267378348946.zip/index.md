---
title: 为什么社会对女同包容性大于男同?
url: https://www.zhihu.com/question/1977453455166687078/answer/1978935267378348946
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 21:15
modified: 2025-12-01 21:15
upvote_num: 162
comment_num: 9
---

其实大家只是包容好看的人罢了。

你只要长得好看，无论是男同女同还是异性恋，都会有人给你摇旗呐喊。

如果你长得又丑又圆又自然，那不管你啥恋，别人都会觉得你既恶心又变态。

