---
title: 有哪些在日本非常火，但是在中国几乎没有知名度的动漫？
url: https://www.zhihu.com/question/664540985/answer/125446401142
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-16 11:08
modified: 2025-03-16 11:08
upvote_num: 1
comment_num: 0
---

宇宙战舰大和号呀

有趣的是很多人倒是都听过这个名字

