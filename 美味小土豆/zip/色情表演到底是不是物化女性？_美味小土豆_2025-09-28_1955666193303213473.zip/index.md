---
title: 色情表演到底是不是物化女性？
url: https://www.zhihu.com/question/626316490/answer/1955666193303213473
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 16:12
modified: 2025-09-28 16:12
upvote_num: 32
comment_num: 2
---

就是物化女性啊，有什么好扭扭捏捏的

女性什么时候最色?自我物化的时候呀。

这事都要站道德制高点就真的太拧巴了。

你们汴吧，我去抱我的小狗去了~

