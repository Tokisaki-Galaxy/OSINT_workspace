---
title: 男人长得帅和长得丑有什么区别？
url: https://www.zhihu.com/question/586705023/answer/1974820623151826834
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-20 12:45
modified: 2025-11-20 12:45
upvote_num: 31
comment_num: 5
---

如果你长得丑，钱对你来说就很重要很重要。

强调才华和品德没有意义，没有钱的前提下别人可能都不愿意深入了解你。

但即使你很有钱，别人内心也不会真的喜欢上你……

真的，这件事情还蛮残忍的。

