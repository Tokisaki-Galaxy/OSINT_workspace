---
title: 耍了三年的男朋友非要和我发生关系 可我不想 怎么办？
url: https://www.zhihu.com/question/4093678850/answer/2006701090050175397
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-16 12:07
modified: 2026-02-16 12:07
upvote_num: 10
comment_num: 0
---

笑死了，三年都没进展，性冷淡配养胃。

祝锁死~

