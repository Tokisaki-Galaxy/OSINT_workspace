---
title: 《黑猫警长》《葫芦娃》与同时期的外国动画相比，属于是什么水平？
url: https://www.zhihu.com/question/10591788503/answer/1963000707717243766
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-18 21:57
modified: 2025-10-18 21:57
upvote_num: 8
comment_num: 1
---

黑猫警长的作画比不过现在的异世界厕纸。

![](./assets/v2-54d7a084cfec9aec4adffe4cb8f7a472_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-bb412c4bbc9af8dcb7701ad456662b13_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

而现在的异世界厕纸和八十年代的日本动画相比就是一坨大便。

![](./assets/v2-bc691a9dc3f5336ed1514fbe1d20fb80_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-bdab1273068831af34a5aab3683c87ef_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


再讲下去话就难听了。

