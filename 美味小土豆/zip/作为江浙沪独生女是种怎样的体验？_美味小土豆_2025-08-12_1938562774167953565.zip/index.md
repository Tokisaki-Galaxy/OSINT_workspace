---
title: 作为江浙沪独生女是种怎样的体验？
url: https://www.zhihu.com/question/352745667/answer/1938562774167953565
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 11:29
modified: 2025-08-12 11:29
upvote_num: 0
comment_num: 0
---

江浙沪不要当成一个整体啊。

浙江，江苏，上海，三个地方的女生是完全不一样的。

光宁波的女生和海盐的女生就去是完全不一样的了，上海男生和宁波女生算门当户对，换成海盐的搞不好小姑娘家里就看不起你上海穷逼了。

