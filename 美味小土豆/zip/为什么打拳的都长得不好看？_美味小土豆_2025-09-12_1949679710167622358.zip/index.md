---
title: 为什么打拳的都长得不好看？
url: https://www.zhihu.com/question/1944713915410932815/answer/1949679710167622358
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 03:44
modified: 2025-09-12 03:44
upvote_num: 11
comment_num: 3
---

打不打拳我不知道，但是漂亮女生确实不媚男。

变态和媚男不是一个概念！

