---
title: 部分中国女性要求中国男性身高「至少180cm」，是否合理？
url: https://www.zhihu.com/question/418365188/answer/1938965588056733035
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 14:10
modified: 2025-08-13 14:10
upvote_num: 3
comment_num: 0
---

她们才管不管合理，她们就是要。

就像男人觉得带一个奈子很大的漂亮妹子出去很有面子一样。

她们就是觉得带一个高个子的出去自己依偎在旁边会很有面子，和挑猪仔一样……

