---
title: 把所有衣服从上到下从里到外都扔同一个洗衣机合适吗？
url: https://www.zhihu.com/question/9870679605/answer/1938859167260586455
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 07:07
modified: 2025-08-13 07:07
upvote_num: 0
comment_num: 0
---

我朋友的jk裙内衣和我的T恤裤子我都一块洗的……

