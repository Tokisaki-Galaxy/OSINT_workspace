---
title: 男人 有钱和帅哪个更重要？
url: https://www.zhihu.com/question/21740734/answer/3545056573
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-06-28 14:54
modified: 2024-06-28 14:54
upvote_num: 0
comment_num: 0
---

得看双商，如果双商低的话选钱，双商高的话选帅，搞不好你会更有钱。

