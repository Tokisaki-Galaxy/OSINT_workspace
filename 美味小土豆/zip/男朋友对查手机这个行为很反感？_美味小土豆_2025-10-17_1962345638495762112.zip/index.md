---
title: 男朋友对查手机这个行为很反感？
url: https://www.zhihu.com/question/1959793160436848204/answer/1962345638495762112
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-17 02:34
modified: 2025-10-17 02:38
upvote_num: 12
comment_num: 2
---

我不仅能接受查手机，我甚至愿意积极和对方分享我的作战记录。

我甚至用这样的坦然开过一个小后宫。

我甚至有段时间特别爱问"你能做我的第x号小女朋友嘛~"

这样搞可以很大概率的筛选掉特别爱翻你手机的作精。

耶!

![](./assets/v2-25ecde816bb2c6db3a32d59ffd38a50d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1640' height='1976'></svg>)

