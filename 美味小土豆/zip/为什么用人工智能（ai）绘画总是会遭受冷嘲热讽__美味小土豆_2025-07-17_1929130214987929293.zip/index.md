---
title: 为什么用人工智能（ai）绘画总是会遭受冷嘲热讽?
url: https://www.zhihu.com/question/1923771889144267111/answer/1929130214987929293
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-17 10:48
modified: 2025-07-17 10:48
upvote_num: 20
comment_num: 0
---

ai跑图是和你在游戏里捏脸，"输入文字得到你想要的ai老婆"这种一样等级的娱乐行为。

我很喜欢ai涩图，有些是真的好看，很多ai图确实有很有趣的想法

用ai是跑图玩，这不是绘画，自称"我用ai绘画"，这本身就很搞笑。

