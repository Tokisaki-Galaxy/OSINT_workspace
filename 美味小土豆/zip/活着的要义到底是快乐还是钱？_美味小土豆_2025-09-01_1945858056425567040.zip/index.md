---
title: 活着的要义到底是快乐还是钱？
url: https://www.zhihu.com/question/1925218096886550978/answer/1945858056425567040
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 14:38
modified: 2025-09-01 14:39
upvote_num: 1
comment_num: 0
---

快乐。

你每天活得很快乐，那么总有办法能挣到钱的。

如果实在挣不到钱。

没钱也有没钱的快乐。

我很多快乐都不是拿钱换来的

我还挺穷的

但我二十来岁的人生一直很快乐

