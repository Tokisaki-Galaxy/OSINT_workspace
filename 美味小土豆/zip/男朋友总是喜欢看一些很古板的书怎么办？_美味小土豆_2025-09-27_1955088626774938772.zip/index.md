---
title: 男朋友总是喜欢看一些很古板的书怎么办？
url: https://www.zhihu.com/question/1952564273160123530/answer/1955088626774938772
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 01:57
modified: 2025-09-27 01:58
upvote_num: 53
comment_num: 2
---

我也遇到过很爱看艰深难懂书籍的文学少女。

但是没关系，只要她愿意陪我看铁血大战异形并且不强迫我一起看她的书。

她就是可爱的!

