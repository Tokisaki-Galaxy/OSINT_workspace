---
title: 有钱真的会有底气吗?
url: https://www.zhihu.com/question/652080225/answer/1958198290312066199
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-05 15:54
modified: 2025-10-05 15:54
upvote_num: 24
comment_num: 7
---

那我活得很搞笑了。

我喜欢和任何一个我认识的人说"没钱"，然后看她/他的反应。

我发现自从理直气壮的说出自己很穷以后。我的人生就活得特别快乐轻松。

——"和我出来玩请一定带好钱，否则我们只能饿肚子逛马路了"

