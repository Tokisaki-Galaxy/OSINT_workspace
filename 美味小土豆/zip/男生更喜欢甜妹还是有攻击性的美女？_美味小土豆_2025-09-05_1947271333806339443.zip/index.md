---
title: 男生更喜欢甜妹还是有攻击性的美女？
url: https://www.zhihu.com/question/1947232354419609977/answer/1947271333806339443
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 12:14
modified: 2025-09-05 12:14
upvote_num: 1
comment_num: 0
---

我喜欢攻击性巨强会刀人的疯批甜妹

![](./assets/v2-340314675f5f3eebcab4f99394fdedbf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

