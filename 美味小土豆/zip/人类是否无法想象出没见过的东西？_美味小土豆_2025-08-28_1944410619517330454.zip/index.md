---
title: 人类是否无法想象出没见过的东西？
url: https://www.zhihu.com/question/316680205/answer/1944410619517330454
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-28 14:46
modified: 2025-08-28 14:46
upvote_num: 25
comment_num: 4
---

纯粹的爱情?

没有钱，没有房，没有车，也是能谈恋爱的呀

有没有可能。

谈恋爱的重点，是你这个人啊

