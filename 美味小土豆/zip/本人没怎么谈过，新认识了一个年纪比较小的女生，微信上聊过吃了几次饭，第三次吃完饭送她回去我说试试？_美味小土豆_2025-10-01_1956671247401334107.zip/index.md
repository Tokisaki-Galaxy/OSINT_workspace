---
title: 本人没怎么谈过，新认识了一个年纪比较小的女生，微信上聊过吃了几次饭，第三次吃完饭送她回去我说试试？
url: https://www.zhihu.com/question/1948680668327417124/answer/1956671247401334107
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 10:46
modified: 2025-10-01 10:46
upvote_num: 3
comment_num: 1
---

"陪我去酒吧谈心！怎么?半小时都不肯为我付出？"

哇你也太油腻了吧……

