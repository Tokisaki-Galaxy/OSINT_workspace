---
title: 抛开道德，抛开一切束缚，让你畅所欲言，你想要什么？
url: https://www.zhihu.com/question/641915294/answer/1912414579541139936
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-01 07:46
modified: 2025-06-01 07:46
upvote_num: 0
comment_num: 0
---

一万发波动炮炸死你们所有人！

