---
title: 女朋友现在问我：你有了一个竞争对手你会怎么办?
url: https://www.zhihu.com/question/3543331452/answer/1938472899657830936
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 05:32
modified: 2025-08-12 05:32
upvote_num: 127
comment_num: 3
---

我老板和我说过

"如果一个甲方和你说你和竞争对手b各出一版，谁做的好用谁的，前期费用甲方一分钱都不出"

这种生意不要接，他大饼画得再大都不要接。

