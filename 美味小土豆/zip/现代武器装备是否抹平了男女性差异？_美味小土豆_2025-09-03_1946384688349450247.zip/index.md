---
title: 现代武器装备是否抹平了男女性差异？
url: https://www.zhihu.com/question/1898075759341469940/answer/1946384688349450247
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 01:31
modified: 2025-09-03 01:32
upvote_num: 143
comment_num: 3
---

和女生玩过wargame吗？

我能1vs4。

女生持枪跑动射击再跑动的可持续时长，只有一分钟。

无论放冷枪还是扫射都会让她们停下来。

大部分女生连模型枪都拿不动

和女生枪战比肉搏好搞定得多。

