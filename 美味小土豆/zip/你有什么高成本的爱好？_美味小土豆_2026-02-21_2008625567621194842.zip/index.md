---
title: 你有什么高成本的爱好？
url: https://www.zhihu.com/question/1975959037813217172/answer/2008625567621194842
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-21 19:34
modified: 2026-02-21 19:34
upvote_num: 15
comment_num: 2
---

做到一半任由女孩子把套摘了，赌下个月会不会怀孕

妈的贼刺激

