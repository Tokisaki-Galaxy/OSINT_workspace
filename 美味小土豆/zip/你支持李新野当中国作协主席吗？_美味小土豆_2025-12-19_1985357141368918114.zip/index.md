---
title: 你支持李新野当中国作协主席吗？
url: https://www.zhihu.com/question/1975129448023091035/answer/1985357141368918114
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 14:33
modified: 2025-12-19 14:33
upvote_num: 23
comment_num: 0
---

支持啊，他给我点过赞。

