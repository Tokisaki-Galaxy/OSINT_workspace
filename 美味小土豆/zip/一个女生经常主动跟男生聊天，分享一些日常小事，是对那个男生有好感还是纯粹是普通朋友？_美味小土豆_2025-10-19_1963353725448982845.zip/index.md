---
title: 一个女生经常主动跟男生聊天，分享一些日常小事，是对那个男生有好感还是纯粹是普通朋友？
url: https://www.zhihu.com/question/496346137/answer/1963353725448982845
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-19 21:20
modified: 2025-10-19 21:20
upvote_num: 51
comment_num: 6
---

女生对你有好感的时候会说"哎呀你现在能出来玩吗？"

而不是"在吗?可以聊天吗？"

