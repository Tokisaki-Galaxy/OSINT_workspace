---
title: 现在美女还是稀缺资源吗？
url: https://www.zhihu.com/question/1938905407943873880/answer/2019479513562620901
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-23 18:23
modified: 2026-03-23 18:23
upvote_num: 8
comment_num: 3
---

美女从来不是什么稀缺资源，天然美女也不是，年轻的美少女都不算什么稀缺资源，地球人口那么多，找漂亮的不难。

既聪明又漂亮的美少女都不算稀缺资源。我这辈子遇到过不少又聪明又漂亮的姑娘。

又聪明又漂亮又有钱也不算稀缺资源。

不，愿意给你花钱的也不算稀有，有钱漂亮还爱黏着你的jk大小姐我这辈子遇到的都能组成一个超级战队了。

地球人太多了，哪天要遇到一个漂亮的绿皮龙娘我觉得才叫稀缺资源。

![](./assets/v2-25564fe9f19cfaae23185a442a6d62f4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='896' height='1152'></svg>)

