---
title: 怎么看待网曝35岁三娃货车女司机月入6万住别墅?
url: https://www.zhihu.com/question/664982194/answer/3608165282
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-28 02:14
modified: 2024-08-28 02:16
upvote_num: 6
comment_num: 1
---

我对接的一些乙方小工作室也有两个人一个月四五万收入的。

他们就从来不会发到互联网上告诉别人自己做什么的。

我接私活一个月也能赚到三万。

我也从来不在互联网上和别人说我具体干嘛的，能怎么赚钱。

