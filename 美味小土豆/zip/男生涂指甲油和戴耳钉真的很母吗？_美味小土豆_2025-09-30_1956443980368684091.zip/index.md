---
title: 男生涂指甲油和戴耳钉真的很母吗？
url: https://www.zhihu.com/question/1953760046409295094/answer/1956443980368684091
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 19:43
modified: 2025-09-30 19:43
upvote_num: 4
comment_num: 5
---

戴耳钉肯定不母啊

这年头耳钉已经没法和不良联系到一起了吗?

指甲油确实有点抽象，高中的时候我很沉迷黑色指甲油，感觉很狂野，就被coser姐姐调戏过"少年你好骚啊"

