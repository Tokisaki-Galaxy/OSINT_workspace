---
title: 你觉得“杀富济贫”可不可取？
url: https://www.zhihu.com/question/1923421490747019567/answer/2013250503438517410
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-06 13:52
modified: 2026-03-06 13:53
upvote_num: 4
comment_num: 1
---

要是真的能平等的干掉每一个资本家把钱平均分给穷人的话。

我倒是不介意对我家也用均贫卡。

因为要是真能平等的创死每一个人的话，这样的乐子我绝对愿意看！

