---
title: 武大郎辛勤养家，扶养弟弟，没犯任何错误，就因为自己矮小，娶个漂亮老婆被杀了，就受几百年嘲讽，为什么？
url: https://www.zhihu.com/question/478154391/answer/1956430930928460179
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 18:51
modified: 2025-09-30 18:51
upvote_num: 7
comment_num: 1
---

哎哟，说来说去

谁愿意当武大郎？

没有吧

好了，那你帮武大郎说什么，都是一个笑话。

