---
title: 如何看待一月新番达尔文事变？
url: https://www.zhihu.com/question/1994884469627299254/answer/1996957890662114992
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-20 14:51
modified: 2026-01-20 14:51
upvote_num: 45
comment_num: 1
---

这玩意好丑，丑的我想揍它，没有任何道理

