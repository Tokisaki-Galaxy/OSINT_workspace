---
title: 初三的人可以和高三的人谈恋爱吗？
url: https://www.zhihu.com/question/373979714/answer/1981008252755014102
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-07 14:32
modified: 2025-12-07 14:32
upvote_num: 13
comment_num: 1
---

我觉得没什么问题吧

我初三的时候在和五年级的谈恋爱。

我高三的时候她正好……

哦不对那会她初二！

