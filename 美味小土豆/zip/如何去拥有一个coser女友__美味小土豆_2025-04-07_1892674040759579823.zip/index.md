---
title: 如何去拥有一个coser女友?
url: https://www.zhihu.com/question/611167431/answer/1892674040759579823
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-07 20:24
modified: 2025-04-07 20:24
upvote_num: 3
comment_num: 0
---

交一个女朋友，带她去玩cosplay呀

