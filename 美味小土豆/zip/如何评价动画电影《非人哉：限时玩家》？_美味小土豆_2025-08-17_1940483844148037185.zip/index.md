---
title: 如何评价动画电影《非人哉：限时玩家》？
url: https://www.zhihu.com/question/1939617318771598738/answer/1940483844148037185
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 18:43
modified: 2025-08-17 18:43
upvote_num: 21
comment_num: 0
---

第一次见到真人cos电龙那么像的

![](./assets/v2-77ca67fe282d79b75d0b5755ef579963_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1000' height='671'></svg>)

