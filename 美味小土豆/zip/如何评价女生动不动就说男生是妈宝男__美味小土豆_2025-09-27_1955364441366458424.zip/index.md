---
title: 如何评价女生动不动就说男生是妈宝男?
url: https://www.zhihu.com/question/398720211/answer/1955364441366458424
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 20:13
modified: 2025-09-27 20:13
upvote_num: 6
comment_num: 1
---

"那……我能叫你妈妈吗？"

