---
title: 你是否幻想过自己拥有一个空姐女朋友呢?
url: https://www.zhihu.com/question/663075650/answer/3591852026
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-12 13:18
modified: 2024-08-12 13:18
upvote_num: 3
comment_num: 0
---

空姐女友不如coser女友，毕竟coser大多愿意出空姐，而空姐可能只会和你抱怨她很累别折腾这些事情了

