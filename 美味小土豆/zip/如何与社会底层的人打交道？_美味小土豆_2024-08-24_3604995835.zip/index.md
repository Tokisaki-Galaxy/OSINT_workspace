---
title: 如何与社会底层的人打交道？
url: https://www.zhihu.com/question/61039229/answer/3604995835
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 23:07
modified: 2024-08-24 23:07
upvote_num: 15
comment_num: 2
---

md这问题看得我毛骨悚然。我这种每天要去老乡家里收计件零件又要开着垃圾车去倒垃圾还要去废品站买木板的人，在你乎看起来就和会用手机的贱民差不多了吧？

