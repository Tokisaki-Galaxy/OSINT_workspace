---
title: 什么叫生理性喜欢？
url: https://www.zhihu.com/question/595865100/answer/2018369358942970759
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-20 16:52
modified: 2026-03-20 16:52
upvote_num: 24
comment_num: 0
---

就是和她做爱以后，你还是愿意黏着她，把头埋在她的胸口，任由她一边轻轻的拨弄着你的头发，一边轻声细语的和你聊天。

而不是想着要马上离开。

你们商量着晚上要去吃什么，看什么电影，她说今晚她可以不回去，一直陪着你。

你开心极了，你们两个有一整晚聊不腻的话题，你们两个会用各种各样奇怪的姿势腻在床上，贴在一起，她无论和你分享什么你都兴致勃勃的，你觉得她无比可爱，一眸一笑都是那么的有趣，无论她说什么你都觉得好好玩。

![](./assets/v2-0932d9c2c48b1bfba6e87ac97fbcbbad_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='1000'></svg>)

