---
title: 我有个疑问，为什么抖音上很多coser或者女生自己作品不擦边，但是摄影师账号里的她们却在擦边?
url: https://www.zhihu.com/question/1965561415881458692/answer/1965571866052793296
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 00:14
modified: 2025-10-26 00:14
upvote_num: 8
comment_num: 2
---

大部分情况是自己的账号引流，摄影师的切片卖钱。

这样将来想切割从良也能说是摄影师的锅

