---
title: 女生衣着覆盖率 30% 真的不适合去公共场合吗？
url: https://www.zhihu.com/question/638777886/answer/1954237834492884820
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-24 17:36
modified: 2025-09-24 17:36
upvote_num: 11
comment_num: 1
---

本逆兔爱好者看到这个问题挺一言难尽的

![](./assets/v2-8f554f8f1729bed822ae8086dce14737_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2290' height='3635'></svg>)

