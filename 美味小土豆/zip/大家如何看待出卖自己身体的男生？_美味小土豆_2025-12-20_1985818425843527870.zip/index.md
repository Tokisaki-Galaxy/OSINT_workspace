---
title: 大家如何看待出卖自己身体的男生？
url: https://www.zhihu.com/question/1923276716362667459/answer/1985818425843527870
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-20 21:06
modified: 2025-12-20 21:06
upvote_num: 4
comment_num: 1
---

国内卖淫抓女不抓男，管同性恋不管异性恋。

也就是说，你在国内收女生钱和女生上床，好像是合法的……

很搞笑的。

