---
title: 为什么高达要用剑等冷兵器？
url: https://www.zhihu.com/question/21156779/answer/115081664117
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-03 13:35
modified: 2025-03-03 13:35
upvote_num: 35
comment_num: 5
---

如果你是一个机械设定师，那么哪怕你设计的是一台装甲核心那样的“硬核”sf机设，你都很难保证不给他配把刀。不管设定上它是什么远程炮击狙击高速强袭……总归会给他把刀让他摆个pose看看。

我都设计人形兵器了，还不让它摆个丢枪抽刀的pose？

