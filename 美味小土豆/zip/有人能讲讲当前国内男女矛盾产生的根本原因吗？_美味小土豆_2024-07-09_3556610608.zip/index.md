---
title: 有人能讲讲当前国内男女矛盾产生的根本原因吗？
url: https://www.zhihu.com/question/661027246/answer/3556610608
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-09 18:17
modified: 2024-07-09 18:17
upvote_num: 19
comment_num: 9
---

我个人怀疑是资本的运作。男性其实消费力是挺强的。性别对立可以极大的解放男性消费力。

个人怀疑本质原因就那么简单

