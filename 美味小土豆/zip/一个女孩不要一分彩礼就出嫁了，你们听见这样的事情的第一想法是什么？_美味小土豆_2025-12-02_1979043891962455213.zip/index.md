---
title: 一个女孩不要一分彩礼就出嫁了，你们听见这样的事情的第一想法是什么？
url: https://www.zhihu.com/question/1906593066879543180/answer/1979043891962455213
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-02 04:27
modified: 2025-12-02 04:27
upvote_num: 4
comment_num: 0
---

"哦，应该是上海人伐？"

