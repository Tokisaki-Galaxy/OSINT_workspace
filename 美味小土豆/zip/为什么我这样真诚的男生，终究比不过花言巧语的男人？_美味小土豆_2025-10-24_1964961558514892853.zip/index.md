---
title: 为什么我这样真诚的男生，终究比不过花言巧语的男人？
url: https://www.zhihu.com/question/1963447605095806227/answer/1964961558514892853
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-24 07:49
modified: 2025-10-24 07:49
upvote_num: 17
comment_num: 0
---

你太过真诚，女人会怕你连自己的小家庭和身边人一起卖给外人。

女人不怕你会骗人会撒谎。她们最怕你其实对谁都不会撒谎。

