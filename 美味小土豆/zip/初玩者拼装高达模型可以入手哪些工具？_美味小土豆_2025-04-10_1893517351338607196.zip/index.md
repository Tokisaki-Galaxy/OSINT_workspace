---
title: 初玩者拼装高达模型可以入手哪些工具？
url: https://www.zhihu.com/question/22460504/answer/1893517351338607196
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-10 04:15
modified: 2025-04-10 04:15
upvote_num: 0
comment_num: 0
---

一把剪钳一把镊子一把笔刀一沓砂纸就够了，这时候拼模型绝对是最开心的娱乐

往上每添一样东西你就会多一份焦虑和心思，最后你就再也不会想拼模型了

