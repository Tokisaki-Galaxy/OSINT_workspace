---
title: 前中国拳击冠军华人周润琪在澳洲遇袭昏迷，我们普通人练武还有什么意义？
url: https://www.zhihu.com/question/1962625786759606576/answer/1963343508577423592
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-19 20:39
modified: 2025-10-19 20:39
upvote_num: 13
comment_num: 0
---

练武在你动手前从来都没什么用的。

出门在外能保护自己的永远是高大的体型和莫名其妙生人勿近的气场。

这样还不会赔钱。

