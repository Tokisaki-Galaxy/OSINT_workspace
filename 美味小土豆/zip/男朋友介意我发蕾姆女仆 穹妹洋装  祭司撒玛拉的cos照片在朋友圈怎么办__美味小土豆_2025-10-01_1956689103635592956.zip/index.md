---
title: 男朋友介意我发蕾姆女仆 穹妹洋装  祭司撒玛拉的cos照片在朋友圈怎么办?
url: https://www.zhihu.com/question/1956570071313921103/answer/1956689103635592956
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 11:57
modified: 2025-10-01 11:57
upvote_num: 8
comment_num: 2
---

你们这样拍，他肯定不介意（ai跑的图）

![](./assets/v2-f64f491a9f44d6df4d1bb4fedbb4938c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2730' height='1535'></svg>)

