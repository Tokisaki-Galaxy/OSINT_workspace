---
title: 怎么接受女朋友第一次给了别人？
url: https://www.zhihu.com/question/630388473/answer/1943652361215125320
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-26 12:33
modified: 2025-08-26 12:33
upvote_num: 8
comment_num: 0
---

你不想接受就不要去接受啊

怎么还自我pua上

如果你说"那我现在是爱着她的呀巴拉巴拉的……"

那你不就已经有答案了嘛。

这种事还要抱团取暖抱团分享我是没想到的

