---
title: 目前人类能为男权完全胜利做何种贡献?
url: https://www.zhihu.com/question/1912532665539752190/answer/1951747956316274918
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-17 20:42
modified: 2025-09-17 20:42
upvote_num: 2
comment_num: 0
---

什么解放不解放的

先好好为自己活着吧

活得像个人一样……

  


![](./assets/v2-0060d1f4d759f9ccdb58779d178d7a7c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

