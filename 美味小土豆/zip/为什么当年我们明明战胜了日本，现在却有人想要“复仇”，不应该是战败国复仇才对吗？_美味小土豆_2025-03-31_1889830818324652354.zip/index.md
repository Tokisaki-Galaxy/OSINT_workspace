---
title: 为什么当年我们明明战胜了日本，现在却有人想要“复仇”，不应该是战败国复仇才对吗？
url: https://www.zhihu.com/question/656493191/answer/1889830818324652354
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-31 00:06
modified: 2025-03-31 00:06
upvote_num: 5
comment_num: 0
---

这个事情其实蛮扭曲的，中国只是战胜国，但没有对这场战争进行清算。这个事情无论是日本还是中国两边都很别扭

