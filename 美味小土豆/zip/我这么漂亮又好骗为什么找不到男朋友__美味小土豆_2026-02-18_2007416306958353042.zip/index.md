---
title: 我这么漂亮又好骗为什么找不到男朋友?
url: https://www.zhihu.com/question/2003215959041803243/answer/2007416306958353042
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-18 11:29
modified: 2026-02-18 11:29
upvote_num: 31
comment_num: 1
---

你为什么大过年的要骗人。

漂亮好骗的根本不愁男朋友。

算了，祝你新年快乐，不要再骗人啦

