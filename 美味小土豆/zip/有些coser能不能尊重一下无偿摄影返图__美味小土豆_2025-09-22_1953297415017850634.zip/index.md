---
title: 有些coser能不能尊重一下无偿摄影返图?
url: https://www.zhihu.com/question/655148749/answer/1953297415017850634
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-22 03:19
modified: 2025-09-22 03:19
upvote_num: 97
comment_num: 10
---

“从硬要扩列的摄影那里收到三张一言难尽的场照返图，还得强忍吐槽的冲动选一张下载，然后营业性地说着谢谢——像我这么能忍又礼貌的人，老天爷真的应该夸我两句！”

  


——这大概就是部分免费场照摄影在 coser 心中的真实印象。

