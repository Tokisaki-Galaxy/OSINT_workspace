---
title: 为什么大多数的国内女人喜欢白又瘦的男人而很少喜欢力量型的男人？
url: https://www.zhihu.com/question/1902756959075153414/answer/1903045455459357007
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-06 11:16
modified: 2025-05-06 11:16
upvote_num: 2
comment_num: 1
---

不，她们只喜欢高的……越高越好

你高壮，高黑，高白，高瘦都行，只要高

她们只是不喜欢矮和壮的组合罢了

