---
title: 为什么好多人不承认大众审美就是喜欢白皮？
url: https://www.zhihu.com/question/11040909667/answer/1907444083296801695
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-18 14:35
modified: 2025-05-18 14:35
upvote_num: 872
comment_num: 17
---

![](./assets/v2-f4c8fbcc32a91f9f33bfec58936fc107_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1112'></svg>)

我都要

