---
title: 现在女生对男孩子身高的执念有多深？
url: https://www.zhihu.com/question/412160271/answer/1941030858426417669
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 06:56
modified: 2025-08-19 06:56
upvote_num: 4
comment_num: 0
---

一米4的说想找1米8的

一米5的说想找一米8的

一米6的说想找1米85的

一米七的想找1米9的

一米八的说随意，不要丑的，丑的再高都不行。

