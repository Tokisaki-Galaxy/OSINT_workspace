---
title: 为什么高个子男生更喜欢身材小很多的小女孩？
url: https://www.zhihu.com/question/399099986/answer/1945436342730355612
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 10:42
modified: 2025-08-31 10:42
upvote_num: 0
comment_num: 0
---

一辈子那么短

真的不把各种身高的都试一遍？

