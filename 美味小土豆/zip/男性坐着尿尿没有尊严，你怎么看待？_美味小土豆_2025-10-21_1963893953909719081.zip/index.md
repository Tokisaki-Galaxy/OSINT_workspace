---
title: 男性坐着尿尿没有尊严，你怎么看待？
url: https://www.zhihu.com/question/1962967435889051543/answer/1963893953909719081
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 09:06
modified: 2025-10-21 09:06
upvote_num: 133
comment_num: 1
---

我觉得一个人不能随心所欲的使用一个马桶就已经够没尊严的了。

