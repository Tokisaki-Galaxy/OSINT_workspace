---
title: 为什么周立波当年那么多嘲讽外地人的脱口秀段子可以进行演出？
url: https://www.zhihu.com/question/661442241/answer/1948938196286171062
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 02:37
modified: 2025-09-10 02:38
upvote_num: 3
comment_num: 0
---

读书的时候家里带我去看他演出我是挺震惊的

"册那?这都可以讲?！噶老卵啊？"

