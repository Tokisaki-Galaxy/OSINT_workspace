---
title: 有哪些与性无关，但是可以令人有高潮感觉的事？
url: https://www.zhihu.com/question/35868138/answer/1952706002911732544
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-20 12:09
modified: 2025-09-20 12:09
upvote_num: 6
comment_num: 1
---

用很细的挖耳勺掏耳朵。

有些人耳朵深处会有一个很痒的点

当挖耳勺搔到这个地方的时候可以让对方爽的轻声叫出来

