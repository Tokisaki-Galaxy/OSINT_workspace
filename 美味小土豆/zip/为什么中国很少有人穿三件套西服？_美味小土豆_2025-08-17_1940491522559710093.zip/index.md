---
title: 为什么中国很少有人穿三件套西服？
url: https://www.zhihu.com/question/26913812/answer/1940491522559710093
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 19:13
modified: 2025-08-17 19:13
upvote_num: 7
comment_num: 0
---

我以前只有每周开着我老板的车拿着巨大的遮阳伞去接她女儿放学的时候才会穿三件套。

车，伞，接人，白手套

没有这四件事情，穿三件套就是一件十分搞笑的事情。

