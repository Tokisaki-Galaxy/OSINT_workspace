---
title: 第一次进猫咖，怎么做才能显得很老练？
url: https://www.zhihu.com/question/308122494/answer/3598545633
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-18 20:28
modified: 2024-08-18 20:28
upvote_num: 10
comment_num: 0
---

“哥，别撸了，喝口奶茶吧，头都要被撸秃了”

