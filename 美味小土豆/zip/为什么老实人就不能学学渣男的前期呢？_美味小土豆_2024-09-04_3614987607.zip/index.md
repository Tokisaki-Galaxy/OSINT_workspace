---
title: 为什么老实人就不能学学渣男的前期呢？
url: https://www.zhihu.com/question/486759965/answer/3614987607
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-04 01:11
modified: 2025-08-18 13:40
upvote_num: 20
comment_num: 5
---

渣男起手是"不管她死活，不行就换"

你打算和对方好好过日子的你不管她死活？那后面怎么办。

