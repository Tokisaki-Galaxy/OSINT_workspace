---
title: 如果你是一位除妖师，当你发现所要讨伐的妖怪是美少女的时候，你会做些什么?
url: https://www.zhihu.com/question/1889641183069832185/answer/1892706165516908344
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-07 22:31
modified: 2025-04-07 22:34
upvote_num: 13
comment_num: 0
---

趁她吃更多的人之前一刀干掉她！

![](./assets/v2-3781f807a7f83990b0b9c98239b094f8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1280' height='720'></svg>)

