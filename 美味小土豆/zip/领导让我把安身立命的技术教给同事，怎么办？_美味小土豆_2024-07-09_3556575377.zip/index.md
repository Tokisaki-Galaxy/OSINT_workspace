---
title: 领导让我把安身立命的技术教给同事，怎么办？
url: https://www.zhihu.com/question/658654234/answer/3556575377
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-09 17:40
modified: 2024-07-09 17:40
upvote_num: 82
comment_num: 0
---

我老板倒是巴不得把他会的东西都教给我们，奈何这逼教会的东西是有点难。我拿这点工资还愿意做下去其中一个原因也确实是我想多学点东西

