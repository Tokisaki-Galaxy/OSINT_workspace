---
title: 加藤惠（圣人惠）真的“普通”、“现实”吗？
url: https://www.zhihu.com/question/33313815/answer/3577758839
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-30 03:59
modified: 2024-07-30 03:59
upvote_num: 1
comment_num: 0
---

这样说吧，我女朋友是个性格像英莉莉+学姐的组合体

她只有在“奖励”我的时候才会切换到“圣人惠”模式，而且最多只能24小时

