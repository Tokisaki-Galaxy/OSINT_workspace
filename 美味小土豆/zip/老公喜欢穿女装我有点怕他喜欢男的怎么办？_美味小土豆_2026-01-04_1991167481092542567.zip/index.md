---
title: 老公喜欢穿女装我有点怕他喜欢男的怎么办？
url: https://www.zhihu.com/question/669092849/answer/1991167481092542567
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-04 15:22
modified: 2026-01-04 15:30
upvote_num: 7
comment_num: 0
---

不要相信任何的自证。

与其自我怀疑，不如去翻翻你老公的手机，看看有没有x账号和qq小号之类的，如果有x账号的话看看他有没有关注什么男同账号，比如这种。

![](./assets/v2-f3e7ad4bebdeadbd2f36f2a852053fbd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1187' height='1170'></svg>)

  


![](./assets/v2-3eee36826a5f71a618f91bb75eeb1f3a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1195'></svg>)

  


![](./assets/v2-c3a70e9d05e566e26e5ccf5837757fe2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='2180'></svg>)

