---
title: 表白失败是不是很丢人?
url: https://www.zhihu.com/question/650685834/answer/1986208004895441366
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-21 22:54
modified: 2025-12-21 22:54
upvote_num: 35
comment_num: 6
---

表白一定会有失败率的。

失败了你就能转头换下一个目标，不用再在这个人身上浪费时间了。

这明明是对自己负责任的做法呀。

