---
title: 为什么大多女人执着于老公上交工资呢？
url: https://www.zhihu.com/question/1933656775355250654/answer/2001653574946538834
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-02 13:50
modified: 2026-02-02 13:50
upvote_num: 47
comment_num: 5
---

要是她不爱你，那可不就惦记着你那点工资当做补偿了嘛。

别说上交工资天经地义，相爱的两个人，这种事情没什么不能商量的

