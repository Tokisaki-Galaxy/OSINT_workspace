---
title: 你最接近生理极限的一次经历是怎样的？
url: https://www.zhihu.com/question/24303401/answer/3558171207
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 08:32
modified: 2024-07-11 08:32
upvote_num: 36
comment_num: 6
---

在朋友的大学城打赢了五条狗。当时这群狗拦着我们去网吧的必经之路。

第二天去打的狂犬疫苗

没打死，打跑了，打得狗子嗷嗷叫

后来狗子们就会摇尾巴了。

