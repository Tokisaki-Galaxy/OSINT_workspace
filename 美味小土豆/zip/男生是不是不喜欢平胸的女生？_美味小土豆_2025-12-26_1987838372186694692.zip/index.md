---
title: 男生是不是不喜欢平胸的女生？
url: https://www.zhihu.com/question/310886317/answer/1987838372186694692
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-26 10:53
modified: 2025-12-26 10:53
upvote_num: 9
comment_num: 0
---

一个拥有160cm的身高，37kg的体重，纤细长腿平坦小腹的美少女

如果能再加一对上a罩杯微微隆起的乳量，那就堪称完美了！

我这辈子遇到的真.贫乳就只有我初中时交往过的雌小鬼学妹了。之后就再也没遇到过那么可爱的对a身材。

当年我前搭子见面前骗我说她只有a所以不要嫌弃她，结果见面脱了衣服才发现她至少是b+！

哎……

![](./assets/v2-1f0ba327a2990de3aa96711e5dac6fba_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='832' height='1216'></svg>)

