---
title: 为什么我抵抗不了自己的生理欲望？
url: https://www.zhihu.com/question/1943506465273934618/answer/1955384474343802392
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 21:33
modified: 2025-09-27 21:33
upvote_num: 14
comment_num: 3
---

抵抗不了就顺从。

一样能解决问题的。

![](./assets/v2-c7a03af8698d802f1cc673a7c28d6c6b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1919'></svg>)

