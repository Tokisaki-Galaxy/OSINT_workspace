---
title: “花生米和豆干同嚼有火腿的味道”，有哪些简单的食材奇怪的组合后能产生高级的味道？
url: https://www.zhihu.com/question/1911509670113318391/answer/1990100302473478365
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-01 16:41
modified: 2026-01-01 16:41
upvote_num: 7
comment_num: 2
---

榴莲和洋葱同嚼，有垃圾房的味道

西瓜和椰子水一起喝，有湿垃圾桶的味道

