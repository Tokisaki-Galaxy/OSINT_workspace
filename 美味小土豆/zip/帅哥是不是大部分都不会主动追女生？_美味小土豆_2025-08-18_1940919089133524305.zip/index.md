---
title: 帅哥是不是大部分都不会主动追女生？
url: https://www.zhihu.com/question/373729530/answer/1940919089133524305
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 23:32
modified: 2025-08-18 23:32
upvote_num: 33
comment_num: 0
---

当你注意到一个女生，还在准备酝酿要怎么和她说话的时候

她和你搭话了

她开始找你聊天了

她自然而然的问你过两天有没有空出来玩了

你发现你压根没机会追她

