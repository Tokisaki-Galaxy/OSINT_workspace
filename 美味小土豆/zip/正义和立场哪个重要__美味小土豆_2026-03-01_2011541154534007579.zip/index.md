---
title: 正义和立场哪个重要?
url: https://www.zhihu.com/question/1935287463351410928/answer/2011541154534007579
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-01 20:39
modified: 2026-03-01 20:39
upvote_num: 3
comment_num: 0
---

正义和立场都不重要

对我有没有利最重要。

当然，明面上的话，我会看和我聊天的人觉得什么重要，然后尽量别和他/她争论。

