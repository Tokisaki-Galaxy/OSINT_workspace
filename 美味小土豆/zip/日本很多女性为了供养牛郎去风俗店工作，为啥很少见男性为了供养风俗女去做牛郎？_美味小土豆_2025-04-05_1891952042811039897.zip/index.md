---
title: 日本很多女性为了供养牛郎去风俗店工作，为啥很少见男性为了供养风俗女去做牛郎？
url: https://www.zhihu.com/question/636848813/answer/1891952042811039897
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-04-05 20:35
modified: 2025-04-05 20:35
upvote_num: 3
comment_num: 0
---

去风俗店的油腻大叔可做不了牛郎，他们的归宿是被高利贷榨干

