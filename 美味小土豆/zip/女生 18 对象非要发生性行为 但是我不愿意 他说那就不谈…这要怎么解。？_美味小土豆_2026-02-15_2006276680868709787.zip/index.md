---
title: 女生 18 对象非要发生性行为 但是我不愿意 他说那就不谈…这要怎么解。？
url: https://www.zhihu.com/question/2004873686201672459/answer/2006276680868709787
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-15 08:00
modified: 2026-02-15 08:00
upvote_num: 5
comment_num: 0
---

那就不谈呗。

互相再去找一个更合适的，大家都不要浪费对方的时间，不是挺好的嘛

