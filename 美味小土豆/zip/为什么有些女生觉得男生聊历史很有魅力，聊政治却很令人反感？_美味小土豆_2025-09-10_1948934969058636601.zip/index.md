---
title: 为什么有些女生觉得男生聊历史很有魅力，聊政治却很令人反感？
url: https://www.zhihu.com/question/48348438/answer/1948934969058636601
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 02:25
modified: 2025-09-10 02:25
upvote_num: 47
comment_num: 0
---

就拿高达举例好了。

一个看过gqxuuuuuc，想要了解高达uc历史的女生问你uc高达的剧情脉络

一

你能精炼的和她讲清楚一年战争，迪拉兹叛乱，格里普斯战役，第二次新吉恩战争，阿克西斯奇迹的时间顺序。

顺带把其中的人物理清，告诉她gqxuuuuuc里的人物在原作里是什么时候登场的，对uc历史有着什么样的影响

她会听得津津有味，觉得"哇你好厉害啊"。

![](./assets/v2-46a612b6e88efad62b747b649c7a78c3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

二

你上来就和她讲"我和你说，吉恩映射的就是纳粹，别相信什么吉恩独立战争是被联邦压迫的，吉恩打得就是侵略战，你知道它们在一周战争的时候杀了多少人吗？你不知道！来来来我来告诉你吉恩是怎么来的，你看的这煞笔动画里女二还是side2难民呢，知道side2难民司是怎么一回事吗？你不知道，来来来我告诉我当年穆佐共和国是什么政体，吉恩的立场是什么……我和你说，就应该杀光吉恩狗……"

我估计不出十分钟，对面就一脸嫌弃的不想听你说话了

![](./assets/v2-a3e7af3af8049b8df1c77edba5f86480_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='679' height='736'></svg>)

