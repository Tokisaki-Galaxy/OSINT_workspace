---
title: 如果我能帮你戒掉瘾，你愿意付出多大的代价？
url: https://www.zhihu.com/question/645733239/answer/3558989145
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 21:46
modified: 2024-07-11 21:46
upvote_num: 3
comment_num: 0
---

题主你是不是有一把会卡壳的手枪和一塑料袋子弹？

