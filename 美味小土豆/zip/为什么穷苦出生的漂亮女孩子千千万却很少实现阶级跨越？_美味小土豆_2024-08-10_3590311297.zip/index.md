---
title: 为什么穷苦出生的漂亮女孩子千千万却很少实现阶级跨越？
url: https://www.zhihu.com/question/457964217/answer/3590311297
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-10 20:18
modified: 2024-08-10 20:18
upvote_num: 2
comment_num: 0
---

漂亮女孩太多了，美丽并不是特别稀有的资源。有些人不仅美丽还聪明，家里条件还好，目标还明确

怎么争

