---
title: 大家都说白瘦幼不好看，那白瘦幼怎么就是主流审美了呢？
url: https://www.zhihu.com/question/1942658220440150430/answer/1947428206157202163
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 22:37
modified: 2025-09-05 22:37
upvote_num: 652
comment_num: 54
---

白瘦幼的骨架是个好素体啊

笔直的小鸟腿，

单手就可以握住的小白腰，

平坦的小腹，

小巧的胸腔和纤薄的后背，

洋娃娃一样细巧的手腕和精致的脚掌。

——在这个基础上，随便怎么长肉，都不容易歪。

![](./assets/v2-3ed04b5d8c3c8aaed4e4e524a7e8c51f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1033' height='1200'></svg>)

