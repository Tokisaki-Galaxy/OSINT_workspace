---
title: 抛开工资不谈，各位上班是为了什么？
url: https://www.zhihu.com/question/1978860142532518727/answer/2006691448196715461
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-16 11:28
modified: 2026-02-16 11:28
upvote_num: 4
comment_num: 1
---

老板是29岁的短发巨乳长腿甜美系御姐。

![](./assets/v2-1beea0b10eb396f79eb2de2d4575f413_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1344' height='1720'></svg>)

