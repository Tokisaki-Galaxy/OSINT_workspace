---
title: 是不是有些女的用钱也是搞不定的？
url: https://www.zhihu.com/question/646381715/answer/3607752915
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-27 16:52
modified: 2024-08-27 16:52
upvote_num: 8
comment_num: 0
---

看你出得起多少价格了。

很多时候是因为你觉得再开价下去就不值得了而已。

以前和一个当职业coser的朋友聊天，她当时当板娘一天是1500，出委托cos是一小时300。

我问她雇你挖一个一米的坑要多少钱？

她愣了一会看着我说你在说什么煞笔话？

我说单纯好奇，2000够不够？

她说想都不要想

“那5000？”

“你认真的？”

“穿高雄的c服！”

“你有病啊，那身衣服根本干不了活的好吗？”

“那如果一定要高雄的c服呢”

“嗯……一天5k的话行！衣服假毛美瞳你出，要拍视频吗？”

“不……嘿嘿我只是随口一问”

然后就被她踹了一脚

![](./assets/v2-7fac572c64393b68e2ea45d869da3c56_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

