---
title: 长得高和长得帅，哪个重要？
url: https://www.zhihu.com/question/445455686/answer/1957548590974084972
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 20:52
modified: 2025-10-03 20:52
upvote_num: 20
comment_num: 6
---

你长得帅但是矮，那么你在你的身高区间里总归是赢家

你长得高但是丑，别人只会记住你的丑。

但是

如果你身高超过178而且颜值6分以上

那么每长高10厘米你的颜值就能加0.5分。

