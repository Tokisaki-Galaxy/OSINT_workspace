---
title: 为什么蕾姆 cos 都像蕾姆，炮姐 cos 不像炮姐？
url: https://www.zhihu.com/question/486225501/answer/3565056661
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-17 19:53
modified: 2024-07-17 19:53
upvote_num: 8197
comment_num: 18
---

“所以你猜为什么大部分coser都出过蕾姆”

