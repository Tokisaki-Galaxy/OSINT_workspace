---
title: 大叔恋为什么会受到很多女性的青睐呢？
url: https://www.zhihu.com/question/662601060/answer/3614639779
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 17:13
modified: 2024-09-03 17:13
upvote_num: 4
comment_num: 0
---

这种性格长相的大叔，不要说小女生了，我男的我也吃啊

![](./assets/v2-8ebef6a06ebdeb417d2e6b7a0dfbee0e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='403'></svg>)

  


![](./assets/v2-f2cc5150a146ae864dba8501e851f277_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='862'></svg>)

  


![](./assets/v2-424cefce731329a399aa55587a5ff164_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='964' height='602'></svg>)

