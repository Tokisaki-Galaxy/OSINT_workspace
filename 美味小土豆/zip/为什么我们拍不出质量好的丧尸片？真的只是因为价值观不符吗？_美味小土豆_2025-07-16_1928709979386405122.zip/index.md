---
title: 为什么我们拍不出质量好的丧尸片？真的只是因为价值观不符吗？
url: https://www.zhihu.com/question/1927603826992608269/answer/1928709979386405122
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-16 06:58
modified: 2025-07-16 06:58
upvote_num: 0
comment_num: 0
---

大政府不配拥有丧尸片。

