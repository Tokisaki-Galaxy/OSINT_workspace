---
title: 为什么新中国不处决爱新觉罗·溥仪？
url: https://www.zhihu.com/question/655238621/answer/1962224160223769605
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-16 18:31
modified: 2025-10-16 18:31
upvote_num: 5
comment_num: 0
---

那溥仪可就真长这样了

![](./assets/v2-8954b22aa29b9422649715257dc052fc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2400' height='1572'></svg>)

再配上末代皇帝这片子。

我都能想象得出来会有人多舔这玩意

