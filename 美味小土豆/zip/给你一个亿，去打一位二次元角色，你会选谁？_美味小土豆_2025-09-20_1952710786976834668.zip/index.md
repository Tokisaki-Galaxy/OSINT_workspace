---
title: 给你一个亿，去打一位二次元角色，你会选谁？
url: https://www.zhihu.com/question/11657356835/answer/1952710786976834668
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-20 12:28
modified: 2025-09-20 12:28
upvote_num: 591
comment_num: 27
---

![](./assets/v2-73df4f64ff85785c339f5b2112868112_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='780'></svg>)

所以我出一个亿就能和花凛打架？！

