---
title: 人类真的想象不出从来没见过的东西吗？
url: https://www.zhihu.com/question/266668858/answer/1941230166081802592
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-19 20:08
modified: 2025-08-19 20:08
upvote_num: 2
comment_num: 1
---

就像很多人觉得身高1米65体重38kg的女生一定是骷髅。

其实这种女生还挺软的。肚子虽然是平的但还是很柔软饱满的。

而且还有胸！

