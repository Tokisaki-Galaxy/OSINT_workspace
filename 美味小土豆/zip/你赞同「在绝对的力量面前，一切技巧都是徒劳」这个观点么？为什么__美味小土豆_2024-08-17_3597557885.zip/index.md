---
title: 你赞同「在绝对的力量面前，一切技巧都是徒劳」这个观点么？为什么?
url: https://www.zhihu.com/question/268189551/answer/3597557885
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-17 17:48
modified: 2024-08-17 17:48
upvote_num: 0
comment_num: 0
---

你要是拥有“绝对力量”，那火星流古武术在你面前都没用啊。

