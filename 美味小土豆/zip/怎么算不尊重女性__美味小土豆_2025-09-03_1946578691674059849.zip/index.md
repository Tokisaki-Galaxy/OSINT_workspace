---
title: 怎么算不尊重女性?
url: https://www.zhihu.com/question/746120311/answer/1946578691674059849
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 14:22
modified: 2025-09-03 14:22
upvote_num: 6
comment_num: 0
---

极端派答案：只要搭理她们，她们就有借口说你不尊重她们。

所以不要搭理她们，这时候她们骂你不尊重她们至少你听不见。

我的答案：既然女生可以在任何情况下说你不尊重她，那我就放弃思考这个问题，只凭本能好恶和女生交流了。

