---
title: 自己突然觉得女朋友矮怎么办？
url: https://www.zhihu.com/question/2015606016641868663/answer/2020578841865757241
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-26 19:12
modified: 2026-03-26 19:12
upvote_num: 10
comment_num: 0
---

萝莉控突然意识到自己女朋友只是矮但是并不萝莉了？

真的很像是萝莉控找了个矮个姑娘当代餐，但是现在这个代餐不合胃口了的感觉。

