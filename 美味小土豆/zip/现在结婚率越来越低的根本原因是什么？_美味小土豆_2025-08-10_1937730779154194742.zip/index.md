---
title: 现在结婚率越来越低的根本原因是什么？
url: https://www.zhihu.com/question/1929961364673233370/answer/1937730779154194742
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 04:23
modified: 2025-08-10 04:23
upvote_num: 12
comment_num: 0
---

有没有一个可能

很多人本来就不想结婚

以前是被逼的不得不结婚

现在搞性别对立，就能光明正大的不结婚了。

婚姻本身没那么吸引人的

