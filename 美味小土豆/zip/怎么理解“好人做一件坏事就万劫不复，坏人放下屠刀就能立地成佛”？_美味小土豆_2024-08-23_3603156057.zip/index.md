---
title: 怎么理解“好人做一件坏事就万劫不复，坏人放下屠刀就能立地成佛”？
url: https://www.zhihu.com/question/664870678/answer/3603156057
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-23 03:34
modified: 2024-08-23 03:34
upvote_num: 4
comment_num: 0
---

这两句话无论怎么解释漏洞都很大而且很别扭，所以我不相信这句话。

