---
title: 刚发现谈了几天的女朋友和很多人睡过怎么办?
url: https://www.zhihu.com/question/641258565/answer/1965364573252060519
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-25 10:30
modified: 2025-10-25 10:30
upvote_num: 14
comment_num: 1
---

既然都遇上了你还不抓紧时间刷一下经验值？

你跟她学习一下做爱技巧，得到一些技能评价你也不吃亏啊。

还在纠结啥啊。

