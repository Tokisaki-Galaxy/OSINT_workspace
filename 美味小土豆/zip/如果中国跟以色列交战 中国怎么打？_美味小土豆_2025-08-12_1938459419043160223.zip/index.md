---
title: 如果中国跟以色列交战 中国怎么打？
url: https://www.zhihu.com/question/1917656625176614289/answer/1938459419043160223
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 04:39
modified: 2025-08-12 04:47
upvote_num: 0
comment_num: 2
---

为什么要打以色列啊!他们可是全世界最伟大的民族哎，题主你疯了吗？让我们去挑战这样一个神圣的民族？！

我和你说，就算我们把以色列整个都围起来，全围起来！断水断粮，彻底的断水断粮!

只要犹太人手里还书，他们就一定能有办法赢得这场战争的!他们可是全世界最"智慧"的民族！他们的书上可是有蜂蜜的!

你不信?不信你试试嘛，呐，试试

![](./assets/v2-c6c49731cbef8265dbe1d2df8448ce6a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

