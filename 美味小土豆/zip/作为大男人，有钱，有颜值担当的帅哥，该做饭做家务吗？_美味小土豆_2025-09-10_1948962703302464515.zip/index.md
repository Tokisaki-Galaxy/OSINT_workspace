---
title: 作为大男人，有钱，有颜值担当的帅哥，该做饭做家务吗？
url: https://www.zhihu.com/question/1939341938701599773/answer/1948962703302464515
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 04:15
modified: 2025-09-10 04:15
upvote_num: 6
comment_num: 1
---

我巨喜欢做饭

我最强的战绩是搞坏了半个班女生的肚子

当年我被剔除我们班最适合结婚对象的队列就是因为我痴迷于做饭，谁劝都不好使。

