---
title: 为什么警察不抓有偿伴游呢？
url: https://www.zhihu.com/question/5902959200/answer/1958848762991601525
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-07 10:58
modified: 2025-10-07 10:58
upvote_num: 87
comment_num: 6
---

实际上和伴游无限接近的一件事情就是网友面基然后上床。

伴游能抓，那异地奔现和网友见面就都是违法的。

