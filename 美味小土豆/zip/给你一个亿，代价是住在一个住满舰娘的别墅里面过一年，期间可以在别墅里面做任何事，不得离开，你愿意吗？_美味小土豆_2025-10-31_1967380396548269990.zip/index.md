---
title: 给你一个亿，代价是住在一个住满舰娘的别墅里面过一年，期间可以在别墅里面做任何事，不得离开，你愿意吗？
url: https://www.zhihu.com/question/1965927504788329618/answer/1967380396548269990
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-31 00:00
modified: 2025-10-31 00:00
upvote_num: 12
comment_num: 6
---

那么请帮我带十打岛风的制服

和尽可能多的避孕药

![](./assets/v2-7611fd100eb6c10d3e30fad8852e3acb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-b5ab3c87eef701600c0f949879afee2c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-17fb844b013278f06d1fce0df1eeeee2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-b8c5715392151d9da11f4a098fabfa4e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-e370422f91702a9e7767d75513d89d1d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-30b2aa336dac205c023260bae2adc106_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-be44c26ab37fa82921d4e31889858a09_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-0a2628a6a6d7c941220220713d6688d2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

  


![](./assets/v2-2d59a678cf26381b0790c64816fc688a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

