---
title: 为什么绘圈对AI绘画痛恶欲绝，但其他圈子对AI创作的态度就比较温和？
url: https://www.zhihu.com/question/1941132414425495417/answer/1945845468149032521
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-01 13:48
modified: 2025-09-01 13:48
upvote_num: 6
comment_num: 0
---

很多商场里剧本杀鬼屋的宣传海报都已经是用ai图了。

很多料理店的宣传海报也是一眼ai，甚至前两天有看到工艺广告都用ai图的了。

应该是真的挺方便的吧。绘圈应该也不会劳师动众的去挂这些地方。

e绅士和推上的ai涩图也越来越好撸了

