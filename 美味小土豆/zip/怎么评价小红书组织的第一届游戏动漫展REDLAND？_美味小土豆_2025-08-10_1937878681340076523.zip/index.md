---
title: 怎么评价小红书组织的第一届游戏动漫展REDLAND？
url: https://www.zhihu.com/question/1928808793946460985/answer/1937878681340076523
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:11
modified: 2025-08-10 14:11
upvote_num: 0
comment_num: 0
---

看直播我觉得很有趣，明年能抢到票我一定要去!

