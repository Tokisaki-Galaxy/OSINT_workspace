---
title: 请问一下，体育生跑1000米用了2分18，他是不是在骗人？
url: https://www.zhihu.com/question/555468215/answer/1942732448984172272
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-23 23:38
modified: 2025-08-23 23:38
upvote_num: 2
comment_num: 7
---

3分35秒就能进田径队了

我是区110栏第三名，我1000米成绩最好也就3分19秒……

中国1000米最好记录好像也就2分25秒

