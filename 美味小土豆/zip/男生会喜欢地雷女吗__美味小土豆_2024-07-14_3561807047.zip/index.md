---
title: 男生会喜欢地雷女吗?
url: https://www.zhihu.com/question/530559029/answer/3561807047
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 20:03
modified: 2024-07-14 20:03
upvote_num: 20
comment_num: 5
---

我朋友曾经很喜欢地雷妹，直到有一次被一个行李箱女孩子榨了两个晚上落荒而逃以后就对这个群体敬而远之了。

他说那个妹子喜欢让他掐她脖子，掐到后面我朋友都怂了，他说对方翻白眼了都不让他停……

