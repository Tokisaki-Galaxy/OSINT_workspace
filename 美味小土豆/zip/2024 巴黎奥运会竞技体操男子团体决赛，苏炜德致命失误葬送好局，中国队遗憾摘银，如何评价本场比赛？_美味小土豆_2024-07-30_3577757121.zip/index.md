---
title: 2024 巴黎奥运会竞技体操男子团体决赛，苏炜德致命失误葬送好局，中国队遗憾摘银，如何评价本场比赛？
url: https://www.zhihu.com/question/662928493/answer/3577757121
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-30 03:48
modified: 2024-07-30 03:48
upvote_num: 0
comment_num: 0
---

唉，不气不气，不过掉两次真的看得我傻掉了，挺心塞的。尤其是最后只差0.4，更心塞了。

