---
title: 如何评价知乎用户@小蛋糕绒布球？
url: https://www.zhihu.com/question/1952022768989214670/answer/1955316491265251119
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 17:02
modified: 2025-09-27 17:02
upvote_num: 8
comment_num: 0
---

我不知道他是谁，他回过我15个赞，我只回过他一个赞

我觉得他头像很可爱

出于礼貌我关注了他

就酱

