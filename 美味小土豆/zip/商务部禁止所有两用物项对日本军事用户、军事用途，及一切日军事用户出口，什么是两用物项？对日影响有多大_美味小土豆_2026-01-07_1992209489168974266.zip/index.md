---
title: 商务部禁止所有两用物项对日本军事用户、军事用途，及一切日军事用户出口，什么是两用物项？对日影响有多大？
url: https://www.zhihu.com/question/1991903145379524941/answer/1992209489168974266
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-01-07 12:22
modified: 2026-01-07 12:23
upvote_num: 12
comment_num: 2
---

明年去东京看看泡姬店的太太们颜值是否有明显提升，就知道有没有影响了。

别老成天想打仗的，多关心关心老二呀。

