---
title: 帅哥会知道自己长的帅吗？
url: https://www.zhihu.com/question/399799308/answer/1940526928269406268
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 21:34
modified: 2025-08-17 21:34
upvote_num: 2
comment_num: 1
---

你们真的不是在拿仇人的照片搞抽象吗？

![](./assets/v2-10b92ccad42ee8e91da346295dbf74cf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1024' height='1024'></svg>)

