---
title: 法国大革命为什么失控了，对贵族进行屠杀?
url: https://www.zhihu.com/question/639921995/answer/1938466700937926385
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 05:07
modified: 2025-08-12 05:07
upvote_num: 0
comment_num: 0
---

法国人不行啊，比黄巢晚了900年才开悟

