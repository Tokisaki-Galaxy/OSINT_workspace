---
title: 我觉得女生168/172刚刚好，为什么那么多人讨厌170+的女生呢？
url: https://www.zhihu.com/question/1907194485173101310/answer/1952133788508336576
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-18 22:16
modified: 2025-09-18 22:16
upvote_num: 10
comment_num: 0
---

因为在有的人眼里，168和172的女性是没有区别的

而在另一些人眼里，172的女性就属于"有压迫感"了。

