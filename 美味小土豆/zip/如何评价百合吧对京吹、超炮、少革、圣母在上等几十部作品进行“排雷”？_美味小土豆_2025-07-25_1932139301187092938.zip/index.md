---
title: 如何评价百合吧对京吹、超炮、少革、圣母在上等几十部作品进行“排雷”？
url: https://www.zhihu.com/question/1931047367290889169/answer/1932139301187092938
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-25 18:05
modified: 2025-07-25 18:05
upvote_num: 2
comment_num: 3
---

圣母在上非百合？!

国内第一个百合向论坛就叫山百合会哎!喂！

当年舞hime这种有明确bg的都是当做百合作品来讨论的哎!

有病的，哪天把神无月也开除百合籍算了!

