---
title: 为什么现在很多男生都被说成普信男？
url: https://www.zhihu.com/question/490291692/answer/1965178514094424954
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-24 22:11
modified: 2025-10-24 22:11
upvote_num: 163
comment_num: 8
---

那你就要想办法快点把自信升级成——自私，随心所欲，不顾及别人感受，从来不为别人着想，从来不肯认识到自己的错误。

然后你任何的小甜头就会让快被你折磨疯了的女生反过来沾沾自喜了。

md我在教什么东西啊……

