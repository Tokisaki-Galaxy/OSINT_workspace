---
title: 如何评价《工作细胞BLACK》中文翻译漫画的反男凝删减内容考虑？
url: https://www.zhihu.com/question/658380084/answer/3614676919
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 17:50
modified: 2024-09-03 17:50
upvote_num: 4
comment_num: 0
---

在日式男性向二次元作品里搞反男凝……太搞笑了。

