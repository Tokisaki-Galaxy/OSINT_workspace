---
title: 为什么有的拳馆几乎不实战？
url: https://www.zhihu.com/question/326041939/answer/1943276444974289284
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 11:40
modified: 2025-08-25 11:40
upvote_num: 9
comment_num: 1
---

我泼水都不和朋友较真

男人较真真容易打出真火来

我夏天经常看到小朋友们从友好的水枪追逐变成生死格斗

丢枪那一下还挺帅的

