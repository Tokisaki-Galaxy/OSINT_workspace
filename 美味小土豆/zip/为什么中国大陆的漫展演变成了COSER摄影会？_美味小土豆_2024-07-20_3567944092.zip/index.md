---
title: 为什么中国大陆的漫展演变成了COSER摄影会？
url: https://www.zhihu.com/question/661537655/answer/3567944092
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-20 15:58
modified: 2025-08-13 14:26
upvote_num: 5
comment_num: 1
---

这样难道不好吗?

活生生的零式哎!

![](./assets/v2-010367ee80c6e212d28d68413edb0ea1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1128' height='1504'></svg>)

