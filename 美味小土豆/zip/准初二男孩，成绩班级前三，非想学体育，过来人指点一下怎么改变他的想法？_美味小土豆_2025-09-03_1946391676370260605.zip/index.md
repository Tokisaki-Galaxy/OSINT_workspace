---
title: 准初二男孩，成绩班级前三，非想学体育，过来人指点一下怎么改变他的想法？
url: https://www.zhihu.com/question/1939965248351221192/answer/1946391676370260605
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 01:58
modified: 2025-09-03 01:58
upvote_num: 3
comment_num: 1
---

他的体育成绩是多少？

没有到区第一的话不会有任何出息的。

哪怕到了市第一，将来可能也就当个高中体育老师。

真的想清楚，体育比赛真的卷到让人绝望

