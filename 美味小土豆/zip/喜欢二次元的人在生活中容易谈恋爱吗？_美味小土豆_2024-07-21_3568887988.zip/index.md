---
title: 喜欢二次元的人在生活中容易谈恋爱吗？
url: https://www.zhihu.com/question/582319239/answer/3568887988
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 17:07
modified: 2024-07-21 17:07
upvote_num: 1
comment_num: 0
---

比较难

以前玩主机怪物猎人的时候我鸽掉了好多好多人出去玩的邀请

