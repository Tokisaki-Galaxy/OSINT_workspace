---
title: 为什么中国男人普遍喜欢娇小可爱的女性，而欧美男人却喜欢高大丰满强壮的女性？
url: https://www.zhihu.com/question/664101160/answer/3594429044
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-14 18:13
modified: 2024-08-14 18:13
upvote_num: 0
comment_num: 0
---

我不挑，只要好看的我都喜欢！

