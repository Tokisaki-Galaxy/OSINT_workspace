---
title: 以男生的眼光来看，女生有哪些加分项？
url: https://www.zhihu.com/question/35391681/answer/1933152687043610611
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-28 13:11
modified: 2025-07-28 13:12
upvote_num: 0
comment_num: 0
---

聪明，可靠

会操作浮游炮

像妈妈一样

![](./assets/v2-57a7d4ae263b8ba3589f8a92310e0c2e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='1080'></svg>)

