---
title: 歼-15T、歼-35 和空警-600 在福建舰上首次弹射起飞和着舰训练，释放了怎样的信号？
url: https://www.zhihu.com/question/1953516306285467147/answer/1953848457572881886
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-23 15:49
modified: 2025-09-23 15:49
upvote_num: 6
comment_num: 1
---

[http://【DANGER%20ZONE—南海福建舰特供版-哔哩哔哩】%20https://b23.tv/Qc9AI8q](https://link.zhihu.com/?target=http%3A//%25E3%2580%2590DANGER%2520ZONE%25E2%2580%2594%25E5%258D%2597%25E6%25B5%25B7%25E7%25A6%258F%25E5%25BB%25BA%25E8%2588%25B0%25E7%2589%25B9%25E4%25BE%259B%25E7%2589%2588-%25E5%2593%2594%25E5%2593%25A9%25E5%2593%2594%25E5%2593%25A9%25E3%2580%2591%2520https%3A//b23.tv/Qc9AI8q)

说明国产topgun真的可以开始安排起了。

请让歼8-2负责当假想敌中队！

![](./assets/v2-d580336ebc0f5f70306f1e1773afecbd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-7ae2b60b5c3fff037a1d05e82b3cf824_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

