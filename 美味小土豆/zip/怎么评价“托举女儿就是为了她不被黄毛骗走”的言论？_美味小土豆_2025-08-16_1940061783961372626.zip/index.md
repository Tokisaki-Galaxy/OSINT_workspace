---
title: 怎么评价“托举女儿就是为了她不被黄毛骗走”的言论？
url: https://www.zhihu.com/question/1917973233271051225/answer/1940061783961372626
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 14:46
modified: 2025-08-16 14:46
upvote_num: 0
comment_num: 0
---

笑死了，说黄毛眼光巨高的和说黄毛完全不挑食的先去打一架。

