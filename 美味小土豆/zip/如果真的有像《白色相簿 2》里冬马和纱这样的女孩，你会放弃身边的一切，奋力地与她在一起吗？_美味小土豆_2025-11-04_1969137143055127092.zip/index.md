---
title: 如果真的有像《白色相簿 2》里冬马和纱这样的女孩，你会放弃身边的一切，奋力地与她在一起吗？
url: https://www.zhihu.com/question/340402333/answer/1969137143055127092
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-04 20:21
modified: 2025-11-04 20:21
upvote_num: 4
comment_num: 2
---

不会，因为我身边已经有第二个像四宫辉夜一样的女孩子了。

