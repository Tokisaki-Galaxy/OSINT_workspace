---
title: 真的有人在开车前会绕车一圈吗？
url: https://www.zhihu.com/question/620919441/answer/3558194086
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-11 08:54
modified: 2024-07-11 08:54
upvote_num: 1
comment_num: 0
---

我们连电动三轮车启动前都要绕一圈看看。之前压坏的有砖头，狗盆，狗玩具，打包器等等各种东西了。

