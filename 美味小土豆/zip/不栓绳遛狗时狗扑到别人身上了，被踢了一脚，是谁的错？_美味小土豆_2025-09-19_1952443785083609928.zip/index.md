---
title: 不栓绳遛狗时狗扑到别人身上了，被踢了一脚，是谁的错？
url: https://www.zhihu.com/question/334805934/answer/1952443785083609928
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-19 18:47
modified: 2025-09-19 18:47
upvote_num: 7
comment_num: 0
---

卧槽，还是小孩

假如，我是说假如，我家狗不小心冲出去扑到门口的小孩。

假使这个小孩没受伤，而我又立刻当着小孩的面把狗暴打一顿后，他家大人能摆摆说"算了算了"

我家狗高低都得给这个小孩哥磕一个。

