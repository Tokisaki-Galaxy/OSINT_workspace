---
title: 支持 AI 绘画的理由是什么？AI 相较于传统绘画有什么独特的地方？
url: https://www.zhihu.com/question/586907557/answer/3559892643
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-12 18:00
modified: 2024-07-12 18:00
upvote_num: 1
comment_num: 0
---

不需要和画师来回掰扯。有多少项目黄了都是因为画师的“坚持”

