---
title: 现在的中国如果穿越到二战能吊打全世界吗？
url: https://www.zhihu.com/question/33686895/answer/1965737596387857338
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 11:12
modified: 2025-10-26 11:12
upvote_num: 5
comment_num: 0
---

你这就好像是问让我穿越到我托儿所的时候能不能吊打我全班一样……

