---
title: 为什么会有地域歧视这么可笑的玩意？本质上不还是阶级矛盾吗？
url: https://www.zhihu.com/question/1951269936556127597/answer/2010713547638855016
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 13:51
modified: 2026-02-27 13:51
upvote_num: 8
comment_num: 3
---

你要讲阶级矛盾，那我可要聊聊——"歧视上海人是全中国的政治正确"这件事情了。

