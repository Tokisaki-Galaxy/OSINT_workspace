---
title: 国内实弹射击场为什么不火？靶场数量也少得可怜？
url: https://www.zhihu.com/question/622863674/answer/3591397612
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-12 01:13
modified: 2024-08-12 01:13
upvote_num: 22
comment_num: 4
---

上海的射击馆，里面的手枪像是被用拘束架固定的战术人形一样，我开枪的时候总在脑补是一个萝莉带着脚镣手铐塞着口球撅着屁股被卡在墙壁上……

真的你们自己去体验一下就知道了，真得是又涩情又搞笑。

![](./assets/v2-655cd158d41e1c43824172c0527e4eb4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1387'></svg>)

