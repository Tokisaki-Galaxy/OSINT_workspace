---
title: 为何和平主义者总会被曲解为软骨头和投降派？
url: https://www.zhihu.com/question/13253335271/answer/1892670262337569554
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-07 20:09
modified: 2025-04-07 20:09
upvote_num: 23
comment_num: 0
---

![](./assets/v2-61ccdd29865f773e09acf71f925a20ad_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='700' height='700'></svg>)

假面骑士里最大的和平主义者是主角真司，这逼是个可以为了救人毫不犹豫牺牲自己的圣父。

他阻止骑士大战的办法就是——打败所有人！

这才是和平主义者好嘛！

