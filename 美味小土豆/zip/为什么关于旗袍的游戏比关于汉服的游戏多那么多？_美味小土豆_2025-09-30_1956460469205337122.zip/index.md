---
title: 为什么关于旗袍的游戏比关于汉服的游戏多那么多？
url: https://www.zhihu.com/question/1953871690590319626/answer/1956460469205337122
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 20:48
modified: 2025-09-30 20:48
upvote_num: 7
comment_num: 3
---

门帘子已经是二次元烧鸡特有的刻板印象服侍了。

跟汉服完全不是一个赛道的了。

![](./assets/v2-061becce91ed781b73d3993ff7b71703_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='938'></svg>)

  


![](./assets/v2-8de1aa3a4bfa8a2ede2d5a56429a251a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='896' height='1152'></svg>)

  


![](./assets/v2-b870f610368f663dc110ba9d06aee31b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='848'></svg>)

  


![](./assets/v2-3aff8e7d3e3e9ccbc74e08ecf810867d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='903'></svg>)

  


![](./assets/v2-3f9bcd4751bf12fcd1882a3e39993e7b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='600'></svg>)

  


![](./assets/v2-86a95394b8be5bf11d3681846c088ec4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='1200'></svg>)

