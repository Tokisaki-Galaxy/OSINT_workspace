---
title: 分明是胸小的女人穿衣更好看，为何还痴迷隆胸？
url: https://www.zhihu.com/question/654218316/answer/3605796185
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-25 21:10
modified: 2024-08-25 21:10
upvote_num: 2
comment_num: 0
---

正常大小范畴里，大的比小的好看

过分巨大的，穿什么都不好看，穿jk制服都一言难尽。

