---
title: 为什么东亚人审美不喜欢很壮肌肉男？
url: https://www.zhihu.com/question/355207841/answer/1951780017764798500
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-17 22:50
modified: 2025-09-17 22:50
upvote_num: 7
comment_num: 1
---

自以为健完身以后看起来是魔鬼终结者

![](./assets/v2-7d9b2c38797acb1556a9435476389618_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='506' height='755'></svg>)

但其实更多的是看起来像眼镜犬

![](./assets/v2-7f469cdcb30109d465609e9886ec5950_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='3422' height='3448'></svg>)

眼镜犬人气真的不高……

