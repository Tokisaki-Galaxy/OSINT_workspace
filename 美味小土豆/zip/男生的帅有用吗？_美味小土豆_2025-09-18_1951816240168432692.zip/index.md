---
title: 男生的帅有用吗？
url: https://www.zhihu.com/question/61319575/answer/1951816240168432692
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-18 01:14
modified: 2025-09-18 01:14
upvote_num: 22
comment_num: 1
---

男人也是看颜的

一样的学历一样的能力，他看你顺眼你就是比别人机会多。

如果你的人生一直一帆风顺，做什么事情都很顺利，无论男女都爱和你做朋友，似乎连老天爷都站着你这边的话。

不妨回去照照镜子，感谢一下爹妈。

