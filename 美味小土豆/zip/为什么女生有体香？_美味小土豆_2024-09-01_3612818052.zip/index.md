---
title: 为什么女生有体香？
url: https://www.zhihu.com/question/20320900/answer/3612818052
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-01 21:00
modified: 2024-09-01 21:00
upvote_num: 9
comment_num: 1
---

排除掉化妆品，性激素，狐臭，洗衣液这些

再仔细闻

其实就是新鲜的健康的肉味。

尤其是从小肚子这一片贴着向上闻过去，会有一股十分新鲜的充满活力的肉味，是一种会让人很愉悦的好闻气味，毕竟人类是食肉的。

当然你也可以说这是肉香，但是我觉得这样形容就太变态了。

![](./assets/v2-614a2dc4b59033a9515a56126debb7a1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='440' height='222'></svg>)

  


![](./assets/v2-8058b0d8fe83366739176e5b6ed1174a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='484' height='304'></svg>)

  


![](./assets/v2-02b3e3b04abfdda61c77b3685914e50e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='448' height='291'></svg>)

