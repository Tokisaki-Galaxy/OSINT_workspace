---
title: 男人为什么活不过女人？
url: https://www.zhihu.com/question/1936003682178164541/answer/1939274268526511425
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 10:36
modified: 2025-08-14 10:36
upvote_num: 33
comment_num: 1
---

我会把伤害身体的行为认为是很酷的事情

比如搬很重很重的东西

修窗户从三楼摔下来。

连续三天不睡觉制作道具

然后我还要不停的pua我的身体"动啊，动起来啊，你不是天下无敌的苏帕萝卜嘛！动起来啊！精神力mk2!!!"

