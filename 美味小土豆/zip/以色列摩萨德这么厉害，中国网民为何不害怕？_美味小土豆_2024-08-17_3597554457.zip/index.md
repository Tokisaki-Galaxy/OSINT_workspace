---
title: 以色列摩萨德这么厉害，中国网民为何不害怕？
url: https://www.zhihu.com/question/632405777/answer/3597554457
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-17 17:43
modified: 2024-08-17 17:43
upvote_num: 3
comment_num: 0
---

我朋友每次约小姐姐我都调侃他“当心对方是摩萨德的间谍啊”

后来他问我为啥你从来不说当心对方是cia或者是m6

我说可能是感觉摩萨德比较搞笑？

