---
title: 为什么现在网络上流行贬低170+的女生来说明小鸟依人和保护欲的重要性?
url: https://www.zhihu.com/question/1928895608841832007/answer/1938471512022717267
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 05:27
modified: 2025-08-12 05:27
upvote_num: 0
comment_num: 0
---

170……不算小鸟依人?啊？

