---
title: 为什么女的可以穿男装，男的不能穿女装？
url: https://www.zhihu.com/question/1927533143742713997/answer/1937915666842759860
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 16:38
modified: 2025-08-10 16:38
upvote_num: 136
comment_num: 4
---

没啥不能穿的，穿去人民广场都没问题

![](./assets/v2-7641da2d82661d7573ff8861276e5d88_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='700' height='500'></svg>)

