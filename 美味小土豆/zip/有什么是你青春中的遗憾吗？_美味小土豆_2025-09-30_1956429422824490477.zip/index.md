---
title: 有什么是你青春中的遗憾吗？
url: https://www.zhihu.com/question/572468222/answer/1956429422824490477
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 18:45
modified: 2025-09-30 18:45
upvote_num: 56
comment_num: 5
---

我上高中的时候为什么没有蔚蓝档案！我高中前女友黑皮大长腿，真的是出花凛绝好的苗子啊！

结果现在每天只有个不穿衣服的黑皮巨乳妃咲在我眼前晃……

