---
title: 如何评价吴艳妮？
url: https://www.zhihu.com/question/624876960/answer/3593511606
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-13 22:34
modified: 2024-08-13 22:34
upvote_num: 2
comment_num: 0
---

算了，就算所有人都骂我还是想说

我真的挺喜欢吴艳妮的

作为运动员长得好看，样子可爱，实力也不差，赛前动作很有特色。

如果当年我们跨栏队有这样实力和颜值的妹子，我绝对跪下来和教练说“教练，我想练跨栏”

而不是去练400米。

