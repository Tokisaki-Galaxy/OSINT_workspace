---
title: 如何看待抖音用户 Jeane小圆崽 三年拳击女爱好者 VS 消防员健身男 的拳击实战视频  ？
url: https://www.zhihu.com/question/1941730574927660390/answer/1942104105616122865
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-22 06:01
modified: 2025-08-22 06:04
upvote_num: 596
comment_num: 23
---

我有两个练格斗的女性朋友

一个跆拳道

一个拳击

和她们正经陪练的描述

我能写六篇超甜的轻小说……

或者两篇蓝底白字的案件通告。

ps：不要和女人玩闹格斗，你真的会变弱的……

