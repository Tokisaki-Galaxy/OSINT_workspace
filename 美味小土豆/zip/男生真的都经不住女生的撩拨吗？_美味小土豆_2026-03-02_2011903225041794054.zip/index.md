---
title: 男生真的都经不住女生的撩拨吗？
url: https://www.zhihu.com/question/280675684/answer/2011903225041794054
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-02 20:38
modified: 2026-03-02 20:38
upvote_num: 15
comment_num: 10
---

我会分辨能不能玩到一块，是不是一个圈子，是不是同类的。

玩不到一块的姑娘我一律是不接撩的。

所以在某种程度上我在女性朋友圈子里口碑很好。

很搞笑的，我在现实里居然能得到一个"哎呀我和你们说，xxx和别的男人都不一样的，他很干净的好伐！你去调戏他他都很乖的"的评价。

![](./assets/v2-9fc5bfaab781ffe812fc9077c5d26580_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

