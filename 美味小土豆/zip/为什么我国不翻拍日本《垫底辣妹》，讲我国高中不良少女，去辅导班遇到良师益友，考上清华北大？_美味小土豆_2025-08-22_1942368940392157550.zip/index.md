---
title: 为什么我国不翻拍日本《垫底辣妹》，讲我国高中不良少女，去辅导班遇到良师益友，考上清华北大？
url: https://www.zhihu.com/question/1939845419896141478/answer/1942368940392157550
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-22 23:34
modified: 2025-08-22 23:34
upvote_num: 10
comment_num: 0
---

因为绝对有一帮做题家跳着叫骂"为什么不拍真实的高中生活"然后在下面评论自己刷题有多狠。

