---
title: 如何看待吴京、郭帆、刘慈欣被说成“犹太光明会成员”？
url: https://www.zhihu.com/question/2007979379414811077/answer/2010704229464053097
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 13:14
modified: 2026-02-27 13:14
upvote_num: 63
comment_num: 2
---

啊？现在已经没有人看星际迷航了吗？

我这种95后都还认得这是瓦肯人的打招呼手势啊。

你在公开场合做这个手势的后果，大约就是你公开承认自己是一个古臭sf爱好者。

还蛮羞耻的

