---
title: 女朋友说“我就这样，你要不喜欢就换一个”，该怎么去沟通？
url: https://www.zhihu.com/question/1910892482411095976/answer/2015735776026064687
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-13 10:27
modified: 2026-03-13 10:27
upvote_num: 4
comment_num: 0
---

你都说了她把你当狗了，说明你也清楚她不喜欢你。

你还去沟通啥？人是不愿意和狗沟通的，人只希望狗听话。

你那么乐意当狗？

