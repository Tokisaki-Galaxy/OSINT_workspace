---
title: 为什么动漫里都是日本高中生，是因为上不了大学吗？
url: https://www.zhihu.com/question/816558188/answer/1905657022986317878
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-13 16:13
modified: 2025-05-13 16:13
upvote_num: 0
comment_num: 0
---

很多番但凡主角是个大学生，作品整体感官就会又油腻又弱智，男主会看起来像个超雄巨婴一样。

