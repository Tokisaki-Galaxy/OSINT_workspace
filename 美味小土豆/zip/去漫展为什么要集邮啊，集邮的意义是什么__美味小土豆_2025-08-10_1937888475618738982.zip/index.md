---
title: 去漫展为什么要集邮啊，集邮的意义是什么?
url: https://www.zhihu.com/question/658438726/answer/1937888475618738982
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:50
modified: 2025-08-10 14:50
upvote_num: 3
comment_num: 0
---

当年在LL已经很冷门的时候我在会场集邮齐了缪斯全员，还是很开心很有成就感的。

去年出士官长的时候我满场找ods集邮，结果被一堆假面骑士拉去拍照。

当然还是挺开心的

