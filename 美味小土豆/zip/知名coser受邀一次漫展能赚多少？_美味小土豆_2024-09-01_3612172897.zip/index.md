---
title: 知名coser受邀一次漫展能赚多少？
url: https://www.zhihu.com/question/643413008/answer/3612172897
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-01 01:37
modified: 2024-09-01 01:37
upvote_num: 10
comment_num: 1
---

我朋友在小透明的时候是当板娘一天150，后来是一天450。

她接到的第一个商业邀请是1500一天+酒店和交通费报销，去给一个乙游当板郎。

出名了以后是一天3000+酒店交通费报销。

