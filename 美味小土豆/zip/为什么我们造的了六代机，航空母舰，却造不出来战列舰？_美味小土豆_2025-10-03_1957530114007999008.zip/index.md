---
title: 为什么我们造的了六代机，航空母舰，却造不出来战列舰？
url: https://www.zhihu.com/question/1949013251879863886/answer/1957530114007999008
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 19:39
modified: 2025-10-03 19:39
upvote_num: 0
comment_num: 0
---

你说的战列舰，是这个东西吗？

![](./assets/v2-80f83b9f6bb978f1c0ea2c291d987cb8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='625'></svg>)

