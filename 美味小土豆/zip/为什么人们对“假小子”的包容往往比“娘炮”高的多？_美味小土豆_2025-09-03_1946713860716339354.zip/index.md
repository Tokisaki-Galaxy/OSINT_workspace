---
title: 为什么人们对“假小子”的包容往往比“娘炮”高的多？
url: https://www.zhihu.com/question/24776848/answer/1946713860716339354
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 23:19
modified: 2025-09-03 23:19
upvote_num: 276
comment_num: 64
---

交往过就知道了

假小子可是雌性中的雌性

浓度爆表的那种

而娘炮可不是雄性中的雄性。

![](./assets/v2-ae11a4c60163d8868a045ccae778a367_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-46f6c824edd6f12d153d93aea3e44bee_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-4cc7cd1ea165e877d765cf322b7523d4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-22024214e07cf94087fc1fe5a805e59d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-3f2b68e71f30b9dbb2530d152f45d1dc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-bc5b972f6f32ee68f6aa3554af90dd33_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-dc2579dd8dfb2d4459ac75de51d716f0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-7f1b07cc8fa71b10bae8bc7bd6392297_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

