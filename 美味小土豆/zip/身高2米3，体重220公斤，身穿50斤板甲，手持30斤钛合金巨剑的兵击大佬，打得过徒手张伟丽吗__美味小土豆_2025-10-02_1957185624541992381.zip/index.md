---
title: 身高2米3，体重220公斤，身穿50斤板甲，手持30斤钛合金巨剑的兵击大佬，打得过徒手张伟丽吗?
url: https://www.zhihu.com/question/9941209360/answer/1957185624541992381
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 20:50
modified: 2025-10-02 20:50
upvote_num: 452
comment_num: 100
---

![](./assets/v2-3c81f910dadfff9378a21aa93b4d98ef_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2730' height='1535'></svg>)

  


![](./assets/v2-788f3587f7e8263539d9e68200acc563_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2730' height='1535'></svg>)

徒手都很恐怖了。

![](./assets/v2-50fdc735a0877559727c50739d981c6d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2730' height='1535'></svg>)

让士官长上吧。

