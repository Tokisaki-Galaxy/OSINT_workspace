---
title: 你喝多了都干过什么蠢事？
url: https://www.zhihu.com/question/39916960/answer/1962927811175089739
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-18 17:07
modified: 2025-10-18 17:07
upvote_num: 190
comment_num: 10
---

喝高了在我前老板面前表演卡尔玛之死的国葬演讲。

现在想起来都觉得尴尬到爆炸。

她居然还饶有兴趣的听我慷慨激昂的讲完了，还鼓掌！

