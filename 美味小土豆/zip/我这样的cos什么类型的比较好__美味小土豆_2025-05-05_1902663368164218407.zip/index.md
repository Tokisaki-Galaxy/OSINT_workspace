---
title: 我这样的cos什么类型的比较好?
url: https://www.zhihu.com/question/1902110781136406474/answer/1902663368164218407
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-05-05 09:58
modified: 2025-05-05 09:58
upvote_num: 0
comment_num: 0
---

只要不是萝莉角色，出其他都没问题。你这个颜值画个妆在c圈算中等偏上了。怼脸无修自拍这个水平的话，带个假毛画个妆去会场基本无压力的

