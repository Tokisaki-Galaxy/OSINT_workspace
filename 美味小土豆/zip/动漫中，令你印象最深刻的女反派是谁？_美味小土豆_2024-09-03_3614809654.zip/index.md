---
title: 动漫中，令你印象最深刻的女反派是谁？
url: https://www.zhihu.com/question/665061695/answer/3614809654
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 20:51
modified: 2024-09-03 20:51
upvote_num: 3
comment_num: 2
---

藤乃静流会长！

![](./assets/v2-768c9e8206f074d0aa690279ed407bd8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='1080'></svg>)

  


![](./assets/v2-c73336e162daa13b41368421b44a32df_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='168'></svg>)

不管，hime大战的时候她就是反派

会长杀串一番地和砍翻奈绪时那个崩坏颜是真的飒！

