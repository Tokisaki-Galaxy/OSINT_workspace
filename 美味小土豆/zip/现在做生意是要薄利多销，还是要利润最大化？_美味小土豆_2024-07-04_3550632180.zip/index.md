---
title: 现在做生意是要薄利多销，还是要利润最大化？
url: https://www.zhihu.com/question/657008944/answer/3550632180
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-04 00:37
modified: 2024-07-04 00:37
upvote_num: 6
comment_num: 0
---

追求利润最大化你最惨不过是搞几个月发现搞不下了关门走人。薄利多销你可能会陷入慢性的半死不活然后拆东墙补西墙最后为了资金链不断而且不停举债，最后暴雷。

