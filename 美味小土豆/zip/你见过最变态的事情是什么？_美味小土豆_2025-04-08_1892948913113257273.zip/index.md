---
title: 你见过最变态的事情是什么？
url: https://www.zhihu.com/question/352066634/answer/1892948913113257273
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-08 14:36
modified: 2025-04-08 14:36
upvote_num: 0
comment_num: 0
---

制作1/100带内构的阿布萨拉斯3……

