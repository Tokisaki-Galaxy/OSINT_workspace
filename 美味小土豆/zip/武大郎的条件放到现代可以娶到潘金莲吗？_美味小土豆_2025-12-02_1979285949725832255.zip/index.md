---
title: 武大郎的条件放到现代可以娶到潘金莲吗？
url: https://www.zhihu.com/question/6296579620/answer/1979285949725832255
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-02 20:29
modified: 2025-12-02 20:29
upvote_num: 4
comment_num: 0
---

小说里的武大郎身高1米5不到，你就问问多少现代潘金莲是愿意嫁他的。

