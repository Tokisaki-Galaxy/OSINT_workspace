---
title: 乙女游戏女玩家跑去让男coser公主抱求婚礼是不是一种性压抑？
url: https://www.zhihu.com/question/1927439394752694125/answer/1928709262609213235
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-16 06:55
modified: 2025-07-16 06:55
upvote_num: 4
comment_num: 0
---

我出士官长的时候也有odst过来要我抱他

漫展不就是这样的地方嘛

