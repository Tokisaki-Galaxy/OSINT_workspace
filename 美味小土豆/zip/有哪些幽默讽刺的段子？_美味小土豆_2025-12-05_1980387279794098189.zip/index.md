---
title: 有哪些幽默讽刺的段子？
url: https://www.zhihu.com/question/32171868/answer/1980387279794098189
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-05 21:25
modified: 2025-12-05 21:25
upvote_num: 9
comment_num: 2
---

笑死

我在就事论事。

我不知道谁破防了

![](./assets/v2-47cde017a25fa688255ff32844544fe4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

