---
title: 面对把你名声搞臭诋毁你的人怎么做？
url: https://www.zhihu.com/question/471616888/answer/1978883815565977152
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 17:51
modified: 2025-12-01 17:51
upvote_num: 7
comment_num: 2
---

你长得好看，自有人会帮你说话。

然后对面就会气急败坏的上窜下跳。

