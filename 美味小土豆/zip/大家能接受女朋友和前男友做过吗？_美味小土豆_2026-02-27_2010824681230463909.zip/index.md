---
title: 大家能接受女朋友和前男友做过吗？
url: https://www.zhihu.com/question/658085083/answer/2010824681230463909
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 21:12
modified: 2026-02-27 21:12
upvote_num: 20
comment_num: 7
---

讲真，难道你们不觉得听妹子亲口承认自己超过她所有的男伴是一件很爽的事情吗？

我真的超喜欢驯服一架传奇支努干然后还能玩出更多的花样。

如果还能发给她前男友就更棒了~

