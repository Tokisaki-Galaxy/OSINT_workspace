---
title: 女友说「你对我很好是因为现在我是你女友，其他人是你女友你也会对她好，所以你不是真的爱我」，怎么回?
url: https://www.zhihu.com/question/495734671/answer/1937878371066413227
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 14:10
modified: 2025-08-10 14:10
upvote_num: 0
comment_num: 0
---

女生不答应做你女朋友你怎么敢爱她

当心告你强奸哦

