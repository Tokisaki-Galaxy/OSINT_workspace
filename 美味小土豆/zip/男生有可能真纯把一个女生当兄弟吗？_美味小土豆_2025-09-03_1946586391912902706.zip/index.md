---
title: 男生有可能真纯把一个女生当兄弟吗？
url: https://www.zhihu.com/question/306314800/answer/1946586391912902706
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 14:52
modified: 2025-09-03 14:54
upvote_num: 12
comment_num: 3
---

我的性癖变得奇怪就是因为我那个一直和我称兄道弟打篮球巨激进的短发黑皮假小子挚友在卡拉ok包间里偷偷给我看她奈子上的晒痕。

兄弟什么的真的太香了。

![](./assets/v2-204954ebfb295a9eb7314bda92cdea78_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1152' height='1536'></svg>)

