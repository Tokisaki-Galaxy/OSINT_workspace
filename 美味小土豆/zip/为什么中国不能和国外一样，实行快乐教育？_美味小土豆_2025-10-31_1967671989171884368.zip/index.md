---
title: 为什么中国不能和国外一样，实行快乐教育？
url: https://www.zhihu.com/question/1888215066513491188/answer/1967671989171884368
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-31 19:19
modified: 2025-10-31 19:19
upvote_num: 16
comment_num: 0
---

我这种从小学快乐到大学的人都不支持快乐教育。

我废物一个，我有家里给兜底。

你是全村的希望，你和废物学摆烂？

你日子不过啦？

