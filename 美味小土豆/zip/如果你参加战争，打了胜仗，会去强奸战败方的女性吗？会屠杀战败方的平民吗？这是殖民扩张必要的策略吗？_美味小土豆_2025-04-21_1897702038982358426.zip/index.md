---
title: 如果你参加战争，打了胜仗，会去强奸战败方的女性吗？会屠杀战败方的平民吗？这是殖民扩张必要的策略吗？
url: https://www.zhihu.com/question/14060975539/answer/1897702038982358426
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-21 17:23
modified: 2025-04-21 17:23
upvote_num: 1
comment_num: 0
---

所以我喜欢中国人民解放军。他们就算在东京估计也会帮老乡修屋顶。然后把财阀拖出去公审。

