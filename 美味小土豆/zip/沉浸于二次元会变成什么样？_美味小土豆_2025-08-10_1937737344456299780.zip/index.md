---
title: 沉浸于二次元会变成什么样？
url: https://www.zhihu.com/question/472687427/answer/1937737344456299780
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 04:49
modified: 2025-08-10 04:49
upvote_num: 31
comment_num: 0
---

会在说日语的时候语气像很做作的偶像小女孩

