---
title: 想要奖励学生，想发一些他们没见过的东西，有什么好的选择呢？求助万能的知友？
url: https://www.zhihu.com/question/36882377/answer/1944912355898132434
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-30 00:00
modified: 2025-08-30 00:00
upvote_num: 28
comment_num: 0
---

推荐老师一个便宜又很有特色的东西

用学生的照片，用ai跑一批画风可爱的q版图，做一批吧唧，做好包装，当成奖品。

学生一定会喜欢的，还不贵。

