---
title: 一个人的创业能成功吗？
url: https://www.zhihu.com/question/650627512/answer/3551680288
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-05 00:12
modified: 2024-07-05 00:12
upvote_num: 0
comment_num: 0
---

您能说得更清楚一些吗？也许我能给您一些建议。您意思是想做一件商品，但是无法把他具现化所以不知道应该怎么和制作商品的商家沟通吗？

