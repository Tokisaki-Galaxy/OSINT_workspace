---
title: 为什么985高富帅男不喜欢同为985的我而喜欢我一本的朋友？
url: https://www.zhihu.com/question/591565370/answer/1946367470031053177
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 00:22
modified: 2025-09-03 00:22
upvote_num: 8
comment_num: 0
---

985又不是什么性癖

你要说你8分颜值腿长奈子大，疑惑为什么同样8分长腿大胸肌的高富帅男不喜欢你而喜欢你6分白瘦幼平胸的朋友。

那这问题还有点讨论的意义。

