---
title: 老板凭什么做老板？
url: https://www.zhihu.com/question/20272786/answer/3551666970
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-04 23:51
modified: 2024-07-04 23:51
upvote_num: 8
comment_num: 1
---

“这些事情我一个人都会做，但是我一个人短时间里做不完，我现在把我自己做不完的活教给你们，你们认真学，不懂的我手把手教，房租水电住宿的钱我都付完了，你们的工资每个月都会按时发的，那么开始好好干活吧”

“好的老板”

