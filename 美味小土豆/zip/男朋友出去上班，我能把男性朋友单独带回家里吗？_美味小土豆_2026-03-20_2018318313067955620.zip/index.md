---
title: 男朋友出去上班，我能把男性朋友单独带回家里吗？
url: https://www.zhihu.com/question/658288440/answer/2018318313067955620
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-20 13:29
modified: 2026-03-20 13:29
upvote_num: 31
comment_num: 1
---

最好还是在外面开房，在家里会留下很重的气味，一时半会散不掉的，你很难糊弄过去。

