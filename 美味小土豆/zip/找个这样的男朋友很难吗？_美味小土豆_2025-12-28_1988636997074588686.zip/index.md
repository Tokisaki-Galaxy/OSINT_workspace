---
title: 找个这样的男朋友很难吗？
url: https://www.zhihu.com/question/587982337/answer/1988636997074588686
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-28 15:46
modified: 2025-12-28 15:46
upvote_num: 16
comment_num: 2
---

为什么总是要求不能玩游戏呢？

不玩游戏难道天天玩女朋友吗？

呃……好像专心玩女朋友也不是不行。

但是，首先女朋友得好玩才行啊……

