---
title: 为什么《狂飙》里的高启兰戴上眼镜那么美？
url: https://www.zhihu.com/question/586619207/answer/1955996153821782531
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-29 14:03
modified: 2025-09-29 14:03
upvote_num: 35
comment_num: 5
---

戴眼镜会让女性的脸看起来更小，眼睛更大。

调整脸型最简单直接的办法就是带眼镜，眼镜配的好至少可以凭空把颜值提高一两分。

这是一个很实用的技巧。

眼镜真的是不分种族不分时空不分肤色的人人平等的涩情装置!

![](./assets/v2-811d775232ac850c53286bce1fea65b8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-9f3779879d4026c47cc645f8bf5ac37f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-aa37cfb668bfd04cec3d52ba93816a3e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

  


![](./assets/v2-c270bb53500aa49d0fd231817ac4d1be_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

