---
title: 为什么男生非要先买车呢？
url: https://www.zhihu.com/question/1905452504453460485/answer/1949933528071508944
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 20:33
modified: 2025-09-12 20:33
upvote_num: 31
comment_num: 3
---

如果你除了车以外一无是处，那你确实得买车

买车可以让龟男升级成舔狗

