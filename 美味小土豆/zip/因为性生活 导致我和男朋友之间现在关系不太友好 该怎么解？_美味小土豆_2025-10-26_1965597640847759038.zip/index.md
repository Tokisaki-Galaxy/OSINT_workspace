---
title: 因为性生活 导致我和男朋友之间现在关系不太友好 该怎么解？
url: https://www.zhihu.com/question/1915747566521418866/answer/1965597640847759038
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 01:56
modified: 2025-10-26 01:56
upvote_num: 7
comment_num: 0
---

要不你换个男朋友试试看?

这样你就能明白到底是很烦他这个人还是很烦这件事了。

