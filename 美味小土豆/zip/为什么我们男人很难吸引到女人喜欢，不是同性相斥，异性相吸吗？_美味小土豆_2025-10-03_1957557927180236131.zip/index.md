---
title: 为什么我们男人很难吸引到女人喜欢，不是同性相斥，异性相吸吗？
url: https://www.zhihu.com/question/1956503404433119023/answer/1957557927180236131
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 21:29
modified: 2025-10-03 21:30
upvote_num: 8
comment_num: 1
---

因为很多时候，你还没思考清楚是不是有姑娘喜欢你，就忙不迭的去追那个你根本不知道是不是喜欢你的女人了。

