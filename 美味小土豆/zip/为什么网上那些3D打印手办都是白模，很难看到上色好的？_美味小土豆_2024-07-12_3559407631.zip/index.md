---
title: 为什么网上那些3D打印手办都是白模，很难看到上色好的？
url: https://www.zhihu.com/question/658128037/answer/3559407631
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-12 10:39
modified: 2024-07-12 10:39
upvote_num: 0
comment_num: 4
---

因为会3d打印的人不一定会上色

所以：“客人，上色是另外的价格哦”

其实不止上色。你看到照片上很漂亮的打印模型，你拿到手大概率是没办法完美的组装起来的。

