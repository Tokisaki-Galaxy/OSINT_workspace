---
title: 开门拿外卖你都穿的什么？
url: https://www.zhihu.com/question/1906132326653621000/answer/2013988693568946316
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-08 14:45
modified: 2026-03-08 14:45
upvote_num: 13
comment_num: 3
---

我试过让女孩子穿兔女郎，露背毛衣，浴巾，全裸套t恤，超小比基尼女仆装，只带项圈等各类衣服去开门拿外卖。

所有结果都是外卖小哥低着头放下外卖就跑。

有时候甚至开门了外卖小哥早就走远了……

