---
title: 为什么男人都吃绿茶那一套呢？
url: https://www.zhihu.com/question/411243359/answer/1935416445342315928
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-03 19:07
modified: 2025-08-03 19:07
upvote_num: 9
comment_num: 0
---

"你们不能因为她对我好就骂她绿茶啊!"

