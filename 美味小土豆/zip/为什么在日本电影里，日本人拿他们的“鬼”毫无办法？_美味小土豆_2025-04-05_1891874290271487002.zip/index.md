---
title: 为什么在日本电影里，日本人拿他们的“鬼”毫无办法？
url: https://www.zhihu.com/question/659507843/answer/1891874290271487002
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-04-05 15:26
modified: 2025-04-05 15:26
upvote_num: 105
comment_num: 3
---

那你应该看看特摄，日本三大特摄全是物理驱鬼，驱各种鬼。

![](./assets/v2-a555682abd807d1e2e8f3c3f1acb8ee0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='960' height='1280'></svg>)

