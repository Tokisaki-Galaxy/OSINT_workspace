---
title: 你觉得未来的人口大概是多少？
url: https://www.zhihu.com/question/650992370/answer/2002134643303003927
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-03 21:41
modified: 2026-02-03 21:41
upvote_num: 19
comment_num: 1
---

我记得小时候就说过中国人口最合适的数量应该是6-8亿，现在不是在稳步实现这个目标吗？

让这一代年轻人活得轻松一点吧。

