---
title: 为什么大部分文学作品中，舰船都被认作女性？
url: https://www.zhihu.com/question/607964668/answer/3576672534
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-29 03:30
modified: 2024-07-29 04:29
upvote_num: 9
comment_num: 0
---

母舰！母舰呀！大和可是能成为我母亲的战舰啊！

![](./assets/v2-d7de1ef48949fbd1852ceda93a3e3267_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1276' height='797'></svg>)

