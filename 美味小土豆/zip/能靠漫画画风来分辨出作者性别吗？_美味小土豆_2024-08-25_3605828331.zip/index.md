---
title: 能靠漫画画风来分辨出作者性别吗？
url: https://www.zhihu.com/question/582865469/answer/3605828331
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-25 21:49
modified: 2024-08-25 21:49
upvote_num: 5
comment_num: 0
---

女性作者很排斥画大乳头。

和一个画风很涩情的女画师有过工作上的交流，她画巨乳真的很顶，但是对于把乳头画大一点这件事情她拒绝了我三次。

事后她还感叹，原来男性的真实性癖这么深渊的吗？！

