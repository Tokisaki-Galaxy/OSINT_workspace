---
title: 今天的你存款有多少？
url: https://www.zhihu.com/question/375311567/answer/1986219996779664008
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-21 23:42
modified: 2025-12-21 23:42
upvote_num: 2
comment_num: 1
---

九十八块两毛……

该找我妈要饭钱去了

