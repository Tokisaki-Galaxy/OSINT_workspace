---
title: 女生们来回答一下，男生的颜值和身高哪个更重要？
url: https://www.zhihu.com/question/474811660/answer/1985492821587818054
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 23:32
modified: 2025-12-19 23:32
upvote_num: 2
comment_num: 0
---

我不是女生，但是既然邀请了那我就来插个话：

她们tmd是既要颜值又要身高！

