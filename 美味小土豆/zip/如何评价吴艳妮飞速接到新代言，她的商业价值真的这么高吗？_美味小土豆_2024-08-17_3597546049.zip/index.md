---
title: 如何评价吴艳妮飞速接到新代言，她的商业价值真的这么高吗？
url: https://www.zhihu.com/question/664464076/answer/3597546049
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-17 17:33
modified: 2024-08-19 22:42
upvote_num: 33
comment_num: 63
---

我唯独没想明白为什么说吴艳妮在男性里风评很差

啊？

她挺好看的啊

这种很会摆起手势的长跑美少女为啥在男性里风评很差？啊？

ps：有点不理解为啥都说她起跑那个姿势很装b，我还觉得挺有想法的。

