---
title: 如何看待巴黎奥运会中国美国金牌数 40:40 打平？
url: https://www.zhihu.com/question/664031029/answer/3592235443
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-12 19:28
modified: 2024-08-12 19:28
upvote_num: 1
comment_num: 0
---

40比40，金牌榜就是并列第一呀，有些人上蹿下跳恨极了得疯狂尖叫“就是第二！就是第二啊啊啊啊！！”

不是说国外对金牌根本不上心嘛，怎么那么输不起

