---
title: 为什么年轻人反感老一辈的说教?
url: https://www.zhihu.com/question/1892351298520715780/answer/1957084717959579319
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 14:09
modified: 2025-10-02 14:09
upvote_num: 14040
comment_num: 135
---

我挺愿意听我爸说教的

因为他一直爱说"男人口袋里不能没有钱"

他每次洋洋洒洒说完我一通以后就会问我"钱够不够?要多少？"

