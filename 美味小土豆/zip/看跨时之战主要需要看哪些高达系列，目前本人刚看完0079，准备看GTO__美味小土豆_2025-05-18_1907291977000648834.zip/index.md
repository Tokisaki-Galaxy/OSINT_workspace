---
title: 看跨时之战主要需要看哪些高达系列，目前本人刚看完0079，准备看GTO?
url: https://www.zhihu.com/question/1896612136068825213/answer/1907291977000648834
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-18 04:30
modified: 2025-05-18 04:30
upvote_num: 0
comment_num: 0
---

去看z高达

