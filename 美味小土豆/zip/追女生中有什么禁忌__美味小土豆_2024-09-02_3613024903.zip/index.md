---
title: 追女生中有什么禁忌?
url: https://www.zhihu.com/question/663865722/answer/3613024903
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-02 05:20
modified: 2024-09-02 05:20
upvote_num: 20
comment_num: 1
---

禁忌就是不要追，忽略她的性别，和她去交朋友。如果连朋友都做不了，那其他事情更没戏。

如果只能做朋友？那你起码有一个女性朋友了，多交一些女性朋友，这样找到自己另一半的概率就会大很多。

