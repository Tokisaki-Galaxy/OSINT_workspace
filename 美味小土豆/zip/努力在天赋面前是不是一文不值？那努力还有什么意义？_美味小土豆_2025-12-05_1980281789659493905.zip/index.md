---
title: 努力在天赋面前是不是一文不值？那努力还有什么意义？
url: https://www.zhihu.com/question/1951415883634282687/answer/1980281789659493905
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-05 14:26
modified: 2025-12-05 14:26
upvote_num: 5
comment_num: 0
---

没天赋你就不过日子了？

你能搬十块砖我只能搬两块砖，包工头也不会只雇你不雇我呀。

