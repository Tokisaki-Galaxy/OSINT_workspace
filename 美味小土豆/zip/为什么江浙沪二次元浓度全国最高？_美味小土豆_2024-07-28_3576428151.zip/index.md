---
title: 为什么江浙沪二次元浓度全国最高？
url: https://www.zhihu.com/question/655749658/answer/3576428151
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-28 20:32
modified: 2024-07-28 20:33
upvote_num: 15
comment_num: 1
---

上海在1997年可以同步看到EVA剧场版真心为你，当然，载体是盗版碟

还能同步买到剧场版限定的EVA量产型的hg模型

当时不觉得，现在回想起来真得蛮夸张的

