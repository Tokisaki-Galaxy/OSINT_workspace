---
title: 同事说「我一根项链，比你一身都贵」，你如何回应呢？
url: https://www.zhihu.com/question/2003842544325374495/answer/2006700575593621482
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-16 12:04
modified: 2026-02-16 12:04
upvote_num: 7
comment_num: 0
---

"富婆姐姐v我五块钱买可乐吧~"

