---
title: 如何评价农村修祠堂、族谱的现象？
url: https://www.zhihu.com/question/543993642/answer/3594441043
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-14 18:26
modified: 2024-08-14 18:26
upvote_num: 2
comment_num: 0
---

宗族 ×

不结婚一个人没有软肋 ×

有父母有孩子有房贷有软肋但是没有关系好的亲戚朋友 ✓

