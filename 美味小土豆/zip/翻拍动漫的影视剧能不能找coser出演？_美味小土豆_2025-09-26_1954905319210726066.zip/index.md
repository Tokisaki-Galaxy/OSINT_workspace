---
title: 翻拍动漫的影视剧能不能找coser出演？
url: https://www.zhihu.com/question/8953443817/answer/1954905319210726066
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-26 13:49
modified: 2025-09-27 22:22
upvote_num: 1
comment_num: 0
---

有些coser连私房av都拍不好……

