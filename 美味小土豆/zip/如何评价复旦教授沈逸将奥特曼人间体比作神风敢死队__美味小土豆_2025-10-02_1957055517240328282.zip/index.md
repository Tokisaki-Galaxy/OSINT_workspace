---
title: 如何评价复旦教授沈逸将奥特曼人间体比作神风敢死队?
url: https://www.zhihu.com/question/1948065532420035575/answer/1957055517240328282
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 12:13
modified: 2025-10-02 12:13
upvote_num: 7
comment_num: 1
---

全世界人类都有"神风"这个属性。

![](./assets/v2-4c14d89b0c02e10531359d44283c4141_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

  


![](./assets/v2-c0bd369c9542a9ce74fe6030666c8ab2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2652' height='1200'></svg>)

偏偏是创造出这个词的日本在这个属性上最拉胯。

相当搞笑。

