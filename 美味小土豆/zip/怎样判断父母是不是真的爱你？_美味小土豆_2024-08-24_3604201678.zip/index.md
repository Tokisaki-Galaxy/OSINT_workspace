---
title: 怎样判断父母是不是真的爱你？
url: https://www.zhihu.com/question/321353759/answer/3604201678
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 02:43
modified: 2024-08-24 02:43
upvote_num: 6
comment_num: 0
---

我这辈子，没有实现我父母所期望的任何一件事情——好好学习，结婚生子，找一份稳定的工作。

然后他们现在对我最大的要求是“要照顾好自己，要过得开心”。(T^T)

我不知道我上辈子是不是拯救了地球了所以能遇到这样的父母。

