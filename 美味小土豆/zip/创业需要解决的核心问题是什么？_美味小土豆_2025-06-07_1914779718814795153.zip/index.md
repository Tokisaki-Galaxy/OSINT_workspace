---
title: 创业需要解决的核心问题是什么？
url: https://www.zhihu.com/question/12788004521/answer/1914779718814795153
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-06-07 20:24
modified: 2025-06-07 20:24
upvote_num: 0
comment_num: 0
---

能赚钱，能迅速的赚到钱，能做出来就能赚到钱

