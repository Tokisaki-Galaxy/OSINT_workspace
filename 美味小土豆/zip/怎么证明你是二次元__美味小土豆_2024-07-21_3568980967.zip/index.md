---
title: 怎么证明你是二次元?
url: https://www.zhihu.com/question/661747713/answer/3568980967
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 19:16
modified: 2024-07-21 19:16
upvote_num: 9
comment_num: 0
---

“这啥啊？我不懂的，没看过，不懂你们年轻人现在的喜好”

