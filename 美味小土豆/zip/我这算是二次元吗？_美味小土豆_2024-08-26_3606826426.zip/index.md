---
title: 我这算是二次元吗？
url: https://www.zhihu.com/question/620793010/answer/3606826426
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-26 20:17
modified: 2024-08-26 20:17
upvote_num: 3
comment_num: 0
---

我这种不买谷子不玩原神崩铁不扩列不自己逛漫展不会报新番菜名的基本已经被开除二次元籍了

![](./assets/v2-a9c60a10eacb5022ce5bb77ffb89cf1d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-b1f76e2c3f0f2dbbccd5e20865ef3b6a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

