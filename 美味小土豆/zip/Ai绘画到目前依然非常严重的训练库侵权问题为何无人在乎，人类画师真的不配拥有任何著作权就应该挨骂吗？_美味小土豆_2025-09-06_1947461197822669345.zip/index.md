---
title: Ai绘画到目前依然非常严重的训练库侵权问题为何无人在乎，人类画师真的不配拥有任何著作权就应该挨骂吗？
url: https://www.zhihu.com/question/610415864/answer/1947461197822669345
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 00:48
modified: 2025-09-06 00:48
upvote_num: 2
comment_num: 0
---

无论怎么鄙视

等到掏真金白银的时候，顾客还是坚决不认ai跑出来的东西。

所以我到现在都不担心ai跑图

