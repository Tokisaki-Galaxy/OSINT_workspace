---
title: 男生178 女生164 经常被女朋友说矮 178真的矮吗?
url: https://www.zhihu.com/question/9402890830/answer/2021174094750651548
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-28 10:37
modified: 2026-03-28 10:37
upvote_num: 14
comment_num: 5
---

178不矮的

但是现在有些女生对身高的要求已经是贪婪的匪夷所思。

我都被妹子说过"你也不是很高嘛~"

我192……

真的，她们已经疯了！

