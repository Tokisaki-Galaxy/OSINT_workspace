---
title: “很具性张力”的长相是什么样？
url: https://www.zhihu.com/question/356366499/answer/1937728297669735695
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 04:13
modified: 2025-08-10 04:13
upvote_num: 0
comment_num: 0
---

![](./assets/v2-e06d198dfc5beea597a4a0327c03e148_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='800'></svg>)

  


![](./assets/v2-b78321a55f5490403e98be7db8844e31_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1728' height='1080'></svg>)

谁又能拒绝约翰117呢

