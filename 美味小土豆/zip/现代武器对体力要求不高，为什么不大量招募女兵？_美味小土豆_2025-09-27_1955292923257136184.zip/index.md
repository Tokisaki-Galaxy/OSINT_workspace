---
title: 现代武器对体力要求不高，为什么不大量招募女兵？
url: https://www.zhihu.com/question/299414354/answer/1955292923257136184
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 15:29
modified: 2025-09-27 15:29
upvote_num: 4
comment_num: 1
---

当年我们cos社团那帮傻●姑娘们玩少前入脑了，吵着要玩wargame。

——这么说吧，我空手都没办法一口气干掉她们所有人，而拿彩弹枪我做到了。

1vs8，全灭。

