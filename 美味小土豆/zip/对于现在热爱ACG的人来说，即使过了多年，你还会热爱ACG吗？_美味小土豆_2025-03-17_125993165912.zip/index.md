---
title: 对于现在热爱ACG的人来说，即使过了多年，你还会热爱ACG吗？
url: https://www.zhihu.com/question/14495647505/answer/125993165912
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-03-17 07:58
modified: 2025-03-17 07:58
upvote_num: 12
comment_num: 4
---

二十年前我疯狂喜欢上高达的时候，我姐姐给还是小学生的我买了一盒hg的佐罗亚特，我开心的说我会永远喜欢他们的。当时我姐姐还笑嘻嘻的嘲笑我，说我最多喜欢个四五年了不起了。

然后今年过年我送了她儿子mg的fazz。而hg的佐罗亚特，算上我姐送的，我有三盒了。

