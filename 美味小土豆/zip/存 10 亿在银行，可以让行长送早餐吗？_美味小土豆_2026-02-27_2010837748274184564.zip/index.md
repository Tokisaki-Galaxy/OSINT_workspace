---
title: 存 10 亿在银行，可以让行长送早餐吗？
url: https://www.zhihu.com/question/638154117/answer/2010837748274184564
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-27 22:04
modified: 2026-02-27 22:04
upvote_num: 2
comment_num: 1
---

你存200万就能让开户行的客户经理给你端咖啡了。

