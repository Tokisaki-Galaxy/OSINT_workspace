---
title: 为什么现在男生普遍不追女生了？
url: https://www.zhihu.com/question/64131048/answer/3543171203
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-06-26 21:17
modified: 2024-06-26 21:17
upvote_num: 9
comment_num: 4
---

说个不相关的事情——为什么这两年国产模型厂突然多了那么多，男性的消费力似乎突然间就上去了。

