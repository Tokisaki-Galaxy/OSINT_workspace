---
title: 男朋友这样称呼我正常嘛？
url: https://www.zhihu.com/question/613803881/answer/1964003204992857413
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 16:20
modified: 2025-10-21 16:20
upvote_num: 6
comment_num: 0
---

我对着酷爱dirty talk，热衷被扇脸的小母狗，都没用"傻逼"称呼过她。

你们的play真是相当硬核呢，师匠。

