---
title: 如果让你去讨伐哥布林，你会使用什么战术?
url: https://www.zhihu.com/question/631283178/answer/1963361439910695268
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-19 21:50
modified: 2025-10-19 21:50
upvote_num: 1
comment_num: 1
---

![](./assets/v2-331d7d2f282d65d052fa0fc86dca0054_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1058' height='1154'></svg>)

