---
title: 为什么现在很多二次元玩家以卖肉为荣？
url: https://www.zhihu.com/question/658207295/answer/3569017040
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-21 20:12
modified: 2024-07-21 20:12
upvote_num: 1
comment_num: 0
---

开玩笑，美好的肉体本来就是二次元一直在着力表达的东西啊

![](./assets/v2-312f83dbea7007a8aaebcb6f3b82c908_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='526'></svg>)

  


![](./assets/v2-22a9a17ab4e36e662cb860e5a26da3e1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='538'></svg>)

  


![](./assets/v2-2d4b7e8201a4c2ff364b97acad5a2fe9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='476' height='781'></svg>)

难道你们从来没想过让自己女朋友穿上典子的运动服吗？

