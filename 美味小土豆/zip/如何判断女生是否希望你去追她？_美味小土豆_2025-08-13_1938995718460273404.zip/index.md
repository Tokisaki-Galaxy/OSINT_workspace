---
title: 如何判断女生是否希望你去追她？
url: https://www.zhihu.com/question/27610077/answer/1938995718460273404
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-13 16:10
modified: 2025-08-13 16:10
upvote_num: 11
comment_num: 1
---

我高中和我前女友就是漫展结束以后开完一局我才开始思考这个问题的

"我是不是得告个白了啊啊啊啊啊"

