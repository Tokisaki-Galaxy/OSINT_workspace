---
title: 为什么中国农村房子那么丑？
url: https://www.zhihu.com/question/269801912/answer/3609046379
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-28 21:06
modified: 2024-08-28 21:06
upvote_num: 1
comment_num: 7
---

浙江农村最近几年新建的我觉得还是挺好看的

这是我在村里随手拍的

  


![](./assets/v2-ace2014a808c8201f2952dbc9867af57_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='4000' height='3000'></svg>)

  


![](./assets/v2-3a0e7105ca7137a65f3e5f3e60b9695f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-7c632532442d26b6a19243e456f1673f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-2f13f3e2bbb1b474a54c55eaef2805ab_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-13adbd6af000320bf4abc46a4495f545_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-f84112231d6abaaa3f9a2ace2252c18d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-6df371b6701b17d12ed17a565df0364b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-a872a6139b2df18497a5886b900708b1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-f31d04a536db1b5816525d4e6eefa881_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-4112429fadf594760e734354c6d7cda1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-b57d0f5306be55e70361d86f7a066471_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

  


![](./assets/v2-5edaeb75f8609a1b5d6e68ffaeb502a9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

  


![](./assets/v2-0da6ce0e39b563930ddb0cd4b7ef2087_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='1536'></svg>)

现在浙江农村的新房基本都是这样的风格的。造型方正，得房率高，大面积使用落地玻璃，采光亮堂，稍微装修一下住起来还是很舒服的。

