---
title: 为什么原画和建模总会打架，这中间有什么技术难题吗？
url: https://www.zhihu.com/question/338007913/answer/3561878862
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 21:35
modified: 2024-07-14 21:35
upvote_num: 1
comment_num: 0
---

我自己做建模的时候都会骂我自己“你个煞笔画的是什么啊？”

唯一的好处就是我想改就改

