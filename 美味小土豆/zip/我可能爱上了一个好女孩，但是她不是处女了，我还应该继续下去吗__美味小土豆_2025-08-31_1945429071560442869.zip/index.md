---
title: 我可能爱上了一个好女孩，但是她不是处女了，我还应该继续下去吗?
url: https://www.zhihu.com/question/1942787522854907917/answer/1945429071560442869
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 10:13
modified: 2025-08-31 10:13
upvote_num: 0
comment_num: 0
---

你不爱她，只是她刚好符合你的条件，否则你不会来问这个问题的。

你也找不到更好的，否则你也不会来问这个问题。

我话比较难听——如果你找不到更好的，就别挑挑拣拣了。

