---
title: 不论主角光环，沙扎比和牛高达谁的性能更强？
url: https://www.zhihu.com/question/524577348/answer/2017704569858172184
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-18 20:50
modified: 2026-03-18 20:50
upvote_num: 3
comment_num: 0
---

当然是山楂饼。

牛高达别名塞可缪杰刚

