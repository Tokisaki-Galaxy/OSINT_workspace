---
title: 如果有两个少女在你面前身中剧毒，并且一炷香之内没有服用解药必死无疑，而你只有一份解药，你会给谁呢？
url: https://www.zhihu.com/question/352716155/answer/3575780507
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-28 04:49
modified: 2024-07-28 04:49
upvote_num: 1
comment_num: 0
---

两个美少女？有流萤吗？我救流萤！！

