---
title: 大家有没有觉得“不理解但尊重”这句话很奇怪？因为真正的尊重难道不是基于理解吗？
url: https://www.zhihu.com/question/1941187534550983035/answer/1963780781315948625
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-21 01:37
modified: 2025-10-21 01:37
upvote_num: 21
comment_num: 8
---

就像我内心一直觉得花钱买性是一件很可怜的事情。

但是我不会去嘲讽和看不起任何一个热衷嫖娼的家伙。

第一是因为我道德底线低。

第二是因为我觉得大家都是男人，没必要在这种事情上搞什么优越感和歧视。

不理解，但尊重。

反正你死活也和我没关系。

![](./assets/v2-604c423a628a9a8fdb03fa85f3004b29_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='928' height='1232'></svg>)

