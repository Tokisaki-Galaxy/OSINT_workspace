---
title: 早恋有那些坏处?
url: https://www.zhihu.com/question/1944482045825913171/answer/1955548259876602023
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-28 08:23
modified: 2025-09-28 08:23
upvote_num: 10
comment_num: 4
---

早恋多了长大以后容易养成习惯性撒谎并且毫无道德包袱。

因为每天都要骗老师骗家长骗校长骗coser姐姐骗学妹骗学习委员骗当时的女友还有骗酒店前台。

早恋的孩子一般都不可能是老实孩子

