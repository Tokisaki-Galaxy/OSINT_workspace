---
title: 身高和头身比哪个更重要？
url: https://www.zhihu.com/question/1965904820574619338/answer/1974165230956343766
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-18 17:21
modified: 2025-11-18 17:21
upvote_num: 170
comment_num: 54
---

我当年去面试的那个野鸡模特班，来了200多个1米85以上的男生，最后只要了毛30个人。

头身比不行你身高一文不值。

