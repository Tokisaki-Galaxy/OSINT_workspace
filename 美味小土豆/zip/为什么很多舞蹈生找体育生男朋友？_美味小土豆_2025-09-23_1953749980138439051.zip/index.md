---
title: 为什么很多舞蹈生找体育生男朋友？
url: https://www.zhihu.com/question/1942714503994282376/answer/1953749980138439051
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-23 09:18
modified: 2025-09-23 09:18
upvote_num: 114
comment_num: 15
---

不是，一个练体育的到哪里去找舞蹈生啊？

我在田径队里的时候撑死了能勾搭隔壁游泳队的。

我能认识舞蹈生都得到当模特的时候了。

