---
title: 为什么中国男性大都不注意身材，外形，穿衣？
url: https://www.zhihu.com/question/283866167/answer/1939614718085030623
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 09:09
modified: 2025-08-15 09:09
upvote_num: 8
comment_num: 0
---

没有每个月额外买衣服打理外表的钱。

没有每天运动健身的时间

没有每天思考怎么搭配衣服的精力呗。

你有这个精力时间和钱？那你要被其他男的骂了。

