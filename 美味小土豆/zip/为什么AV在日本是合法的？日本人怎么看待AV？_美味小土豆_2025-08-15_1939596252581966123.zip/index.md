---
title: 为什么AV在日本是合法的？日本人怎么看待AV？
url: https://www.zhihu.com/question/22758947/answer/1939596252581966123
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 07:56
modified: 2025-08-15 07:56
upvote_num: 0
comment_num: 0
---

不管什么AV在日本都上不了台面

98-AV也不行

首都圈老百姓都讨厌

