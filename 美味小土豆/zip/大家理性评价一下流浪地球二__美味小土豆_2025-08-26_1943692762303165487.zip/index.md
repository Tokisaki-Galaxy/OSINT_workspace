---
title: 大家理性评价一下流浪地球二?
url: https://www.zhihu.com/question/580223208/answer/1943692762303165487
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-26 15:14
modified: 2025-08-26 15:14
upvote_num: 1
comment_num: 1
---

国产电影最好空战

