---
title: 部分宅男喜欢在网上扮二次元美少女的原因是什么？
url: https://www.zhihu.com/question/654807141/answer/2017286682261598709
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-17 17:10
modified: 2026-03-18 13:08
upvote_num: 413
comment_num: 64
---

那我更冤枉了。

我一不用二次元头像，二不取可爱的名字，三不会隐瞒我的性别装女人。

都这样了我在网上还经常被人认为是女生。

我在知乎都吹水了那么多和小姑娘腻腻歪歪的日常，居然还会被认为是女的反串……

我经常在聊天的时候被人说"你说话好可爱啊"，男女都这么说过。

明明我都没有讲过什么奇怪的话。

以前在朋友的cos群被人认错成女生，问我能不能陪他去cj，我说我是男的……他说男娘也行，我说我1米92，体重85公斤，他才作罢。

[![](./assets/v2-74665a8cffedaecc15103f2aa23890bd_720w.jpg)https://www.zhihu.com/video/2017588132703412561](https://link.zhihu.com/?target=https%3A//www.zhihu.com/video/2017588132703412561)

  


![](./assets/v2-3154fd5d96592e858cd52aec05d7abdf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='928' height='1312'></svg>)

