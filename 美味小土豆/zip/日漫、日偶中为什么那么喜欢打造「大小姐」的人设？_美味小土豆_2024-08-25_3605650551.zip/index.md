---
title: 日漫、日偶中为什么那么喜欢打造「大小姐」的人设？
url: https://www.zhihu.com/question/592595315/answer/3605650551
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-25 17:46
modified: 2024-08-26 19:08
upvote_num: 154
comment_num: 19
---

终于知道怎么发无水印的图了

———————我是分割线———————————

因为大小姐真的很棒。

我给大小姐当过跑腿的。

每次周末放学接她她都会请我吃饭。

休息天她去泡温泉也会算我一个人头，我只要洗完等她穿好衣服帮她梳头就行。

去迪士尼只要帮她拎鞋拎包她就包我两天的门票和酒店和餐费。走之前还给我2k的拎包费。

去漫展只要帮她拎包她就包我的全部费用。

当年她最虎的一次是在本来应该上课的时间打电话给我，问我有没有港澳通行证，她想去香港玩。我说大小姐你还在上课，不好吧，她说这破课她一天都上不下去了，现在就要逃学，她带着二十万，说分我一半，但是要我带她去香港玩。

我说好的，你等着我，你在哪？我现在就来接你

然后我打电话告诉她爸爸：“老板大事不好了，您女儿要离家出走了！”，然后她爸爸带人在高速前面就把我们拦下了。

然后我就被她炒鱿鱼了……

哎，以前每周带我去吃的晚饭真的挺好吃的(T^T)

![](./assets/v2-655e42612e9196577d8250ebfeca130b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

  


![](./assets/v2-b54ecc77d1b5a49b9beedc12500f2fb4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

  


![](./assets/v2-d70e283155d525ec9f98b19c70adef8a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

  


![](./assets/v2-447030a14a42342564deb21e7fcc08b4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='780' height='1140'></svg>)

