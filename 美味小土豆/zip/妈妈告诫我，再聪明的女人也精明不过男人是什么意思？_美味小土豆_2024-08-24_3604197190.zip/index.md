---
title: 妈妈告诫我，再聪明的女人也精明不过男人是什么意思？
url: https://www.zhihu.com/question/555095784/answer/3604197190
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 02:24
modified: 2024-08-24 02:24
upvote_num: 12
comment_num: 3
---

有些时候不是女人精明不过男人，而是有的男人根本不和女人谈，比如一些广东老板。我一个女性朋友自己开公司的，但是她每次和广东人谈生意都会叫上我，因为即使她是老板，有些广东老板也不把她当回事。

