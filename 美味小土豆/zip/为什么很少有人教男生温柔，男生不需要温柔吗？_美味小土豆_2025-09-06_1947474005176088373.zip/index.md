---
title: 为什么很少有人教男生温柔，男生不需要温柔吗？
url: https://www.zhihu.com/question/1944076389339881901/answer/1947474005176088373
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-06 01:39
modified: 2025-09-06 01:39
upvote_num: 8
comment_num: 0
---

如果你长得很高，擅长打架，举止狂野。

那么性格温柔就是很让人心动的特点了。

