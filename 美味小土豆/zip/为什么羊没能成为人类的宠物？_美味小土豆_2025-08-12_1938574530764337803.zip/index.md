---
title: 为什么羊没能成为人类的宠物？
url: https://www.zhihu.com/question/275449005/answer/1938574530764337803
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-12 12:16
modified: 2025-08-12 12:16
upvote_num: 0
comment_num: 0
---

我老家的羊能碾得我和我表弟还有我的狗子满山跑……

