---
title: 什么可以看出一个女孩很聪明？
url: https://www.zhihu.com/question/361586177/answer/1940032330237470339
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-16 12:49
modified: 2025-08-16 12:49
upvote_num: 7
comment_num: 0
---

她告诉你一件事她自己能解决，不要管她

她最后真的完美解决了这件事情。

比你平时做的还靠谱还有效率。

你一年才学会的手艺，她看三天就会。

做什么事情都像模像样。

