---
title: 要是你突然继承了8000万。明天起床先做什么？
url: https://www.zhihu.com/question/1923394092647298305/answer/1982832070540689892
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-12 15:20
modified: 2025-12-12 15:20
upvote_num: 70
comment_num: 2
---

"等等，让我静一静，我爸妈都死了？！"

"为什么只有8000万了……"

