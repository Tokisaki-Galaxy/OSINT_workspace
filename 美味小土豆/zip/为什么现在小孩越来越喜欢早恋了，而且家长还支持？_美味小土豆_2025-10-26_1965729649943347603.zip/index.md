---
title: 为什么现在小孩越来越喜欢早恋了，而且家长还支持？
url: https://www.zhihu.com/question/10955433455/answer/1965729649943347603
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-26 10:41
modified: 2025-10-26 10:41
upvote_num: 31
comment_num: 3
---

家长支持早恋是希望能降低下一代的婚恋成本，得到更稳定的婚恋关系。

比如我妈在我初中的时候就爱撮合我和她姐妹淘的女儿们。

但是我妈不知道，我早恋纯是在玩，根本没考虑过结婚……

