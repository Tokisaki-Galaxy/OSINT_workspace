---
title: 如何评价多位 Coser 一边打拳一边搞擦边？
url: https://www.zhihu.com/question/2001012911/answer/1890711393600249869
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-02 10:25
modified: 2025-04-02 10:25
upvote_num: 8
comment_num: 0
---

玩cosplay的朋友和我说过一句很有趣的话——“coser的私信就像赛博浦西，每天收到最多的就是各种电子金箔”。

时间久了对男性的看法自然就变了。

