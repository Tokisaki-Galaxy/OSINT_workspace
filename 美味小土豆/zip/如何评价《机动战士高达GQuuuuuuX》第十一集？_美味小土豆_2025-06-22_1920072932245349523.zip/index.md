---
title: 如何评价《机动战士高达GQuuuuuuX》第十一集？
url: https://www.zhihu.com/question/1918471283760428745/answer/1920072932245349523
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-06-22 10:57
modified: 2025-06-22 10:57
upvote_num: 41
comment_num: 11
---

不论gquuuuux的争议点有多大，这片能让看完的05后饶有兴趣的去补0079的tv，我觉得光这点真的是近几年的几部新tv都无法做到的，很牛逼。

