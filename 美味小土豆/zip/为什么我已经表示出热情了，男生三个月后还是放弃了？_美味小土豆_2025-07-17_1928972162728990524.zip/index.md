---
title: 为什么我已经表示出热情了，男生三个月后还是放弃了？
url: https://www.zhihu.com/question/612383582/answer/1928972162728990524
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-07-17 00:20
modified: 2025-07-17 00:20
upvote_num: 0
comment_num: 0
---

是这样的，一般女生在三分钟里对我没兴趣我就会乖乖放弃了。

能坚持三个月的，什么高级龟鳖男

