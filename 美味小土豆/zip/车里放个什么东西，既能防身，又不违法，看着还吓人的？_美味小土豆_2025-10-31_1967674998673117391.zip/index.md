---
title: 车里放个什么东西，既能防身，又不违法，看着还吓人的？
url: https://www.zhihu.com/question/632563155/answer/1967674998673117391
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-31 19:31
modified: 2025-10-31 19:31
upvote_num: 22
comment_num: 0
---

我自己

想起来知乎那个"后备箱里放什么东西可以吓住一米八的路怒症壮汉了"

我的回答是"看起来很生气的一米九的我自己"

