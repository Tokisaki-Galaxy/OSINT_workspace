---
title: 喜欢萝莉犯法吗?
url: https://www.zhihu.com/question/1936097289396519018/answer/1957533007847065320
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 19:50
modified: 2025-10-03 19:50
upvote_num: 7
comment_num: 0
---

管她呢的呢！你都喜欢萝莉了，还在意犯不犯法？!

![](./assets/v2-6734a0d90b350b2e065ce01682d06d28_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='600' height='876'></svg>)

  


![](./assets/v2-db4d19390a942a09027ca14dbdc79ad4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='768' height='768'></svg>)

