---
title: 谈恋爱怎样避免找到像翟欣欣一样的女朋友？
url: https://www.zhihu.com/question/65213069/answer/1957528810686767788
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-10-03 19:33
modified: 2025-10-03 19:34
upvote_num: 157
comment_num: 16
---

以最烂的面貌和女生社交。

妹子邀请我出去玩，我的起手式就是"没钱，要不请我吃饭吧"

只要你别太丑，只要你愿意请我吃饭，我就能湉着个屌脸陪你。

只要她不嫌弃我，我就会认真考虑陪她一阵子。

