---
title: 你有小小的怪癖吗？
url: https://www.zhihu.com/question/656121584/answer/1946946786980782251
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-04 14:44
modified: 2025-09-04 14:44
upvote_num: 7
comment_num: 1
---

我副业是写galgame剧本。

小甜文小台本也写

我经常把我的个人经历写进脚本里

然后看别人的评价

