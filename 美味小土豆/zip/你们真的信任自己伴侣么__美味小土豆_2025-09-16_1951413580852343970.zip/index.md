---
title: 你们真的信任自己伴侣么?
url: https://www.zhihu.com/question/608629596/answer/1951413580852343970
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-16 22:34
modified: 2025-09-16 22:34
upvote_num: 13
comment_num: 2
---

我cp有句话巨糙但是巨有道理

xxx又没让你🌿过，你信他不信我？

