---
title: 为什么盐汽水只在江浙沪地区流行，其它地区很少有人喝呢？
url: https://www.zhihu.com/question/20402388/answer/1943284097909777455
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2025-08-25 12:10
modified: 2025-08-25 12:10
upvote_num: 1
comment_num: 1
---

这b东西巨难喝，尤其是不冰的

我爸巨爱喝，夏天一车一车的往家里搬，占满整个冰箱。

他说这是他童年的味道

