---
title: 为什么我经常能看到女生欣赏偏男性向的作品，却很少看见男生欣赏偏女性向的？
url: https://www.zhihu.com/question/549005298/answer/1937901035344606979
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 15:40
modified: 2025-08-10 15:40
upvote_num: 3
comment_num: 1
---

更衣人偶就是偏女性向的作品啊

作者绝对是画少女漫画的。

就很好看啊。

我和你们说，看恋爱番还是要看少女漫画，狂野的不得了！

