---
title: 结账时发现东西很贵怎么办？
url: https://www.zhihu.com/question/287356623/answer/1978926365509194831
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-01 20:40
modified: 2025-12-01 20:40
upvote_num: 46
comment_num: 0
---

"对不起，我买不起，我不要了"

这句话让我每年节约了很多钱。

买不起又不是啥丢脸的事情。

