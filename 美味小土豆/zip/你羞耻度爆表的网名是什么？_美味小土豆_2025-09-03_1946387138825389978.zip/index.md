---
title: 你羞耻度爆表的网名是什么？
url: https://www.zhihu.com/question/350896779/answer/1946387138825389978
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 01:40
modified: 2025-09-03 01:41
upvote_num: 2
comment_num: 1
---

我微信和qq名字都叫"太阳使者无敌铁人28号"

所以我加女生都是用小号，熟了才会给她们我的大号……

