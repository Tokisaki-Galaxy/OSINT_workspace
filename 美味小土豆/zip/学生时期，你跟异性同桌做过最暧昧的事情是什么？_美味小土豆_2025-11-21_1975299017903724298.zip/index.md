---
title: 学生时期，你跟异性同桌做过最暧昧的事情是什么？
url: https://www.zhihu.com/question/412372409/answer/1975299017903724298
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-21 20:26
modified: 2025-11-21 20:26
upvote_num: 11
comment_num: 6
---

真羡慕你们懵懵懂懂的纯爱党。

不像我……差点把同桌搞怀孕了。

说起来，我初中高中好像有对异性同桌特攻属性。

![](./assets/v2-db88eb53a3eb01d198ccd0d3e48e57e0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='675' height='1200'></svg>)

