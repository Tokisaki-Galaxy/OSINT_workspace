---
title: 你见到了异性版本的你，与你有着相同的爱好，习惯和思想，你们会不会永远的一起幸福生活？
url: https://www.zhihu.com/question/1955452669423510344/answer/1956356168604690165
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-30 13:54
modified: 2025-09-30 13:54
upvote_num: 6
comment_num: 4
---

你说的是一个"身高192，性格开朗，没心没肺，脸皮巨厚！还有性瘾的黑皮体育女生?"

哇……那我能让她一直怀孕。

