---
title: 女朋友不想和我做，该咋办？
url: https://www.zhihu.com/question/650844101/answer/1957188194224305349
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 21:00
modified: 2025-10-02 21:00
upvote_num: 916
comment_num: 13
---

所以你不仅浪费掉了高一高二高三大一这四年美好的时光，然后现在还准备继续浪费下去？

那你总有一天会后悔的。

趁着你还没太怨恨她之前快点分手吧

否则你将来一定恨死她。

