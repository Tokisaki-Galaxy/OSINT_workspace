---
title: “军迷”到底是一类什么样的人，好不好相处？
url: https://www.zhihu.com/question/41405037/answer/1957363434027974850
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-03 08:36
modified: 2025-10-03 08:36
upvote_num: 6
comment_num: 1
---

沉迷宏大叙事

普遍性压抑

人均ETC转世

热衷于各类黑话且充满优越感。

集厌女渴女于一身的究极矛盾体。

言必"有战舰当老婆还要什么女人啊!"，但是他们口中的战舰就是个大奈子烧鸡啊！

![](./assets/v2-6f81ea8a9f6d11a1328725fb0a2bad92_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='822' height='1200'></svg>)

