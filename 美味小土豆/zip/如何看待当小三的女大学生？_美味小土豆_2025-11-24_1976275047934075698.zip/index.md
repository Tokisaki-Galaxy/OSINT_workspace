---
title: 如何看待当小三的女大学生？
url: https://www.zhihu.com/question/598667665/answer/1976275047934075698
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-11-24 13:04
modified: 2025-11-24 13:04
upvote_num: 17
comment_num: 1
---

说起来，为什么女生牛了别人就叫小三 ，而男性就被叫黄毛呢。

感觉侵略性完全不一样。

啊？问我怎么看待的？我这种三观已经腐烂的黑皮黄毛难道还要去批判女小三吗？

