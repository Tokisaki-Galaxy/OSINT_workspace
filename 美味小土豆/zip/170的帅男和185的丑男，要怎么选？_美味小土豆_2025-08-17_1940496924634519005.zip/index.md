---
title: 170的帅男和185的丑男，要怎么选？
url: https://www.zhihu.com/question/409540183/answer/1940496924634519005
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-17 19:35
modified: 2025-08-17 19:37
upvote_num: 2
comment_num: 1
---

185的丑男都能和170的帅哥上一个秤了

身高就这么重要嘛……

![](./assets/v2-db612596bbb9b293c17616f02ad231b2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='816' height='1456'></svg>)

多说一句

185脸帅的，能加十分

185脸丑的，丑是翻倍的

