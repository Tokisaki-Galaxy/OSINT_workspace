---
title: 在跟一个朋友交谈时，称呼“你妈”被指没有礼貌，称呼“你母亲”又太过书面语，请问怎么称呼比较合适？
url: https://www.zhihu.com/question/664642745/answer/1963373259706852657
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-19 22:37
modified: 2025-10-19 22:37
upvote_num: 3
comment_num: 0
---

"你亲爱的妈妈"

人家妈妈呀，嘴甜一点别人又不会反感的。

