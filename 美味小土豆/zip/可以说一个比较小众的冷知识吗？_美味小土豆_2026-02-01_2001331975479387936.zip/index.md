---
title: 可以说一个比较小众的冷知识吗？
url: https://www.zhihu.com/question/784489052/answer/2001331975479387936
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-02-01 16:32
modified: 2026-02-01 16:32
upvote_num: 318
comment_num: 15
---

私立医院是可以带未成年去打胎的，谁签字都行。

不不不，不是你们想得那样的。

