---
title: 为什么中国男性的审美会偏向脸部小的女性，可脸小明明不能带来生存优势，有没有科学合理的解释？
url: https://www.zhihu.com/question/663537236/answer/1949256292519617951
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-10 23:41
modified: 2025-09-10 23:41
upvote_num: 6
comment_num: 1
---

![](./assets/v2-b56838edaa3578cb40f90d707b7f702d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1200'></svg>)

  


![](./assets/v2-59035bd79a5560816415e3008862761e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='640'></svg>)

只要是男人应该能懂吧？

