---
title: 戒色的人到底在戒什么？
url: https://www.zhihu.com/question/1932755049685186235/answer/1949932595912634471
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 20:29
modified: 2025-09-12 20:29
upvote_num: 6
comment_num: 0
---

我也不知道在戒什么

我觉得只有在应该射地方尽情射空才叫戒色

