---
title: 以我现在的实力，能找到怎么样的女朋友？
url: https://www.zhihu.com/question/1982479192223421396/answer/1988195338499166707
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-27 10:31
modified: 2025-12-27 10:31
upvote_num: 6
comment_num: 0
---

抱歉，可能有点失礼。

看到你的条件我第一个想到的就是推上这个家伙。

![](./assets/v2-83f286353245f73850c956635c1c5e75_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1198' height='1608'></svg>)

你可以去参考一下他,就能知道自己大概可以找到怎样的姑娘了。

他的帖子下面回复都是这个画风的hhhh

![](./assets/v2-d31b83afffb0cd1ba6532fe6b7793467_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1195' height='1144'></svg>)

