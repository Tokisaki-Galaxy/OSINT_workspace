---
title: 男朋友给我的备注是高达的角色“琪琪•安达鲁西亚”，这是什么意思？
url: https://www.zhihu.com/question/567997977/answer/1936133944975270719
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-05 18:38
modified: 2025-08-05 18:38
upvote_num: 3
comment_num: 0
---

你查查他的车叫杰刚还是柯西

