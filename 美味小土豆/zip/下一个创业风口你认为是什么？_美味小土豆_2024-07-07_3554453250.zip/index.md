---
title: 下一个创业风口你认为是什么？
url: https://www.zhihu.com/question/439115196/answer/3554453250
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-07 19:32
modified: 2024-07-07 19:32
upvote_num: 6
comment_num: 1
---

男女对立

琢磨一下有什么是男的喜欢但是以前没那么多钱消费的

8090后情怀

这波人现在也有钱了，如果不恋爱不结婚，你可以卖情怀给他们。

