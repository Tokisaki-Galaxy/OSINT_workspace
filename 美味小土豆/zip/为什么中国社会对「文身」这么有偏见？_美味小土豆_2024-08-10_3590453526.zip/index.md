---
title: 为什么中国社会对「文身」这么有偏见？
url: https://www.zhihu.com/question/401632519/answer/3590453526
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-10 23:30
modified: 2024-08-10 23:30
upvote_num: 1
comment_num: 0
---

我对纹身没有偏见，我认为纹身是彰显个性的符号，很酷

但是我和老板说招人绝对不要招有纹身的人，他也深以为然。

我不歧视有纹身的人，有纹身很棒的，酷！

