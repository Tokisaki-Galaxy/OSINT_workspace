---
title: 为什么有的渣男这么多女朋友？
url: https://www.zhihu.com/question/579891394/answer/3614907528
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-09-03 22:56
modified: 2024-09-03 22:56
upvote_num: 16
comment_num: 0
---

当你真的能证明自己很渣——比如说女生控诉你的小作文，比如你自己拍的和女生的床照视频，比如你谈到带妹子去哪里吃喝玩乐的时候如数家珍的话……

就真的会有女生因为好奇你是个什么样子的人而约你出来见面的……

