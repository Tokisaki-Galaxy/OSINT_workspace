---
title: 一个男的救了一个女孩的生命，女孩决定把自己的家产给他表达感激之情，这样做好吗?
url: https://www.zhihu.com/question/1949302338050295512/answer/1949833099643971253
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-12 13:53
modified: 2025-09-12 13:53
upvote_num: 6
comment_num: 0
---

那也太恶心了

你的第一次是什么很重要的东西吗？

救你一条命你就这么恶心人?！

快滚快滚!

