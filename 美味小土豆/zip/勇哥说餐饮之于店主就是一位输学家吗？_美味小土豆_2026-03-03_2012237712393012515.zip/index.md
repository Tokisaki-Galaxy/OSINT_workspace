---
title: 勇哥说餐饮之于店主就是一位输学家吗？
url: https://www.zhihu.com/question/1979495207323051520/answer/2012237712393012515
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2026-03-03 18:47
modified: 2026-03-03 18:47
upvote_num: 1455
comment_num: 474
---

勇哥真的太喜欢猪脚饭包打一切了。

这招在三线小城市可能确实还挺管用的。

但是最近看到一期，他劝一家在静安寺cp开台式卤肉饭的店家改做猪脚饭……

静安cp长这样：

![](./assets/v2-6d8c161c4ab47fb3b91e9b3395ebd37b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1199' height='1588'></svg>)

  


![](./assets/v2-20520f2172f0833951f18a2d81a58464_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1198' height='1600'></svg>)

他讲这句话的时候我又惊讶又不意外。

不意外的地方是他确实一直这样给意见，只要这个地方有客流，他就一定会劝别人"做刚需，做猪脚饭，做粉面"，老打法了。

惊讶的则是，他这次居然没有问"你们本地有没有人吃这个？"。

——讲真我在静安寺玩了二十多年，从来没在商场里看到过有做猪脚饭的。上海白领中午也几乎不会去吃猪脚饭。

静安寺附近最近的猪脚饭也要在1.7公里以外

![](./assets/v2-263dcbde68e1b1a3cddd01c9b49a6ab2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

这期连评论都在和他说"在静安寺开猪脚饭没人吃的"

![](./assets/v2-e81c208877b2a4e0d4d6f0ec517b7536_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='2652'></svg>)

而且猪脚饭的成本和售价也没有比台湾卤肉饭便宜多少。我本来以为他会和连线的老板分析他的店租太贵了（4.5万一个月），品类太杂（他韩式台式都有）。

结果他居然推荐做猪脚饭。这个槽点真的太大了，因为我都能想象的出来如果这期的老板真的在静安寺cp开了一家猪脚饭店，他会怎么批评对方。

讲真我真的好好奇他有多喜欢猪脚饭……

