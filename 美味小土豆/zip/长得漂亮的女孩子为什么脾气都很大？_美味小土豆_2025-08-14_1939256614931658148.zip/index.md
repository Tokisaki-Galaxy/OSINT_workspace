---
title: 长得漂亮的女孩子为什么脾气都很大？
url: https://www.zhihu.com/question/297793472/answer/1939256614931658148
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-14 09:26
modified: 2025-08-14 09:26
upvote_num: 2
comment_num: 0
---

漂亮女生很有礼貌是真的。她们会很得体的拒绝别人

脾气大真不觉得，也有可能是我的身边朋友定律导致我的信息茧房。

女生长得好看的都不太愿意得罪人，反而有点容易被欺负。

