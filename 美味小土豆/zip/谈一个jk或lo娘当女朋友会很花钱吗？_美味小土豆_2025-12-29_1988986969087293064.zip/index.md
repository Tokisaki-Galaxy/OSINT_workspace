---
title: 谈一个jk或lo娘当女朋友会很花钱吗？
url: https://www.zhihu.com/question/477929788/answer/1988986969087293064
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-29 14:57
modified: 2025-12-29 14:57
upvote_num: 22
comment_num: 5
---

jk一般不怎么花钱的，因为平时要上课，周末出来玩最多也就奶茶家庭餐厅甜品店和电影院还有酒店。

平时买一堆小零食就已经很开心了。

如果玩cosplay的话倒是开销会高一些，毕竟c服＋妆娘+门票+酒店化妆，两三千总是要的。

不过这种活动一年也不会有几次。

所以这些开销她们完全能负担得起的。

等等……你问的是jk吧？

