---
title: cos约妆在外面要怎么办?
url: https://www.zhihu.com/question/1889421444322133252/answer/1957029469060571208
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-02 10:29
modified: 2025-10-02 10:29
upvote_num: 5
comment_num: 0
---

出cosplay就是很麻烦呀

漫展约妆也是在换好衣服在场外等妆娘画好妆再进场的

如果你要在户外活动，那确实只有穿好了出门或者放在包里在就近的商场换好衣服这两个选择了。

