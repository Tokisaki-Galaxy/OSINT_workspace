---
title: 和一个人睡的次数多了 会爱上对方嘛?
url: https://www.zhihu.com/question/388186290/answer/1947329736884847468
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-05 16:06
modified: 2025-09-05 16:06
upvote_num: 167
comment_num: 33
---

不一定，也有可能会很讨厌对方

比如什么姿势都试完了以后，突然发现原来她也没那么可爱，还很烦。

所以大部分炮友关系都很难坚持两个星期。

