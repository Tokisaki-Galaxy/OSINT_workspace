---
title: 最近看到一句“人终究会被年少不可得之物困扰一生”  你是怎么理解这句话的？
url: https://www.zhihu.com/question/53282970/answer/1955223180827427024
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-27 10:52
modified: 2025-09-27 11:06
upvote_num: 8
comment_num: 3
---

我会很执着的让交往过的每一个女生cos一部很老的轻百合战斗动画里的女主，然后把脸埋在她的胸口喊她姐姐。

——年少时我真的很想要一个像舞衣一样的姐姐。

  


![](./assets/v2-f662ba0a1c2ce3e09180b8acacd411ae_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1200'></svg>)

