---
title: 如果你作为一个富甲一方的商人，在极端反魔物的国度里偷偷开魔物娼馆，被官府发现后要怎么推脱？
url: https://www.zhihu.com/question/662533837/answer/3592042560
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-12 16:16
modified: 2024-08-12 16:17
upvote_num: 6
comment_num: 1
---

嘶，你都能让魔物听命于你了，居然只想着让她们当娼妇，啊？魔王大人？！

玩够了就快回来吧！别在人类世界赚那堆没意义的金币了，邪神大人她已经很生气了……

