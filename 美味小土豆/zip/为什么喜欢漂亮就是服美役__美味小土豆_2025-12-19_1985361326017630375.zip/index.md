---
title: 为什么喜欢漂亮就是服美役?
url: https://www.zhihu.com/question/588971014/answer/1985361326017630375
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-19 14:50
modified: 2025-12-19 14:50
upvote_num: 27
comment_num: 1
---

"只要长得漂亮身材好，都不会拒绝展示自己的美，不会拒绝让自己变得更漂亮，不会讨厌别人的夸奖"。

因为这个道理太简单太难反驳了，所以只能在概念上批臭它。

