---
title: 中国为什么执着于任何产业都国产替代？
url: https://www.zhihu.com/question/1898561030344410133/answer/1907450549491709904
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-05-18 15:00
modified: 2025-05-18 15:00
upvote_num: 2
comment_num: 0
---

有个事情很奇怪

就是你一旦会一个技术，你再出去询报价，总能找到很便宜而且质量不错的。

我不知道原因，但真的就是这样。

