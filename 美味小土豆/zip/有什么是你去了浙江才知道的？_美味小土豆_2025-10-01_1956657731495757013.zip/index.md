---
title: 有什么是你去了浙江才知道的？
url: https://www.zhihu.com/question/540446479/answer/1956657731495757013
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-01 09:52
modified: 2025-10-01 09:52
upvote_num: 12
comment_num: 3
---

浙江警察平等的对每一个人态度都很好。

这点上海警察都做不到。

