---
title: ai绘画出来好几个月了，有画师因此失业或少了单子吗？相关行业有感受到带来的所谓冲击吗？
url: https://www.zhihu.com/question/564781450/answer/3561898336
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-07-14 21:58
modified: 2024-07-14 21:58
upvote_num: 5
comment_num: 1
---

ai连福利姬都卷不死，不要说画手了。

