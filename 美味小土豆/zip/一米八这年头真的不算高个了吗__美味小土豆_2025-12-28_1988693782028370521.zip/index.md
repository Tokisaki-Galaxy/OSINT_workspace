---
title: 一米八这年头真的不算高个了吗?
url: https://www.zhihu.com/question/1904235233890505654/answer/1988693782028370521
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-12-28 19:32
modified: 2025-12-28 19:32
upvote_num: 5
comment_num: 0
---

在我看起来，1米7到1米8都差不多高，都是能看到头顶的身高。

但是1米6的女生就会和我说"才没有好嘛！1米7和1米8的差距很明显的好吧！"

