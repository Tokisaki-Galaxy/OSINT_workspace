---
title: 为什么杂鱼这个词在日本很有攻击力？
url: https://www.zhihu.com/question/1926745246135484700/answer/1937904344235238922
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-10 15:53
modified: 2025-08-10 15:53
upvote_num: 7
comment_num: 1
---

"连Gal里的选项都不敢存档的废物，以为这样本小姐会穿着女仆装给你喂巧克力嘛~呜哇——恶心死了~臭肥猪，杂鱼处男，腐烂的宅臭都要溢出次元壁了啦 

呐~如果你现在立刻跪下来舔我的小皮鞋，再用颤抖的声音说一百遍，尊贵的小恶魔大人请收下我廉价如同垃圾一样的杂鱼童贞，本小姐就勉强今天晚上的垃圾回收时间赏·给·你哦~"

![](./assets/v2-a8011885fcfa3df3e436968b6c719299_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1543' height='2048'></svg>)

你说的是这种攻击力吗？

