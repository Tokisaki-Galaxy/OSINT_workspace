---
title: 我国以14周岁作为性同意年龄是否太低了?
url: https://www.zhihu.com/question/387091440/answer/1959204214342411553
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-08 10:31
modified: 2025-10-08 10:31
upvote_num: 6
comment_num: 1
---

反正我十五岁的时候感觉十四岁的姑娘思考问题好成熟。

她们不仅知道要买套套还知道应该吃哪种药。

