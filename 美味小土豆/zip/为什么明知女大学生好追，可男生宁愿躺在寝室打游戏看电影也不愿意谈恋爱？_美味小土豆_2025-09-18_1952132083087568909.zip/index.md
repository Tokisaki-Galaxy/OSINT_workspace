---
title: 为什么明知女大学生好追，可男生宁愿躺在寝室打游戏看电影也不愿意谈恋爱？
url: https://www.zhihu.com/question/486632294/answer/1952132083087568909
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-18 22:09
modified: 2025-09-18 22:09
upvote_num: 57
comment_num: 6
---

不说追了

我高中沉迷怪物猎人的时候，放n个女生的鸽子被她们找到我家楼下我都不为所动

——她们既不想看我秀太刀打雷狼龙，还要大热天的拉我出门逛街。

谁愿意啊！！

