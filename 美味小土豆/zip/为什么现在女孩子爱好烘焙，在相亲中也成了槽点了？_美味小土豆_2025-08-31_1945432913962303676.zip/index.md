---
title: 为什么现在女孩子爱好烘焙，在相亲中也成了槽点了？
url: https://www.zhihu.com/question/318773505/answer/1945432913962303676
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 10:29
modified: 2025-08-31 10:29
upvote_num: 73
comment_num: 1
---

男人相亲要是说"喜欢拼模型"，"喜欢笔涂sd高达"，"喜欢圣地巡礼"，"喜欢看live"

估计要被吐槽的飞起了

