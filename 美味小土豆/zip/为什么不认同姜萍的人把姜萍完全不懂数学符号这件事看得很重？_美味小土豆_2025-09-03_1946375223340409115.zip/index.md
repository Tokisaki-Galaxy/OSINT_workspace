---
title: 为什么不认同姜萍的人把姜萍完全不懂数学符号这件事看得很重？
url: https://www.zhihu.com/question/1900114236622999562/answer/1946375223340409115
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-09-03 00:53
modified: 2025-09-03 00:53
upvote_num: 5
comment_num: 14
---

一个粉了uc高达20年的姨姥绝对不会把下面这个东西叫v高达

![](./assets/v2-f6ea2537c352b352c651dd2ad80bd178_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2048' height='3072'></svg>)

