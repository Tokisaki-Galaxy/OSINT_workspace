---
title: 如何看待38岁男子外称“红姐”假扮女性约会一千多名男性事件？
url: https://www.zhihu.com/question/1924503796328927255/answer/1940781133810889636
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-18 14:24
modified: 2025-08-18 14:24
upvote_num: 0
comment_num: 0
---

我一个男的是真的无法理解……

他们的审美也太恐怖了吧？!

