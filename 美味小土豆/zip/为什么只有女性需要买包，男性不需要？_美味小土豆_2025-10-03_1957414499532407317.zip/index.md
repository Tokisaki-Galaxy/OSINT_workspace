---
title: 为什么只有女性需要买包，男性不需要？
url: https://www.zhihu.com/question/1957257906266304898/answer/1957414499532407317
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-10-03 11:59
modified: 2025-10-03 11:59
upvote_num: 16
comment_num: 2
---

我妈送过我一个万宝龙的邮筒包，装零碎小东西很方便的。

有了它就再也不需要从裤子口袋里东掏西掏了，出门拎起来就走。

建议男人都买个小包，轻便实用还不会像背大包那样看起看像驮工。

