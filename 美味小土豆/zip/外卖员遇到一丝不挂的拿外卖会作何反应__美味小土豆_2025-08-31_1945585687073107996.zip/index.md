---
title: 外卖员遇到一丝不挂的拿外卖会作何反应?
url: https://www.zhihu.com/question/1944448947289584257/answer/1945585687073107996
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-31 20:36
modified: 2025-08-31 22:34
upvote_num: 8
comment_num: 2
---

会淡定的离开

我和n个coser妹子试过在酒店里的时候她穿各种衣服拿外卖。

露背毛衣

超小比基尼女仆装

低胸兔女郎装

只有胸贴的逆兔

奶盖旗袍

外卖员看到了都会迅速的离开。有些甚至会低着头把外卖迅速放下然后快速走掉。

有些妹子真的特别热衷于做这件事情……说这样会上瘾。

![](./assets/v2-1034e9da76c390c6167f99400b7f4168_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='821' height='1200'></svg>)

