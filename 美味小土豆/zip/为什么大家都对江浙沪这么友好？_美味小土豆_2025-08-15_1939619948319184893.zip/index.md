---
title: 为什么大家都对江浙沪这么友好？
url: https://www.zhihu.com/question/405447637/answer/1939619948319184893
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-15 09:30
modified: 2025-08-15 09:30
upvote_num: 0
comment_num: 1
---

谁不喜欢能随便骂的全国人民的小婊子呢~

