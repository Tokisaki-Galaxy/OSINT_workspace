---
title: 爸妈养我20多年，3.8w的彩礼真的多吗？
url: https://www.zhihu.com/question/2002442592093230903/answer/2007716276827621269
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 上海
created: 2026-02-19 07:21
modified: 2026-02-19 07:21
upvote_num: 17
comment_num: 4
---

你爸妈养育了你20年，是希望你能健康成长，追求自己的梦想和幸福。

而不是成天想着把自己贱卖给一个你不爱的男人的。

你成天想着当廉价妓女，你爸妈会伤心的

