---
title: DeepSeek从年初的“国运级”到现在的热度减退，到底哪里出问题了？
url: https://www.zhihu.com/question/1934555313303950224/answer/1938119460855711038
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-08-11 06:08
modified: 2025-08-11 06:08
upvote_num: 57
comment_num: 4
---

我是在deepseek最火的时候下载了用的

我问它rx78的光束步枪的功率，结果它硬生生给我生造了一个型号，直接编了一段说明。

而且它甚至不知道加岛勇是谁，硬编造了一个虚构的苍蓝命运三号机的机师。

它甚至否认有rgm79f这个型号，说这个不是官方的设定，应该是某些同人作品。

我就知道这玩意是有问题的

