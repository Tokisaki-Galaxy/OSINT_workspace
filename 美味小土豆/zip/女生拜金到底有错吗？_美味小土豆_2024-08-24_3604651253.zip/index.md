---
title: 女生拜金到底有错吗？
url: https://www.zhihu.com/question/446963182/answer/3604651253
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2024-08-24 15:24
modified: 2024-08-24 15:24
upvote_num: 9
comment_num: 0
---

我觉得单纯拜金的女性没什么不好的。拿多少钱办多少事。

最要命的还是只想要钱，还拼命pua的：这是对你的考验，我是慢热型，看你的表现咯，你送我礼物不代表我接受你的感情等等

真的，哪怕一个妹子在你有钱的时候对你嘘寒问暖在你落魄的时候扭头就走，都好过以上种种pua。

