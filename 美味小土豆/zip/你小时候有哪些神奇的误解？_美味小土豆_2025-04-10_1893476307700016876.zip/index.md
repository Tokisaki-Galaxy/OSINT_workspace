---
title: 你小时候有哪些神奇的误解？
url: https://www.zhihu.com/question/20484952/answer/1893476307700016876
author: 美味小土豆
author_badge: 兄弟们我真不是牛郎啊啊啊
location: 浙江
created: 2025-04-10 01:32
modified: 2025-04-10 01:32
upvote_num: 0
comment_num: 0
---

近视以后会变异，会长出四个眼睛来……

