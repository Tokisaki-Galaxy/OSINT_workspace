---
title: 走夜路被一只黄鼠狼拦住问话时，你该如何脱身？
url: https://www.zhihu.com/question/440965402/answer/2563159230
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 四川
created: 2022-07-07 16:33
modified: 2023-01-21 18:37
upvote_num: 3854
comment_num: 57
---

![](./assets/v2-b2e920823f9d823a4c77f9f07583a17c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='720' height='1121'></svg>)

