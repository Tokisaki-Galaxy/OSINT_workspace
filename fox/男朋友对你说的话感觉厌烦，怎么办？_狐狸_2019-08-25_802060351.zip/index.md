---
title: 男朋友对你说的话感觉厌烦，怎么办？
url: https://www.zhihu.com/question/337155793/answer/802060351
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-08-25 16:51
modified: 2019-08-25 16:51
upvote_num: 27
comment_num: 1
---

![](./assets/v2-ed975f385400d43a3e5aa9c4c34de4e1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='748' height='718'></svg>)

