---
title: 明日方舟攒了4发十连，是应该去抽小绵羊，还是等小火龙？
url: https://www.zhihu.com/question/369989804/answer/1001035416
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-02-06 11:56
modified: 2020-02-06 22:35
upvote_num: 12
comment_num: 4
---

谢谢各位，问题已经解决了。

![](./assets/v2-7e872ab07c4e8515b209e30812224e87_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

那就是一发十连给小羊，另外三发继续等小火龙

应大佬们的要求，我放一下我目前的阵容图

![](./assets/v2-5074d6e2c4577df09a6771a3af490aec_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

