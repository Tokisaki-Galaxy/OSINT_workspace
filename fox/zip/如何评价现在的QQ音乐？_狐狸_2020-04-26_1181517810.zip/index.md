---
title: 如何评价现在的QQ音乐？
url: https://www.zhihu.com/question/318885195/answer/1181517810
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-04-26 16:51
modified: 2020-04-26 16:53
upvote_num: 59
comment_num: 2
---

无产阶级的歌被资本家收费，就很离谱

![](./assets/v2-f97536fb579c7471ac45c477b9db82d2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='2280'></svg>)

  


![](./assets/v2-d6110f47f4ad986e620a05490bfe894d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='2280'></svg>)

