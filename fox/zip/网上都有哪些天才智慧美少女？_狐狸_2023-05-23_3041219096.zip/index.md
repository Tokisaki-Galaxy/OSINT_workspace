---
title: 网上都有哪些天才智慧美少女？
url: https://www.zhihu.com/question/528590644/answer/3041219096
author: 狐狸
author_badge: 获得点赞超过28万
location: 四川
created: 2023-05-23 18:33
modified: 2023-05-23 18:36
upvote_num: 775
comment_num: 125
---

我。

  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


  


![](./assets/v2-18e8e23ede8d4768c3447e640b335d39_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='454' height='457'></svg>)

