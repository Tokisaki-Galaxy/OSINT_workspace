---
title: 这像是哥哥和妹妹的对话吗?
url: https://www.zhihu.com/question/342387511/answer/808198028
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-08-30 17:34
modified: 2019-08-30 17:34
upvote_num: 29
comment_num: 1
---

白天哥哥妹妹，晚上死鬼宝贝。

