---
title: 曹操的能力在帝王中能排前十吗?
url: https://www.zhihu.com/question/346864380/answer/936390869
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-12-15 13:34
modified: 2020-04-20 17:37
upvote_num: 73
comment_num: 8
---

曹操通过曹丕分享的二维码加入了群聊。

* * *

看来是没什么人懂这个梗了。

