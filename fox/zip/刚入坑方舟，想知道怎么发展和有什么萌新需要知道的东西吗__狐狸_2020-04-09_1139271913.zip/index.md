---
title: 刚入坑方舟，想知道怎么发展和有什么萌新需要知道的东西吗?
url: https://www.zhihu.com/question/379428548/answer/1139271913
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-04-09 08:28
modified: 2020-04-09 08:28
upvote_num: 8
comment_num: 2
---

没什么需要了解的，玩着玩着就都知道了。

有六星就无脑练，都是有用的。

有时候抽不到想要的别灰心，该有的总会有的。

