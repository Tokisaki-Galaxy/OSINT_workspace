---
title: 为什么美国感染百万我感受不到大家悲伤？
url: https://www.zhihu.com/question/391302885/answer/1245169806
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-05-25 18:28
modified: 2020-05-25 18:30
upvote_num: 25
comment_num: 3
---

5月23日，美国各地的海滩开放了。

大家在沙滩上晒着日光浴，在海中游泳、冲浪，甚至还有人在沙滩上烧烤野餐。

截止至当天，确诊人数已经高达168万，并且以每日2万的速度稳定增加着。

![](./assets/v2-1ff1b10352d2588b873adb95a7280733_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='459'></svg>)

  


![](./assets/v2-10faadedce99a05678bbbb90bf628db6_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='467'></svg>)

  


![](./assets/v2-44d9fe276ef462179a9e1c9995a8c083_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='446'></svg>)

人家自己都不悲伤，您又来劲了？

