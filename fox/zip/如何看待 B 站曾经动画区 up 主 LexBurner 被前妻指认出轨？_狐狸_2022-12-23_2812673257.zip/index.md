---
title: 如何看待 B 站曾经动画区 up 主 LexBurner 被前妻指认出轨？
url: https://www.zhihu.com/question/573117382/answer/2812673257
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 四川
created: 2022-12-23 10:02
modified: 2022-12-24 21:09
upvote_num: 402
comment_num: 16
---

什么叫魔幻现实？

男人在台上大哭，

他的皮套肆无忌惮地狂笑，

奔四的大叔跟一群十三四岁的小女孩哭诉求安慰，

女孩们一边给大叔打钱，一边直呼“哥哥别哭”。

这次直播里：

雷某收割了小女孩们的同情和金钱，

前妻收割了雷某三千万的婚内财产，

叔叔收割了雷某两千万的秽土转生费，

小女孩们收获了与“哥哥”共渡难关的满足感和幸福感，

我等乐子人收获了快乐。

我们都有美好的未来。

* * *

又刷到雷某的视频，蚌埠住了

![](./assets/v2-7b00745e032b8a59f6b5dc303f736440_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2376' height='1080'></svg>)

  


![](./assets/v2-3822919aba49d4cdbf048fb0e9f744db_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2376' height='1080'></svg>)

  


![](./assets/v2-4fb28de6500c2a56068b8efa0fd6dbe0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2376' height='1080'></svg>)

人在哭，皮在笑，钱在往下掉，什么地狱绘图

