---
title: 如何看踹伤猥亵男男生被解除刑拘，案件提级由市公安局重新调查？
url: https://www.zhihu.com/question/417588740/answer/1434836805
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-08-26 15:54
modified: 2020-08-26 16:07
upvote_num: 62
comment_num: 4
---

“爸，我出事了！”

“出什么事了，乖儿子？”

“我性骚扰妇女被抓了!”

“嗨，这是赚钱的好事啊，讲得这么吓人，搞得我还以为你见义勇为了呢。”

