---
title: 你认为你见过的最霸气的图片是哪张？
url: https://www.zhihu.com/question/342848648/answer/1413401036
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-08-16 23:09
modified: 2020-09-22 10:24
upvote_num: 844
comment_num: 23
---

![](./assets/v2-94c31a9bb6d7c100c9e609144c0fdeea_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='496' height='773'></svg>)

中间这位应该是班长，严肃的表情中透着难以掩盖的自豪。

旁边两位很耐人寻味，两个小伙子一个斜靠着枪，一个好像在走神，仿佛在说:

“啊？不就随随便便端掉印度一个炮兵营吗，有什么大不了的？拍完没有啊，我还赶着吃饭呢？”

举手投足间就不经意地流露出强者特有的那种淡定与从容，与印度强行鼓起勇气嘤嘤狂吠的滑稽模样形成鲜明对比。

* * *

  


![](./assets/v2-7b2ff81498c74beef85b5864e23a1149_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2000' height='1328'></svg>)

俄罗斯驻土耳其大使遇刺，普京出席葬礼。

普京的表情，悲伤中蕴含着极致的愤怒，在座的所有人都畏畏缩缩地打量着他，那恐惧的表情好像在看一座即将爆发的火山。

全程没有一句话，但山雨欲来的压迫感让人窒息。

如果第三次世界大战真的爆发了，这张照片毫无疑问会被选入教科书。

