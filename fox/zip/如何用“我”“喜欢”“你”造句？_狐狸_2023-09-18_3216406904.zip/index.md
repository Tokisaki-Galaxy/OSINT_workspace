---
title: 如何用“我”“喜欢”“你”造句？
url: https://www.zhihu.com/question/618556158/answer/3216406904
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 四川
created: 2023-09-18 16:20
modified: 2023-09-18 16:22
upvote_num: 13839
comment_num: 556
---

没有必要弯弯绕绕，这个世界的大多数人都很缺爱，

所以我就直说了：

  


  


**我喜欢你。**

  


  


  


  


  


  


  


![](./assets/v2-273164633bdb37382290355e5cb022f0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='700' height='700'></svg>)

