---
title: 有什么事是你小时候不懂年轻时敢说老了不想说的事？
url: https://www.zhihu.com/question/354594049/answer/888324249
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-11-09 23:04
modified: 2019-11-09 23:04
upvote_num: 18
comment_num: 2
---

“那个皇帝身上明明什么衣服都没穿，为什么大家都在赞美他的衣服呢？”

