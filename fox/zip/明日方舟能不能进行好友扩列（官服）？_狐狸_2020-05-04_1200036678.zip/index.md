---
title: 明日方舟能不能进行好友扩列（官服）？
url: https://www.zhihu.com/question/340287544/answer/1200036678
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-05-04 21:12
modified: 2020-10-03 22:03
upvote_num: 16
comment_num: 10
---

B服，艾谢尔，请多指教。

常用的几个干员练度都比较高，除了傀影，技能都是专三。如果需要我更换的话，在评论区留言就好。

![](./assets/v2-a066b1a5db7cca19d72c0b387751505b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-b6c5096c820ae51866f00653940b95d5_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-aab8e19da7ffee41847984159c374b25_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

