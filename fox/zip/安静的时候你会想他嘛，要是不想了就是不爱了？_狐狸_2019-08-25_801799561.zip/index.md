---
title: 安静的时候你会想他嘛，要是不想了就是不爱了？
url: https://www.zhihu.com/question/342055857/answer/801799561
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-08-25 12:35
modified: 2019-08-25 12:35
upvote_num: 25
comment_num: 3
---

![](./assets/v2-ed975f385400d43a3e5aa9c4c34de4e1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='748' height='718'></svg>)

