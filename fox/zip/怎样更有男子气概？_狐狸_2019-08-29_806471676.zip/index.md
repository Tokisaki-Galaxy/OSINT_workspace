---
title: 怎样更有男子气概？
url: https://www.zhihu.com/question/343077808/answer/806471676
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-08-29 09:32
modified: 2019-08-29 09:32
upvote_num: 24
comment_num: 1
---

健身，这个才是最快的选择。

