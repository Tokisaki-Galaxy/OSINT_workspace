---
title: 动脉的具体位置越具体越好？
url: https://www.zhihu.com/question/68669256/answer/854203802
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-10-12 09:59
modified: 2019-10-12 09:59
upvote_num: 26
comment_num: 4
---

小可爱，你的动脉被我藏起来了哦，找不到哒。

你笑一下我就还给你哟(●'◡'●)ﾉ❤

