---
title: 为什么承太郎发动时停的时候会喊：“砸挖撸多”？
url: https://www.zhihu.com/question/393661460/answer/1214009334
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-05-10 21:29
modified: 2020-05-13 12:31
upvote_num: 2692
comment_num: 72
---

承太郎：“食堂泼辣酱！”

白金之星：“啊？叫我干嘛？”

承太郎：“砸瓦鲁多！”

白金之星：“哦哦，好的。”

* * *

毕竟白金之星的功能太多了，画素描、接子弹、赶论文、当望远镜、欧拉欧拉，你如果只是叫他名字，人家不知道你想让他干什么。

就像你妈平时在家里使唤你一样，

“XXX!去洗衣服！”

“XXX!去把碗洗了！”

“XXX!下楼顺便把垃圾带上！”

“白金之星！世界！”

  


![](./assets/v2-ab18d0e133b462e07d07ba1010072643_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='500' height='544'></svg>)实锤了，大乔=白金之星

