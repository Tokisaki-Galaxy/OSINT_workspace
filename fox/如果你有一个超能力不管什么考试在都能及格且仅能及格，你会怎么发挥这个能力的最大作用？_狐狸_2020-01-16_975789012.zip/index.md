---
title: 如果你有一个超能力不管什么考试在都能及格且仅能及格，你会怎么发挥这个能力的最大作用？
url: https://www.zhihu.com/question/365574368/answer/975789012
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-01-16 12:57
modified: 2020-01-16 12:57
upvote_num: 18
comment_num: 1
---

以后国家专门给你设一个考试局，只负责为你安排考试。

一张卷子就两道题，一道60分，一道40分。

