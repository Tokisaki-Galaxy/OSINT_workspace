---
title: 为什么动漫里大都是冷兵器作战？
url: https://www.zhihu.com/question/354125581/answer/912843737
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-11-27 19:27
modified: 2019-11-27 19:27
upvote_num: 7
comment_num: 2
---

隔着上千米，该怎么打嘴炮拖时间？

