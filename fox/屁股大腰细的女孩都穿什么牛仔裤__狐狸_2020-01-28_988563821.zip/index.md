---
title: 屁股大腰细的女孩都穿什么牛仔裤?
url: https://www.zhihu.com/question/356413579/answer/988563821
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-01-28 21:29
modified: 2020-01-28 21:29
upvote_num: 16
comment_num: 1
---

这个鱼钩有点太直了（狗头）

