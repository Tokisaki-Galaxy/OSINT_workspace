---
title: 喜欢一个女生，可是她有男朋友了，如何挖墙脚?
url: https://www.zhihu.com/question/392835863/answer/1224670065
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-05-15 17:28
modified: 2020-05-15 17:45
upvote_num: 34
comment_num: 14
---

有男朋友的女生，你只有一个竞争对手；

没有男朋友的女生，你有无数个竞争对手。

那么答案已经显而易见了

少年，你还在等什么？

  


(小声逼逼几句：前提是你和她男朋友互不认识，不然就等死吧(°ー°〃),)

