---
title: 怎么看待在烈士陵园门前嬉笑打闹放风筝的行为？
url: https://www.zhihu.com/question/386917670/answer/1232689823
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-05-19 15:53
modified: 2020-05-19 15:53
upvote_num: 87
comment_num: 4
---

烈士们大概会会心一笑吧，他们献出生命，就是为了看孩子们的笑脸啊。

