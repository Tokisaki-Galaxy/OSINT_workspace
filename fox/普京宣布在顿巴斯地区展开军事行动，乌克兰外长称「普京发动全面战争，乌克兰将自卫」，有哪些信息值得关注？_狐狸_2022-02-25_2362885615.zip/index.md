---
title: 普京宣布在顿巴斯地区展开军事行动，乌克兰外长称「普京发动全面战争，乌克兰将自卫」，有哪些信息值得关注？
url: https://www.zhihu.com/question/518414164/answer/2362885615
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2022-02-25 08:05
modified: 2022-02-25 08:15
upvote_num: 76
comment_num: 3
---

![](./assets/v2-4b6616026c31e59baee426b02b936cfb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2000' height='1328'></svg>)

俄罗斯驻外大使遇刺，普京出席葬礼。

普京的表情，悲伤中蕴含着极致的愤怒，在座的所有人都畏畏缩缩地打量着他，那恐惧的表情好像在看一座即将爆发的火山。

全程没有一句话，但山雨欲来的压迫感让人窒息。

这张照片将来或许会被选入历史教科书。

