---
title: 有哪些令人悲痛的文学/动漫/影视作品中的人物的死？
url: https://www.zhihu.com/question/61932912/answer/1449202420
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-09-02 13:53
modified: 2020-09-02 13:58
upvote_num: 40
comment_num: 3
---

严肃向作品里，为了把剧情推向最高峰，像“团长”一类的精神领袖基本上是难逃一死，

团长终有一死，不过有的团长之死重于泰山:

![](./assets/v2-20a023aee1451d31d33d8c24659eb757_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-87b412f31b2029f4a55bf5b430c8d2b1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-5575c235d188a3afbeb56024f64c2d7b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-7de4409b95ac59c9c234cb79560654d0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

  


![](./assets/v2-5ebf42862ee868d3c9b6e5bd640d7f8b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2280' height='1080'></svg>)

**“把死亡的意义托付给下一个生者，这是我们对抗这个残酷世界的唯一手段！！！”**

  


有的团长之死则轻于鸿毛:

  


  


  


![](./assets/v2-38e5cf91162b11dd48823ca0838d9116_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='554' height='312'></svg>)呃…啊啊啊啊！！！！

  


![](./assets/v2-f7e01e37cf4606e3f54b9892496c9df0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='554' height='312'></svg>)团长，你在干什么啊？？！团长！！

  


![](./assets/v2-9ee0917d3c52968b90a7127a15451c29_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='200' height='133'></svg>)不要停下来啊！！

