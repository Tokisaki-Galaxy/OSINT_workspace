---
title: 如果艾滋病在古代被发现会发生什么？
url: https://www.zhihu.com/question/351217347/answer/943762544
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2019-12-20 19:08
modified: 2019-12-20 19:08
upvote_num: 20
comment_num: 11
---

卧槽，现在一想，古代某些妇女“克夫克子”，不就是艾滋病吗？

