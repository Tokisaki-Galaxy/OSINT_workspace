---
title: 如何看待美国明尼苏达州明尼阿波利斯因警察压死黑人发生暴乱？
url: https://www.zhihu.com/question/397995405/answer/1258853077
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-06-01 19:59
modified: 2020-06-01 20:04
upvote_num: 11
comment_num: 4
---

![](./assets/v2-911caa449c549e7c1c0a7ebc5e8040f5_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='718' height='1863'></svg>)

堡垒最容易从内部攻破，说不定明天就解放白宫了呢？(狗头)

愤怒的黑人们唱着国际歌，手中高举马列毛的著作冲入白宫解放美国，正道的光撒在了大地上。

