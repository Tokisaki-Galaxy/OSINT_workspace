---
title: 杀狐狸会遭报应吗？
url: https://www.zhihu.com/question/415684178/answer/2837644275
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 四川
created: 2023-01-09 23:33
modified: 2023-01-09 23:33
upvote_num: 117
comment_num: 18
---

不知为何，这问题看得我心头一颤

![](./assets/v2-1f9155bf094082a3fb6439c8bff456fe_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='766' height='962'></svg>)

