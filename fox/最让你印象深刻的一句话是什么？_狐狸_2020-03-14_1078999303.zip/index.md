---
title: 最让你印象深刻的一句话是什么？
url: https://www.zhihu.com/question/50701799/answer/1078999303
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-03-14 21:52
modified: 2020-03-14 21:53
upvote_num: 48
comment_num: 8
---

“要让一群人团结起来，需要的不是英明的领导，而是共同的敌人”

