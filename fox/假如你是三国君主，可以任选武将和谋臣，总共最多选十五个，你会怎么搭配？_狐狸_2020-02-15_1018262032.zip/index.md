---
title: 假如你是三国君主，可以任选武将和谋臣，总共最多选十五个，你会怎么搭配？
url: https://www.zhihu.com/question/371205299/answer/1018262032
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-02-15 21:46
modified: 2020-02-15 21:46
upvote_num: 13
comment_num: 3
---

我有丞相董卓，副丞相曹操，大将军袁绍，义子吕布，猛将潘凤、刘三刀，守营大将淳于琼，心腹许攸，可一统天下否？

