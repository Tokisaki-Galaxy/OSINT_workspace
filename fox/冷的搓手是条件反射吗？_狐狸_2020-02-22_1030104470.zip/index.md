---
title: 冷的搓手是条件反射吗？
url: https://www.zhihu.com/question/373575602/answer/1030104470
author: 狐狸
author_badge: 我们被我们塑造的东西所塑造着。
location: 未知
created: 2020-02-22 03:05
modified: 2020-02-22 03:05
upvote_num: 10
comment_num: 1
---

当然不是。我们在感到冷的时候，是有意识地去控制自己的手搓起来，而不是下意识地就开始搓手。

"望梅止渴"就是一个典型的条件反射，看到梅子就止不住地流口水，"流口水"这一举动显然是下意识中就完成的，而不是人为控制的结果。

