---
title: 你发现过另一半的哪些秘密？
url: https://www.zhihu.com/question/1906668508625991191/answer/1948336423783633774
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-08 10:46
modified: 2025-09-08 10:46
upvote_num: 54
comment_num: 10
---

我发现，

我左边一半是有心脏的，

而右边一半没有。

所以，

把我从中间劈开，

左边的血会喷出来，

右边不会。

![](./assets/v2-f8a9de984bde118a8c2c141c9df5e39f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1260' height='1840'></svg>)

