---
title: 10月1号实行的K字签证，对普通人有什么影响？
url: https://www.zhihu.com/question/1955778144209473651/answer/1956356709405664606
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-30 13:56
modified: 2025-09-30 13:56
upvote_num: 31
comment_num: 7
---
**汉土从此无一寸，天地何处是家乡……** 