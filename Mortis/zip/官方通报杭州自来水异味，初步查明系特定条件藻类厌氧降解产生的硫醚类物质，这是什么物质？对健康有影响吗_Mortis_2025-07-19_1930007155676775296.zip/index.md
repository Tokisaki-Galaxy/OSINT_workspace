---
title: 官方通报杭州自来水异味，初步查明系特定条件藻类厌氧降解产生的硫醚类物质，这是什么物质？对健康有影响吗？
url: https://www.zhihu.com/question/1929927890734145793/answer/1930007155676775296
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-19 20:52
modified: 2025-07-19 20:52
upvote_num: 100
comment_num: 10
---

![](./assets/v2-b0730a09ddf7f7afecfcb835a59bbd2c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='864' height='540'></svg>)

