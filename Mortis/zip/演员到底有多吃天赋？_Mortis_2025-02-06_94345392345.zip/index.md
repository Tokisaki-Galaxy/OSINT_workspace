---
title: 演员到底有多吃天赋？
url: https://www.zhihu.com/question/443350396/answer/94345392345
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-06 19:43
modified: 2025-02-06 19:43
upvote_num: 7
comment_num: 2
---

不知道

[@Amoris](https://www.zhihu.com/people/1f7cd4d906a6f530111ebf9cf4c2d6b0)

