---
title: 为什么很多西方语言会出现阴性、阳性这种属性?
url: https://www.zhihu.com/question/653896029/answer/1921891131723087903
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-27 11:22
modified: 2025-06-27 11:22
upvote_num: 2
comment_num: 0
---

阴阳是ZHMZ的伟大发明。邪恶的西方通过偷窃**《永乐大典》** 将此据为己有，还恬不知耻地大量使用。

