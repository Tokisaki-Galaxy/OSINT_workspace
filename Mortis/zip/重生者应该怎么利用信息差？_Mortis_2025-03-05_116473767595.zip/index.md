---
title: 重生者应该怎么利用信息差？
url: https://www.zhihu.com/question/660532433/answer/116473767595
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-05 00:14
modified: 2025-03-05 00:14
upvote_num: 3
comment_num: 0
---

在妹妹刚出生的时候，说服爸爸妈妈给她取名高松灯。

![](./assets/v2-01fe3379adfe0348212e576ff04651b4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='998' height='998'></svg>)

