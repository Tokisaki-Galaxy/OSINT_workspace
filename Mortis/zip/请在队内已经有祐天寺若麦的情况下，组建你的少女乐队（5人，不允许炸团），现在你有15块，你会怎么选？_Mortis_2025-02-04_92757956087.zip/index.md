---
title: 请在队内已经有祐天寺若麦的情况下，组建你的少女乐队（5人，不允许炸团），现在你有15块，你会怎么选？
url: https://www.zhihu.com/question/11194705701/answer/92757956087
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-04 20:12
modified: 2025-02-04 20:15
upvote_num: 105
comment_num: 10
---

全买安和昴，整16个鼓手给我捶捶背。

* * *

为啥东京阿诺比我贵这么多？

