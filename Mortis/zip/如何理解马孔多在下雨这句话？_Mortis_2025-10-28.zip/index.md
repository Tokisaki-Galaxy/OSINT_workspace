---
title: 如何理解马孔多在下雨这句话？
url: https://www.zhihu.com/question/38193780/answer/1966565719064937031
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-28 18:03
modified: 2025-10-28 18:03
upvote_num: 4319
comment_num: 169
---
陈胜：“大泽乡在下雨。”

军官：“下雨？下雨也算时间哦！”

![](./assets/v2-58f2227ea3ea00c37b602d1f0421aa5f_720w.jpg)