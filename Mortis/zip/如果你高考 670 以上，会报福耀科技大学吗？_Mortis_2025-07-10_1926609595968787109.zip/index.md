---
title: 如果你高考 670 以上，会报福耀科技大学吗？
url: https://www.zhihu.com/question/1924146399940961896/answer/1926609595968787109
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-10 11:52
modified: 2025-07-10 11:52
upvote_num: 411
comment_num: 18
---

去组少女乐队也比上这个👆学校强啊。

![](./assets/v2-811b9b039bfbf668cc435e1083ed2eb2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='828' height='986'></svg>)

