---
title: 历史上有没有人是只有功没有过的？
url: https://www.zhihu.com/question/1903443808064091582/answer/1907951318527616949
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-20 00:10
modified: 2025-05-20 00:10
upvote_num: 16
comment_num: 0
---

若叶睦是只有功没有过的，因为好事算她的，坏事算我的。

![](./assets/v2-f24d1de3917341ee7350f717719d66be_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1088'></svg>)

