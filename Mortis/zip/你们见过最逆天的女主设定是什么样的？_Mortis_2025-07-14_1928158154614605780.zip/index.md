---
title: 你们见过最逆天的女主设定是什么样的？
url: https://www.zhihu.com/question/62832998/answer/1928158154614605780
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-14 18:25
modified: 2025-07-14 18:25
upvote_num: 11
comment_num: 1
---

和自己小姨谈恋爱。

![](./assets/v2-3a35b626c20df5aa564125da180688ff_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1216' height='832'></svg>)

