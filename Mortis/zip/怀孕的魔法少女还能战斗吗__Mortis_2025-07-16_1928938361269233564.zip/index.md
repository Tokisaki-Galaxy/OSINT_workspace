---
title: 怀孕的魔法少女还能战斗吗?
url: https://www.zhihu.com/question/641874950/answer/1928938361269233564
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-16 22:05
modified: 2025-07-16 22:05
upvote_num: 69
comment_num: 1
---

多年以后，面对行为越来越像她的**父亲们** 的Mortis，**丰川祥子** 总会想起自己向丘比许愿还清老登168亿债务的那个下午。

![](./assets/v2-032aaa41b496bd975434f9e95fd4c5fb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2105' height='1200'></svg>)

  


![](./assets/v2-64bd1a907cd71285f4572bb519dfc439_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2079' height='1200'></svg>)

  


![](./assets/v2-906673f97cab92e5ecb855282b4059f3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2095' height='1200'></svg>)

  


![](./assets/v2-3f2307328bc3ba13f194b262e667bf68_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2119' height='1200'></svg>)

  


![](./assets/v2-9bff61819e4f36545ef3726bf51b8ba2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='960' height='657'></svg>)

  


![](./assets/v2-654794691820229f994a93407b02c047_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1216' height='832'></svg>)

