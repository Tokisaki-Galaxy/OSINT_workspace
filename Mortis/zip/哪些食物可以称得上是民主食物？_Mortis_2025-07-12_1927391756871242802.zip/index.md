---
title: 哪些食物可以称得上是民主食物？
url: https://www.zhihu.com/question/1925658527558501665/answer/1927391756871242802
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-12 15:40
modified: 2025-07-12 15:40
upvote_num: 1988
comment_num: 82
---

![](./assets/v2-b408be49b0a33cc161de012af07336d9_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='852' height='861'></svg>)

