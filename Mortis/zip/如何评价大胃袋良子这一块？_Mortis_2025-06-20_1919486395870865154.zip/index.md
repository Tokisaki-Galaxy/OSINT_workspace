---
title: 如何评价大胃袋良子这一块？
url: https://www.zhihu.com/question/7272414588/answer/1919486395870865154
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-20 20:06
modified: 2025-06-20 20:06
upvote_num: 3616
comment_num: 88
---

良子什么时候去拍**《热辣滚烫2》** 啊？

