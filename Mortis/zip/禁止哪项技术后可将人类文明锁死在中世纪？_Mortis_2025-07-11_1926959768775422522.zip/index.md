---
title: 禁止哪项技术后可将人类文明锁死在中世纪？
url: https://www.zhihu.com/question/642683269/answer/1926959768775422522
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-11 11:03
modified: 2025-07-11 11:03
upvote_num: 2
comment_num: 0
---

投票

