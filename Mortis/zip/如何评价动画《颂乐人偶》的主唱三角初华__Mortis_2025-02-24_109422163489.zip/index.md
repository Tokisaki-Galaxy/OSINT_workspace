---
title: 如何评价动画《颂乐人偶》的主唱三角初华?
url: https://www.zhihu.com/question/13238425864/answer/109422163489
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-24 21:53
modified: 2025-02-24 21:53
upvote_num: 10
comment_num: 2
---

拜托了初华，拯救那个没有被邦多欺骗的我吧……

![](./assets/v2-8e1129a19b6c413213b498e97c055248_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1920' height='1080'></svg>)

