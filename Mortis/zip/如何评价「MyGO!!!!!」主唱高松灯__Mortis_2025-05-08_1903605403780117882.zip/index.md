---
title: 如何评价「MyGO!!!!!」主唱高松灯?
url: https://www.zhihu.com/question/10197799678/answer/1903605403780117882
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-08 00:21
modified: 2025-05-08 00:21
upvote_num: 37
comment_num: 3
---

人们很早就发现，除了R^4外，其他欧氏空间的微分结构是唯一的；后来，经过Freedman和Donaldson的工作，人们知道R^4上甚至有不可数多个不同的微分结构。

![](./assets/v2-a75bd32314731768b748eae84b805d3b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='996' height='998'></svg>)

