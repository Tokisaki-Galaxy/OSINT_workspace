---
title: 和尚自称老衲，道士自称贫道，上班族应该自称什么？
url: https://www.zhihu.com/question/1905784537872577712/answer/1929824872315466905
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-19 08:48
modified: 2025-07-19 08:48
upvote_num: 9
comment_num: 1
---

同志

![](./assets/v2-e616f6036a55db9f0669429a98885c08_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2292' height='3168'></svg>)

