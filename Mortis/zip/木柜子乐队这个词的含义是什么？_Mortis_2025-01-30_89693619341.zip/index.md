---
title: 木柜子乐队这个词的含义是什么？
url: https://www.zhihu.com/question/9131860308/answer/89693619341
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-01-30 20:53
modified: 2025-01-30 20:57
upvote_num: 8
comment_num: 1
---

苦来兮苦是个木柜子，里头的人想出去，外头的人想进来。

出柜的人可以大声说我爱你，但是远去；进来的人只是默默地，并且满足。

