---
title: 如何以「一觉醒来，我变成了野生动物，而我的种群面临灭绝」为开头，写一个故事？
url: https://www.zhihu.com/question/1955996087174279789/answer/1960058170492825899
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-10 19:04
modified: 2025-10-10 19:05
upvote_num: 21
comment_num: 3
---

一觉醒来，我变成了野生动物，而我的种群面临灭绝。

我翻了个身，继续睡觉。

![](./assets/v2-b327d451ba7378b1f114a488e4843391_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='667'></svg>)

