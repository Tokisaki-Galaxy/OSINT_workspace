---
title: 如果给历史上的罪人排个名，你觉得谁能排第一？?
url: https://www.zhihu.com/question/1900955528416461364/answer/1913346113488004835
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-03 21:27
modified: 2025-06-03 21:27
upvote_num: 6
comment_num: 3
---

最邪恶的人是高松灯，原因如图（封印转载）。

![](./assets/v2-4f7fa3e03164651080b66ad29ee31c27_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1018' height='16362'></svg>)

