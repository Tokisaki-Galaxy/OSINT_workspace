---
title: 女生衣着覆盖率 30% 真的不适合去公共场合吗？
url: https://www.zhihu.com/question/638777886/answer/1926442004490982341
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-10 00:46
modified: 2025-07-10 00:46
upvote_num: 8
comment_num: 3
---

我决定只在有理数坐标点上穿衣服：

这样，我身上任何一点的任何开邻域都不是完全裸露的；同时，所穿衣服的勒贝格测度为零。

![](./assets/v2-d6b32ad0047b7e16f4108e5892c3cda0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='960' height='1280'></svg>)

