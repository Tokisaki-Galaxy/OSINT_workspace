---
title: 多少钱能解决你现在的烦恼呢？？
url: https://www.zhihu.com/question/661082100/answer/1950660865494852058
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-14 20:43
modified: 2025-09-14 20:43
upvote_num: 243
comment_num: 20
---

5000元，已经超过15天了，知乎什么时候把奖金发给我？

![](./assets/v2-a17ac681baa3bc618a10558bd39a0182_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1125' height='1500'></svg>)

  


![](./assets/v2-a89401e680f2eb1336672ec6b0921b49_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='562'></svg>)

[@知乎人文](https://www.zhihu.com/people/0eebc9b425a88e87408729eec9f09be4)

