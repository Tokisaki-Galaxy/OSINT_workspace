---
title: 《哪吒之魔童闹海》 8 月 2 日全网上线，你看了吗？
url: https://www.zhihu.com/question/1934284362930677081/answer/1937129422584021352
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-08 12:34
modified: 2025-08-08 12:34
upvote_num: 55
comment_num: 7
---

还写了观后感。

![](./assets/v2-28d7c8e0831a996e54b963a52b9c567c_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='12769'></svg>)

