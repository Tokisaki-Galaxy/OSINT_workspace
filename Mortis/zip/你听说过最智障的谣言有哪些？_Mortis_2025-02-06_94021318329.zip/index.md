---
title: 你听说过最智障的谣言有哪些？
url: https://www.zhihu.com/question/265721641/answer/94021318329
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-06 12:41
modified: 2025-02-06 12:41
upvote_num: 2
comment_num: 1
---

高中某学长厌恶数学。一日突发奇想，认为只要坚持在做数学题时自慰，就会建立“数学→高潮”的条件反射。后考取某985数学专业。

这个谣言的智障之处在于：根据本人采访，该学长对数学一直是热爱的，他只是单纯喜欢自慰而已。

