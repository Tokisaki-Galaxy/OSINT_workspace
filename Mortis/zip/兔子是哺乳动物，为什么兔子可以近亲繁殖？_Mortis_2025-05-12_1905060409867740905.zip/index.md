---
title: 兔子是哺乳动物，为什么兔子可以近亲繁殖？
url: https://www.zhihu.com/question/1903786776876777538/answer/1905060409867740905
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-12 00:43
modified: 2025-05-12 00:43
upvote_num: 3
comment_num: 1
---

祥子也是哺乳动物，凭什么她就能和小姨繁殖？

![](./assets/v2-4ac5eaf21f5209459098d3cb9f4127cf_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='740' height='1100'></svg>)

## +

![](./assets/v2-31d87e14fb32df27976d2e0a5f709765_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='474' height='638'></svg>)

## =

![](./assets/v2-3f3022ec6cca4043a817d171612d3344_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1100' height='1593'></svg>)

