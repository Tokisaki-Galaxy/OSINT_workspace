---
title: 即将举办演唱会，贝斯、吉他和主唱却被另一个乐队的成员干扰怎么办?
url: https://www.zhihu.com/question/12694438938/answer/104857200662
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-19 12:54
modified: 2025-02-19 12:54
upvote_num: 1
comment_num: 1
---

![](./assets/v2-868c9829d747aa6c0edcf37767cdb355_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1839'></svg>)

为什么要举报？

