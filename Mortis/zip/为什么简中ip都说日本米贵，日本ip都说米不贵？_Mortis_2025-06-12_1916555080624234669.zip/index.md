---
title: 为什么简中ip都说日本米贵，日本ip都说米不贵？
url: https://www.zhihu.com/question/1914385730291110340/answer/1916555080624234669
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-12 17:58
modified: 2025-06-12 17:58
upvote_num: 0
comment_num: 0
---

V我50（人民币）叫爸爸。

