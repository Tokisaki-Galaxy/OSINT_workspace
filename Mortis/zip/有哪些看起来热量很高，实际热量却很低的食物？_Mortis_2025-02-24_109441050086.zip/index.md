---
title: 有哪些看起来热量很高，实际热量却很低的食物？
url: https://www.zhihu.com/question/359675190/answer/109441050086
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-24 22:18
modified: 2025-02-24 22:18
upvote_num: 11
comment_num: 7
---

抹茶芭菲，猫天天炫也不胖。

