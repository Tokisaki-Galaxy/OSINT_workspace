---
title: 都说全女模式不行，那么请问有没有全女模式能行的案例？
url: https://www.zhihu.com/question/1910720347642258525/answer/1916647622204199104
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-13 00:06
modified: 2025-06-13 00:06
upvote_num: 33
comment_num: 7
---

![](./assets/v2-70496d04c88c39309b10d1536772edb8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='800' height='800'></svg>)

  


![](./assets/v2-8324bea38892e80bc4c525bded0738fb_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1274' height='777'></svg>)

  


![](./assets/v2-49b9d571be384366ef13a6aa69257b93_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='474' height='284'></svg>)

