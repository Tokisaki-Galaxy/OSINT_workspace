---
title: 如何评价傅首尔长相？
url: https://www.zhihu.com/question/1899043245226435150/answer/1908559243524707046
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-21 16:26
modified: 2025-05-21 16:26
upvote_num: 204
comment_num: 3
---

这是傅东京

![](./assets/v2-9a65382ce84777f06510421ec24d1a13_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1196' height='1197'></svg>)

anon酱，love!

