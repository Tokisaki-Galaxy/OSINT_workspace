---
title: 我是mortis墨缇丝，如何让小睦不那么惦记着祥子酱？
url: https://www.zhihu.com/question/11599379067/answer/96900859661
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-09 23:53
modified: 2025-02-09 23:53
upvote_num: 9
comment_num: 2
---

我正在努力分裂出一个白祥人格，睦可以和她一起在后台组一被子乐队。

