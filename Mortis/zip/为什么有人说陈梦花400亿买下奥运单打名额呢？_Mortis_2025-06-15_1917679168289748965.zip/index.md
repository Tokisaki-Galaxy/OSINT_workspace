---
title: 为什么有人说陈梦花400亿买下奥运单打名额呢？
url: https://www.zhihu.com/question/1916057938289750625/answer/1917679168289748965
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-15 20:25
modified: 2025-06-15 20:25
upvote_num: 0
comment_num: 0
---

400亿是开的发票。

