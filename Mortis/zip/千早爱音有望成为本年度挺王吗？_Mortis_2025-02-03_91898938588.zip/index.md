---
title: 千早爱音有望成为本年度挺王吗？
url: https://www.zhihu.com/question/11129601756/answer/91898938588
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-03 13:56
modified: 2025-02-03 13:56
upvote_num: 40
comment_num: 1
---

Anon酱可能成为本年度挺王，但Anon酱成为本年度挺王不太可能。如果你问我谁最有可能成为本年度挺王，我还是觉得抹茶的芭菲最好吃！

