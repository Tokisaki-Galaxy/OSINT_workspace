---
title: 什么样的父母能把孩子逼疯？
url: https://www.zhihu.com/question/322280218/answer/109903022354
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-25 13:05
modified: 2025-02-25 13:05
upvote_num: 0
comment_num: 0
---

![](./assets/v2-44d0e63d432987c566d06f4c867a5a6e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='490' height='490'></svg>)

