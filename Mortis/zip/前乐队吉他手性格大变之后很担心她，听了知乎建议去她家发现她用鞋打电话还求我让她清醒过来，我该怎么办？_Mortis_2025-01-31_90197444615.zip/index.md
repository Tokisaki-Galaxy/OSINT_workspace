---
title: 前乐队吉他手性格大变之后很担心她，听了知乎建议去她家发现她用鞋打电话还求我让她清醒过来，我该怎么办？
url: https://www.zhihu.com/question/10921722580/answer/90197444615
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-01-31 18:30
modified: 2025-01-31 18:31
upvote_num: 5
comment_num: 1
---

我打电话的时候保姆一直嘀咕什么“这孩子拿个鞋……”之类的。这分明就是电话，她一派胡言!

瞧，精神医生这不就过来了吗？

