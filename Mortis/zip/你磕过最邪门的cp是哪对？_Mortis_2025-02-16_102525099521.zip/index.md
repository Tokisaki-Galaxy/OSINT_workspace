---
title: 你磕过最邪门的cp是哪对？
url: https://www.zhihu.com/question/567023983/answer/102525099521
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-16 20:24
modified: 2025-02-16 20:24
upvote_num: 1
comment_num: 0
---

艾跃进和孔文革

![](./assets/v2-326d227761b5c8977843140c5ffda181_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1124' height='873'></svg>)

  


![](./assets/v2-dfaab51b1ee0ae98d6e373a6f1eb6b85_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='368' height='232'></svg>)

