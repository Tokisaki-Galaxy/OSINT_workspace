---
title: 如何看待新华社知乎账号注销?
url: https://www.zhihu.com/question/1943131155579774666/answer/1943432094601707749
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-25 21:58
modified: 2025-08-25 21:58
upvote_num: 58
comment_num: 4
---

![](./assets/v2-26c4f36da8d04b1c182850dc9e9c6ca6_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1908' height='1200'></svg>)

