---
title: 解函数方程f^2(x)+f^2(y)=f(x+y)f(x-y)+1?
url: https://www.zhihu.com/question/1917943407977961282/answer/1918001395287695927
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-16 17:46
modified: 2025-06-16 17:46
upvote_num: 0
comment_num: 0
---

对x求导，对y求导，令x=y.

得f(x)=cosx

