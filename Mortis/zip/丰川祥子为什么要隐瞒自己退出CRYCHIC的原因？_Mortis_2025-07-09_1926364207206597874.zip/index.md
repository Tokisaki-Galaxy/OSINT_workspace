---
title: 丰川祥子为什么要隐瞒自己退出CRYCHIC的原因？
url: https://www.zhihu.com/question/653248640/answer/1926364207206597874
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-09 19:36
modified: 2025-07-09 19:37
upvote_num: 29
comment_num: 0
---

前边oblivious了，后边oblivious了。

总之，

## **钩子。**

![](./assets/v2-4f912dc8d5b9b5c8bac676d782033ade_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1073' height='1087'></svg>)

## 

