---
title: 因为这个表情包，被女朋友误解我把她当成鸡，要跟我分手，怎么办？
url: https://www.zhihu.com/question/659625163/answer/2008902089204582123
author: Mortis
author_badge: saki，联通
location: 日本
created: 2026-02-22 13:53
modified: 2026-02-22 13:53
upvote_num: 24
comment_num: 1
---
她有点忙，等回复了我再更新吧。

![](./assets/v2-35deaddb727979c8f698d2552ca0f5fd_720w.jpg)