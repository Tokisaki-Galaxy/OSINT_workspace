---
title: 如何在外形不使用猫耳猫尾元素，行为不猫叫，不做猫的动作的情况下，设计一个人人都看得出来的猫娘角色?
url: https://www.zhihu.com/question/1914116085403346284/answer/1928103979017036675
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-14 14:50
modified: 2025-07-14 14:50
upvote_num: 27
comment_num: 4
---

想吃麦当劳……

