---
title: 如果丰川祥子和骆驼祥子互换身体穿越会发生什么?
url: https://www.zhihu.com/question/14887148821/answer/124045409334
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-14 11:25
modified: 2025-03-14 11:25
upvote_num: 2
comment_num: 0
---

初华，我想和你困觉……

