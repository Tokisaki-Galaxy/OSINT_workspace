---
title: 哪些动漫哪些瞬间让你最意难平?
url: https://www.zhihu.com/question/623475431/answer/94332690006
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-06 19:21
modified: 2025-02-06 19:21
upvote_num: 12
comment_num: 0
---

《宝石之国》中磷叶石发誓要为硫化汞找到“有趣且非她不可”的工作。

在磷叶石决定去月球时，她对硫化汞说：“我找到只有你才能胜任的工作了。”

“那有趣呢？”硫化汞说。

