---
title: 乒超联赛，樊振东与王楚钦早晚要碰，能预测他们的比赛结果吗？
url: https://www.zhihu.com/question/1915729538257777818/answer/1916269182007370198
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-11 23:02
modified: 2025-06-11 23:02
upvote_num: 10
comment_num: 0
---

![](./assets/v2-316306802a9c3cac10fa85d45e78ea9f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='670'></svg>)

