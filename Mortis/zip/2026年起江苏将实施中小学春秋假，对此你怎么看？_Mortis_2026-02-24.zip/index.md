---
title: 2026年起江苏将实施中小学春秋假，对此你怎么看？
url: https://www.zhihu.com/question/2002046679709394067/answer/2009722062353212659
author: Mortis
author_badge: saki，联通
location: 日本
created: 2026-02-24 20:11
modified: 2026-02-24 20:11
upvote_num: 2648
comment_num: 74
---
鹰击长空，鱼翔浅底，万类霜天竞自由。

![](./assets/v2-0fb05c33da29be4ba0a588bf57a89700_720w.jpg)