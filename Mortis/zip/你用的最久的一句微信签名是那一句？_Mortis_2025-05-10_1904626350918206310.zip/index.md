---
title: 你用的最久的一句微信签名是那一句？
url: https://www.zhihu.com/question/627043652/answer/1904626350918206310
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-10 19:58
modified: 2025-05-10 19:58
upvote_num: 1
comment_num: 1
---

富强、文明、和谐、爱国、敬业、诚信、友善。

