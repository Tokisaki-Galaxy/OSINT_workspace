---
title: ave mujica能否在剩下三集里解决c团遗留问题，拉大喵回来，再开一场live?
url: https://www.zhihu.com/question/14008581523/answer/116670476231
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-05 09:56
modified: 2025-03-05 09:56
upvote_num: 1
comment_num: 0
---

大喵自古以来就是鸡团不可分割的一部分。至于大祥老师，我建议鸡狗两团，搁置争议，共同开发。

