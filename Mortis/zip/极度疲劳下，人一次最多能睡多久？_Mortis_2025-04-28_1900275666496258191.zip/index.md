---
title: 极度疲劳下，人一次最多能睡多久？
url: https://www.zhihu.com/question/459680751/answer/1900275666496258191
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-04-28 19:50
modified: 2025-04-28 19:50
upvote_num: 11
comment_num: 0
---

醒来之后发现什么都没有变。

