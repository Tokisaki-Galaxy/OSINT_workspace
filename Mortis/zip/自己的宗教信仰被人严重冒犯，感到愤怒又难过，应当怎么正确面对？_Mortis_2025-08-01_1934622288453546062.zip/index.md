---
title: 自己的宗教信仰被人严重冒犯，感到愤怒又难过，应当怎么正确面对？
url: https://www.zhihu.com/question/1934201650085619491/answer/1934622288453546062
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-01 14:31
modified: 2025-08-01 14:31
upvote_num: 135
comment_num: 2
---

![](./assets/v2-05d3f11aa5a2fb6a2d060c653a1bfd30_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2056' height='1200'></svg>)

