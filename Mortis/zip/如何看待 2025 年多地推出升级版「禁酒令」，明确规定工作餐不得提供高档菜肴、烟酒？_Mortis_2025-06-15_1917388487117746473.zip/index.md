---
title: 如何看待 2025 年多地推出升级版「禁酒令」，明确规定工作餐不得提供高档菜肴、烟酒？
url: https://www.zhihu.com/question/1915750650832184691/answer/1917388487117746473
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-15 01:10
modified: 2025-06-15 01:10
upvote_num: 0
comment_num: 0
---

以前犯了错误需要自罚三杯，现在不需要了。

