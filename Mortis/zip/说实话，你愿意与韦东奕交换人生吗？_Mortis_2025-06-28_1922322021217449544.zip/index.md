---
title: 说实话，你愿意与韦东奕交换人生吗？
url: https://www.zhihu.com/question/1921569210921889981/answer/1922322021217449544
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-28 15:54
modified: 2025-06-28 15:54
upvote_num: 2
comment_num: 1
---

不愿意，因为我不想让他过得这么痛苦。

