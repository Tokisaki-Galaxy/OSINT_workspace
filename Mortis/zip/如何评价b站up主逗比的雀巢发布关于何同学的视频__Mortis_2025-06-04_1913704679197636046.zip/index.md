---
title: 如何评价b站up主逗比的雀巢发布关于何同学的视频?
url: https://www.zhihu.com/question/1911845788901938248/answer/1913704679197636046
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-04 21:12
modified: 2025-06-04 21:12
upvote_num: 3
comment_num: 0
---

他们俩很熟吗？

![](./assets/v2-a242a40f7f954bc38dfdebd4b5d78fd0_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='609'></svg>)

