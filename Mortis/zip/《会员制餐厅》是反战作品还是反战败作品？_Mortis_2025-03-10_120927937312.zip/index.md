---
title: 《会员制餐厅》是反战作品还是反战败作品？
url: https://www.zhihu.com/question/14508811966/answer/120927937312
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-10 14:19
modified: 2025-03-10 14:19
upvote_num: 341
comment_num: 6
---

事少女乐队作品（迫真）

![](./assets/v2-9ee99521c40009cd77badb61cb0c001d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1180'></svg>)

