---
title: 如何看特朗普:哈佛很多学生连2+2都不会？
url: https://www.zhihu.com/question/1909616802855650853/answer/1910068096284197613
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-25 20:22
modified: 2025-05-26 13:09
upvote_num: 295
comment_num: 13
---

![\\sum_{}^{}{\\left\\{ \(2+2\)+“4+4" \\right\\}}=主](https://www.zhihu.com/equation?tex=%5Csum_%7B%7D%5E%7B%7D%7B%5Cleft%5C%7B+%282%2B2%29%2B%E2%80%9C4%2B4%22+%5Cright%5C%7D%7D%3D%E4%B8%BB)

![](./assets/v2-8fcd7f4bda3619df2df1a6fb35b2be94_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='559' height='517'></svg>)

