---
title: 如何评价纽约时报爆料马斯克吸毒膀胱病变？
url: https://www.zhihu.com/question/1912239882128040791/answer/1912958689054273733
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-02 19:48
modified: 2025-06-02 19:48
upvote_num: 0
comment_num: 0
---

马斯克孩子众多，膀胱想必因充分锻炼而紧致弹牙，而XD导致的病变有增添了奇妙的风味……

