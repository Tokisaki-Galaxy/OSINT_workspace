---
title: 如何评价RT今日俄罗斯发的微博“原神与斯大林”？
url: https://www.zhihu.com/question/1964694950001252176/answer/1965106628304016347
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-24 17:25
modified: 2025-10-24 17:25
upvote_num: 35
comment_num: 3
---

苏尔特洛奇一觉醒来，发现自己KPI掉榜二了。

![](./assets/v2-70a89340282fa96af3d21437fde1efd5_720w.gif)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1080' height='1080'></svg>)

