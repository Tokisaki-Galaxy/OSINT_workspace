---
title: 如何用「赤」「橙」「黄」「绿」「青」「蓝」「紫」造句？
url: https://www.zhihu.com/question/8026857316/answer/122070079402
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-11 21:42
modified: 2025-03-11 21:42
upvote_num: 5
comment_num: 2
---

我要赤金日橙的大蓝子，看绿金正日的黄漫，青金正恩挨紫弹。

