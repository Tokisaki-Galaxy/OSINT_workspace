---
title: 你觉得预言 7 月 5 日海啸是真的吗?
url: https://www.zhihu.com/question/1924172714349945147/answer/1924629538186438414
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-05 00:43
modified: 2025-07-05 00:43
upvote_num: 10
comment_num: 9
---

希望是真的，快点重开吧……

