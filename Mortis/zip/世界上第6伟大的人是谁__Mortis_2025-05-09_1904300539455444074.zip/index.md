---
title: 世界上第6伟大的人是谁?
url: https://www.zhihu.com/question/1897414190685206141/answer/1904300539455444074
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-09 22:23
modified: 2025-05-09 22:23
upvote_num: 455
comment_num: 25
---

## 第一伟大：柿本广大。

没有柿本广大，就没有ave mujica，天大地大没有soyo前置装甲大，爹亲娘亲没有band友情亲。

## 第二伟大：孔子

孔子是老二。

## 第三伟大：饺子

哪吒是老三。

## 第四伟大：董袭莹

十年种树，百年树人，四年成材

## 第五伟大：波尔布特

将马列主义与柬埔寨自然环境结合起来。

## 第主伟大：姜萍

> 主＝6

