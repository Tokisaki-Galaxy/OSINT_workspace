---
title: 有哪些高颜值的摇滚乐手？
url: https://www.zhihu.com/question/28918006/answer/1928533643116122526
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-15 19:17
modified: 2025-07-15 19:17
upvote_num: 21
comment_num: 5
---

![](./assets/v2-1e60cc245e49737fa67f7fc0f85fd906_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='640' height='640'></svg>)

