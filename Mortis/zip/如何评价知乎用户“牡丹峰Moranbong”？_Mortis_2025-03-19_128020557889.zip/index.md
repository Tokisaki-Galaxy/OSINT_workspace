---
title: 如何评价知乎用户“牡丹峰Moranbong”？
url: https://www.zhihu.com/question/15321206945/answer/128020557889
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-19 22:07
modified: 2025-03-19 22:07
upvote_num: 330
comment_num: 9
---

是我的一位留学瑞士的发小

![](./assets/v2-bf16e8c0f9e961ed77aab9d83973509f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='478' height='478'></svg>)

