---
title: 下辈子想当只鸟，大家有什么经验可以分享吗？
url: https://www.zhihu.com/question/602412614/answer/93988054822
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-06 11:57
modified: 2025-02-06 11:57
upvote_num: 6
comment_num: 1
---

当企鹅，捡石头。

