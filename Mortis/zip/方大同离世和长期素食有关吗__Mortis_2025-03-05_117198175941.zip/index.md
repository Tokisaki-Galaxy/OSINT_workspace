---
title: 方大同离世和长期素食有关吗?
url: https://www.zhihu.com/question/13805559267/answer/117198175941
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-05 19:47
modified: 2025-03-05 19:47
upvote_num: 24
comment_num: 1
---

没关系，我可以提供不在场证明。

![](./assets/v2-6718df919b95890564671b2f51411de1_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='674'></svg>)

斯人已逝，歌声永存。

