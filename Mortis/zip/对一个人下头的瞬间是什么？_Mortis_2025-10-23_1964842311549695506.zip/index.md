---
title: 对一个人下头的瞬间是什么？
url: https://www.zhihu.com/question/492860479/answer/1964842311549695506
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-23 23:55
modified: 2025-10-23 23:55
upvote_num: 2473
comment_num: 151
---

我发朋友圈说想养条狗，高中同学评论：

**汪汪汪**

![](./assets/v2-1d38af72559c69796f6f8c76e5cc48cd_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1184' height='1062'></svg>)

