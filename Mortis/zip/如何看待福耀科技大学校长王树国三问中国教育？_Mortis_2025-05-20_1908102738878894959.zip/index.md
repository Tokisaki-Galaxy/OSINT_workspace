---
title: 如何看待福耀科技大学校长王树国三问中国教育？
url: https://www.zhihu.com/question/1907236737752757749/answer/1908102738878894959
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-20 10:12
modified: 2025-05-20 10:12
upvote_num: 6
comment_num: 1
---

如果nina继续读高中，还有今天的トゲナシトゲアリ吗？

如果hina继续读高中，还有今天的Diamond Dust吗？

如果山田凉继续读大学，还有今天的结束乐队吗？

就此，**户山香澄** 感言，“真正的能力是在实战状态下**磨♀练♀** 出来的”，“没有一个人的能力是**调教** 出来的”，“他们真正的成长是在实践当中，是在**血与汗** 的挑战当中，自己磨练出来的。这是真的本事，这叫能力。能力不是书本上得来的；书本上得来的那叫知识，知识转化为能力是在实践当中。”

![](./assets/v2-be070336a930c4b893c8fc02ad806324_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1536' height='2048'></svg>)

