---
title: 爸爸拿我和“谷爱凌”比，我该怎么办？
url: https://www.zhihu.com/question/515444120/answer/1905210022134286219
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-12 10:37
modified: 2025-05-12 10:37
upvote_num: 4
comment_num: 1
---

拿令尊跟丰川定治比。

![](./assets/v2-ec8079b38f7673c15be9f49470693aa6_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1333' height='750'></svg>)

