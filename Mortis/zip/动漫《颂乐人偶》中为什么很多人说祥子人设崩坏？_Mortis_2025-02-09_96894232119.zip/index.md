---
title: 动漫《颂乐人偶》中为什么很多人说祥子人设崩坏？
url: https://www.zhihu.com/question/11016892626/answer/96894232119
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-09 23:42
modified: 2025-02-09 23:42
upvote_num: 7
comment_num: 1
---

saki，坏掉

