---
title: 在清华的时候李新野和梁植谁比较帅？
url: https://www.zhihu.com/question/1982185794287448874/answer/1982915797039994359
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-12-12 20:52
modified: 2025-12-12 20:52
upvote_num: 65
comment_num: 7
---
夜夜思君不见君，环球同此凉热。

![](./assets/v2-0da428a9794547bc55d00c23cc010f31_720w.jpg)