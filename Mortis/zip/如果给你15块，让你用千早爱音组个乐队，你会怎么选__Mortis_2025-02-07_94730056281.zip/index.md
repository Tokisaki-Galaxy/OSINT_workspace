---
title: 如果给你15块，让你用千早爱音组个乐队，你会怎么选?
url: https://www.zhihu.com/question/11419615072/answer/94730056281
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-07 10:28
modified: 2025-02-07 10:28
upvote_num: 241
comment_num: 15
---

Mortis型爱音和若叶睦型爱音杂交，后代Mortis型与若叶睦型比例近似为1：1；Mortis型爱音自交后代性状分离比是M:睦=3：1

故推测表演天赋与吉他天赋是由一对等位基因控制，前者为显性性状，后者为隐性性状。

实验产物由实验员自行处理。

