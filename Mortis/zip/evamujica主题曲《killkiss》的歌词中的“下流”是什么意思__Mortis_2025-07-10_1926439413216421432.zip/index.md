---
title: evamujica主题曲《killkiss》的歌词中的“下流”是什么意思?
url: https://www.zhihu.com/question/1926278709163299351/answer/1926439413216421432
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-10 00:35
modified: 2025-07-10 00:35
upvote_num: 3
comment_num: 0
---

祥子是大小姐生的，是个“上流”；

初音是女仆生的，是个“下流”。

![](./assets/v2-e8b9f2a8aa3a437d9ac894d7c1c2e6a4_720w.gif)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='327' height='300'></svg>)

