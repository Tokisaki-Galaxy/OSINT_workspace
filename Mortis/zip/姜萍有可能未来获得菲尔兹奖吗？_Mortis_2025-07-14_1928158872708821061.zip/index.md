---
title: 姜萍有可能未来获得菲尔兹奖吗？
url: https://www.zhihu.com/question/1920919838748041874/answer/1928158872708821061
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-14 18:28
modified: 2025-07-14 18:28
upvote_num: 5
comment_num: 1
---

可能的，且概率远大于葛立恒数分之一。

