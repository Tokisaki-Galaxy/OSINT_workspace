---
title: 什么叫演戏用力过猛？
url: https://www.zhihu.com/question/57953126/answer/120293890204
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-09 19:15
modified: 2025-03-09 19:17
upvote_num: 2
comment_num: 0
---

![](./assets/v2-2b434dabe35ad28f12e56c9bcf836929_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2127' height='1196'></svg>)

  


![](./assets/v2-40d7f32745a5a91d7e80c3e74f3d0675_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2127' height='1196'></svg>)

  


![](./assets/v2-65e96978f6918959b2d4010589c54d8f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='674'></svg>)

  


![](./assets/v2-c48d03d6b29997e9e8068656969ae903_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2127' height='1196'></svg>)

