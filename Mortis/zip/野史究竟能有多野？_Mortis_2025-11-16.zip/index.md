---
title: 野史究竟能有多野？
url: https://www.zhihu.com/question/434526052/answer/1973496930593169518
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-11-16 21:05
modified: 2025-11-16 21:05
upvote_num: 76
comment_num: 8
---
16世纪末的意大利歌唱家曾尝试在演出前用美少女的玉足扩张自己的喉咙，从而拓宽音域。

![](./assets/v2-cda1193006f51ec7d16c0cce99dc28bb_720w.jpg)