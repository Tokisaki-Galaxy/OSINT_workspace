---
title: 为什么不认同姜萍的人把姜萍完全不懂数学符号这件事看得很重？
url: https://www.zhihu.com/question/1900114236622999562/answer/1902504222643188801
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-04 23:25
modified: 2025-05-04 23:25
upvote_num: 4716
comment_num: 121
---

我这个C和弦，很厉害吧？

![](./assets/v2-a972cc7729922a62714cbeff9b38661f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='456' height='714'></svg>)

