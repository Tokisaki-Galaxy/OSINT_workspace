---
title: 如何以“一个正义的主角能做的最淫荡的事就是出现在邪恶反派的家门口，为开头写一个故事”?
url: https://www.zhihu.com/question/662017586/answer/105733218301
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-20 12:07
modified: 2025-02-20 12:07
upvote_num: 30
comment_num: 2
---

一个正义的主角能做的最淫荡的事就是出现在邪恶反派的家门口，浑身是血，遍体鳞伤，然后说：

“拜托了初华，让我忘掉一切吧。”

![](./assets/v2-3540602797a6f8fb78f157261b1bc33f_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='531' height='446'></svg>)

