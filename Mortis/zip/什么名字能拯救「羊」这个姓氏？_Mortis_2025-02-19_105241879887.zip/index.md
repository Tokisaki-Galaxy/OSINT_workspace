---
title: 什么名字能拯救「羊」这个姓氏？
url: https://www.zhihu.com/question/388449461/answer/105241879887
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-19 20:45
modified: 2025-02-19 20:45
upvote_num: 7
comment_num: 1
---

羊宫妃那

![](./assets/v2-01fe3379adfe0348212e576ff04651b4_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='998' height='998'></svg>)

