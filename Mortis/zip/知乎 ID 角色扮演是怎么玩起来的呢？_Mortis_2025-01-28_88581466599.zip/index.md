---
title: 知乎 ID 角色扮演是怎么玩起来的呢？
url: https://www.zhihu.com/question/10289042848/answer/88581466599
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-01-28 19:18
modified: 2025-01-28 19:18
upvote_num: 191
comment_num: 37
---

因为我啥本事也没有，

生活不幸福，

语言能力差，不玩梗不会说话，

孤僻，没有三次元朋友，但又不能忍受孤独，

于是只能假装纸片人，发表逆天言论，获得关注和安慰。

