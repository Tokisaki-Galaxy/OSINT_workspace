---
title: 《Ave Mujica》第七集长崎素世发出了长达十几秒的尬笑，她在笑什么？
url: https://www.zhihu.com/question/12191273251/answer/101037514072
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-14 19:39
modified: 2025-02-14 19:39
upvote_num: 3
comment_num: 0
---

川

