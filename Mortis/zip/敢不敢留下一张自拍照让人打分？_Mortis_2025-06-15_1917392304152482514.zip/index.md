---
title: 敢不敢留下一张自拍照让人打分？
url: https://www.zhihu.com/question/654927580/answer/1917392304152482514
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-15 01:25
modified: 2025-06-15 01:25
upvote_num: 77
comment_num: 4
---

睦子米，你漂亮吗？

![](./assets/v2-9c41eacd7385245db606dcbd77d224ce_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1711'></svg>)

睦头睦头漂亮漂亮

喵梦喵梦你拿着鼓棒

你说要芭菲，你说要瓜黄

我不能种也不能抢

我只有一张吱吱嘎嘎响的床

