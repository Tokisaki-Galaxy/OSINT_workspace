---
title: 斯奎奇大王（牢A）为什么那么多人信？
url: https://www.zhihu.com/question/1998700356796958130/answer/2008273220843893815
author: Mortis
author_badge: saki，联通
location: 日本
created: 2026-02-20 20:14
modified: 2026-02-20 20:14
upvote_num: 21
comment_num: 3
---
A圣与日本女友敦伦，鏖战昼夜，终得其道，喜极而泣，曰：**对上了，对上了！** 

![](./assets/v2-0fa50d5fd66cb5e084ee556c7bf67148_720w.jpg)