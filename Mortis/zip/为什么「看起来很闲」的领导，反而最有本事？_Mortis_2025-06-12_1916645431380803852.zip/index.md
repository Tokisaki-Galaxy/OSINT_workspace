---
title: 为什么「看起来很闲」的领导，反而最有本事？
url: https://www.zhihu.com/question/1889974658293547499/answer/1916645431380803852
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-12 23:58
modified: 2025-06-12 23:58
upvote_num: 9
comment_num: 0
---

你可以这样思考：

领导是不干活的，所以没有领导的生产效率是最高的。

“不存在领导”是一个理想模型，无法达到。

越“闲”的领导越接近理想模型，生产效率就越高。

