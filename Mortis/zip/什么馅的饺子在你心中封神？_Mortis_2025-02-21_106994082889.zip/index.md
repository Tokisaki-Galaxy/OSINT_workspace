---
title: 什么馅的饺子在你心中封神？
url: https://www.zhihu.com/question/631103201/answer/106994082889
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-21 19:56
modified: 2025-02-21 19:56
upvote_num: 3
comment_num: 0
---

不好看，睡了114514小时。 5毛一条把括号删了，时间随便填一个

