---
title: 佐仓杏子总是吃那么多，为什么没有变成一个胖子？
url: https://www.zhihu.com/question/1904499645977195268/answer/1928158314845407000
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-14 18:26
modified: 2025-07-14 18:26
upvote_num: 1
comment_num: 0
---

因为她还没来得及……

