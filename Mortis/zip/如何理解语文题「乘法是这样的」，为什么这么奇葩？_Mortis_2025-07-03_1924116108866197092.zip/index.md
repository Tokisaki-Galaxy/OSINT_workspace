---
title: 如何理解语文题「乘法是这样的」，为什么这么奇葩？
url: https://www.zhihu.com/question/1899581207672501628/answer/1924116108866197092
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-03 14:43
modified: 2025-07-03 14:43
upvote_num: 7
comment_num: 1
---

乘法是这样的：“少女乐队”乘以“人格分裂”，再乘以“丰川家的黑暗”，等于“ave mujica”，又等于“无法预测的命运舞台”，最后等于“屎💩”

![](./assets/v2-2bfe9333b3e62c23b436e8d777a42d94_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='864' height='540'></svg>)

