---
title: 如何评价知名女声优进藤天音出轨?
url: https://www.zhihu.com/question/1931532473860325495/answer/1932196349715125622
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-25 21:51
modified: 2025-07-25 21:51
upvote_num: 304
comment_num: 16
---

我没有要求你永远要求我，我不是我。

可是，意思是什么意思？你作为我的你怎么了？

现在才2025年吧？再这样下去，你42岁的时候42岁，84岁的时候84岁，168岁的时候168岁，336岁的时候336岁，672岁的时候672岁，很多年后，你就死了。

作为我的你的我，我可能得写一个布尔值：真的。

![](./assets/v2-f57f6f759588cd75bb91d38f9d60ab42_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1576' height='1080'></svg>)

