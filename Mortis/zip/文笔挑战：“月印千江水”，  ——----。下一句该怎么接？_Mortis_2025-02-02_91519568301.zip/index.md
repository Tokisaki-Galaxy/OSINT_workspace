---
title: 文笔挑战：“月印千江水”，  ——----。下一句该怎么接？
url: https://www.zhihu.com/question/661581608/answer/91519568301
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-02 22:01
modified: 2025-02-02 22:01
upvote_num: 5
comment_num: 0
---

日穿邦多利

![](./assets/v2-b3822de28908d8f486b20b7128210ce8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2081' height='1200'></svg>)

