---
title: 如何看待网络热梗“我是 xx 的狗”，是一种自轻自贱吗？
url: https://www.zhihu.com/question/1916519384924553495/answer/1917268737733661663
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-14 17:14
modified: 2025-06-14 17:14
upvote_num: 1103
comment_num: 31
---

横眉冷对千夫指，俯首甘为saki狗🐶

![](./assets/v2-a7e6d0ded5de6d2c93c2726806d0c863_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='700' height='658'></svg>)

