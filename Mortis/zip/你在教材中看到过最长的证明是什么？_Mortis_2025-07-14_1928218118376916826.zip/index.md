---
title: 你在教材中看到过最长的证明是什么？
url: https://www.zhihu.com/question/57050011/answer/1928218118376916826
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-14 22:23
modified: 2025-07-14 22:23
upvote_num: 20
comment_num: 1
---

LYM院士关于辛矩阵标准型的讨论。

其实我感觉他证的有问题，后来别人给了更强的结果，看起来是没问题的。

