---
title: 一个政权为什么不能永远依靠暴力让民众服从？
url: https://www.zhihu.com/question/13520684972/answer/116070620223
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-04 15:12
modified: 2025-03-04 15:12
upvote_num: 4
comment_num: 0
---

![](./assets/v2-44d0e63d432987c566d06f4c867a5a6e_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='490' height='490'></svg>)

政权……不会长久的……

