---
title: 你是伪人吗？
url: https://www.zhihu.com/question/1916220300523209890/answer/1921889855744487583
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-27 11:17
modified: 2025-06-27 11:17
upvote_num: 2
comment_num: 1
---

我是奶龙

![](./assets/v2-84056c0b12525005b83d23f2473b11c6_720w.gif)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'></svg>)

