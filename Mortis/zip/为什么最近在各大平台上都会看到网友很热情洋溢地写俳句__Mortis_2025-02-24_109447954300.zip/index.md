---
title: 为什么最近在各大平台上都会看到网友很热情洋溢地写俳句?
url: https://www.zhihu.com/question/13042463378/answer/109447954300
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-24 22:28
modified: 2025-02-24 22:28
upvote_num: 45
comment_num: 12
---

网上写俳句

是出于什么目的

我也不知道

