---
title: 数学中，你最服的技巧是哪个？
url: https://www.zhihu.com/question/66094972/answer/1927760565486466057
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-13 16:05
modified: 2025-07-13 16:05
upvote_num: 276
comment_num: 20
---

陶哲轩的那本加性组合里有这样一个技巧，大概是这样的：

已经得到，左边≤C•右边，C是一个大于1的常数，现在想把C改进为1。我记得是关于图的，把图做n次乘积，再证明可以把n提出了，就得到了左边≤C^1/n•右边，于是C可以改进为1。

