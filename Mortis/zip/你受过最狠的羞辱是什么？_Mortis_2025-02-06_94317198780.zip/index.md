---
title: 你受过最狠的羞辱是什么？
url: https://www.zhihu.com/question/642239067/answer/94317198780
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-06 18:54
modified: 2025-02-06 18:54
upvote_num: 0
comment_num: 0
---

北京、胡同、晚上、遛弯儿、

大狗、调皮、舔我脸一口、

主人说、别舔、脏。

