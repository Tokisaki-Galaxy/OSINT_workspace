---
title: 我觉得《魔法少女小圆》里的丘比是功臣，我的这个认知有偏差吗？
url: https://www.zhihu.com/question/1890502866931807629/answer/1894651083500011839
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-04-13 07:20
modified: 2025-04-13 07:20
upvote_num: 191
comment_num: 2
---

你觉得天堂是存在的，但天堂和现实间隔着一座血海，所以你决定先实现这片血海。

