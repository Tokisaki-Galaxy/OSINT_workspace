---
title: 可以写一句莫名其妙的话吗?
url: https://www.zhihu.com/question/663883875/answer/1917939110615716322
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-16 13:38
modified: 2025-06-16 13:38
upvote_num: 8
comment_num: 1
---

对于有限个给定哈基米哇袄成的叮咚鸡，我们可以构造一组单位正交米哈基，这个大狗被称作AUV-小白手套CCB

