---
title: 如何看待电，烟，星二代，尤其是富二代的权钱接力？然而保家卫国的开国少将爷爷，爸爸老兵，当事人跑外卖？
url: https://www.zhihu.com/question/1934913533029621889/answer/1942633035708229028
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-23 17:03
modified: 2025-08-23 17:03
upvote_num: 121
comment_num: 2
---

“爷爷，我长大后可以当将军吗？”

“当然了，我的孩子，你会成为将军的。”

“那爷爷，我可以成为外卖员吗？”

“这个不行，外卖员也有自己的孙子。”

![](./assets/v2-e073cfc67afce1518d18161d698f5992_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='960' height='980'></svg>)

