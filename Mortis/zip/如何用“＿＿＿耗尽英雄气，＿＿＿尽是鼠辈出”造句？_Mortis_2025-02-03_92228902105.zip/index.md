---
title: 如何用“＿＿＿耗尽英雄气，＿＿＿尽是鼠辈出”造句？
url: https://www.zhihu.com/question/641454824/answer/92228902105
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-03 23:48
modified: 2025-02-03 23:48
upvote_num: 102
comment_num: 3
---

crychic耗尽英雄气，mygo!!!!!尽是鼠辈出。

