---
title: 丰川祥子、海老冢智来了，但你只准备了一个键盘，高情商的你如何处理此事？
url: https://www.zhihu.com/question/1907741097972708582/answer/1918261226150032673
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-17 10:58
modified: 2025-06-17 10:58
upvote_num: 3
comment_num: 0
---

四手联弹

