---
title: 工业克苏鲁什么意思?
url: https://www.zhihu.com/question/648573938/answer/1925121339435508780
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-06 09:18
modified: 2025-07-06 09:18
upvote_num: 1
comment_num: 1
---

**为什么没有按时间排序？**

