---
title: “我爱你，但与你无关”，怎么读懂这句话？
url: https://www.zhihu.com/question/1897393312534622942/answer/1917594987987727427
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-15 14:51
modified: 2025-06-15 14:51
upvote_num: 0
comment_num: 2
---

我爱的是睦，和你Mortis有什么关系？

![](./assets/v2-2e0b44644f8a7321e4c9d0f6adcd92ad_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='8256' height='4992'></svg>)

