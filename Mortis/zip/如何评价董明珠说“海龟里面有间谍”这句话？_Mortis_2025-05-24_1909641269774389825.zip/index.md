---
title: 如何评价董明珠说“海龟里面有间谍”这句话？
url: https://www.zhihu.com/question/1899192867794162558/answer/1909641269774389825
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-24 16:05
modified: 2025-05-24 16:05
upvote_num: 11
comment_num: 1
---

不但海龟里面有间谍，企鹅里面也有！还更多！

高松灯，她是个大叛徒、大内奸、大工贼！造成了非常非常坏的影响和非常非常大的损失！

![](./assets/v2-552b589ede0e0e6af4e8f14c84462185_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2084' height='1200'></svg>)

