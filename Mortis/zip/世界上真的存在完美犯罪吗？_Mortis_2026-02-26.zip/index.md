---
title: 世界上真的存在完美犯罪吗？
url: https://www.zhihu.com/question/378647766/answer/2010142784636612827
author: Mortis
author_badge: saki，联通
location: 日本
created: 2026-02-26 00:03
modified: 2026-02-26 00:03
upvote_num: 81
comment_num: 6
---
“尿床的是姐姐！”

“是姐姐把妈妈羽绒服剪坏了！”

“电视是姐姐看的，我好好写作业呢！”

“姐姐教我的！她说三乘五五乘三都一样。”

“往浴霸上呲水的是姐姐！她说要给浴霸淬火！”

“醋里的小苏打是姐姐放的，她说要给我表演大呲花。”

![](./assets/v2-9b378d42c33091ea373f187ae9b98bf3_720w.jpg)