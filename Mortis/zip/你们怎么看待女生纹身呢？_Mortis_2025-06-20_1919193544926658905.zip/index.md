---
title: 你们怎么看待女生纹身呢？
url: https://www.zhihu.com/question/324660695/answer/1919193544926658905
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-20 00:43
modified: 2025-06-20 00:43
upvote_num: 278
comment_num: 29
---

上高中的时候自残，拿钢笔划手臂，现在墨水也没代谢掉……

