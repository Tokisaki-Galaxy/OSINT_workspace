---
title: 环球小姐因伪造学历获刑 240 天，暴露出哪些问题？选美行业为什么也会有学历崇拜？
url: https://www.zhihu.com/question/1904263305020797410/answer/1905061487384466020
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-12 00:47
modified: 2025-05-12 00:47
upvote_num: 67
comment_num: 4
---

相比之下，少女乐队对学历要求就并不高。

![](./assets/v2-8591ac23190f8874977140886c6f002a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='740' height='556'></svg>)

