---
title: 如果把邦多利所有角色拉进一个聊天群会发生什么？
url: https://www.zhihu.com/question/11564920173/answer/96905879657
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-10 00:02
modified: 2025-02-10 00:02
upvote_num: 72
comment_num: 0
---

Anon酱，不要再发奶龙表情包了，我害怕……

