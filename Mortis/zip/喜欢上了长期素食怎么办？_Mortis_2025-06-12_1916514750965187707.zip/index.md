---
title: 喜欢上了长期素食怎么办？
url: https://www.zhihu.com/question/1915788874262774090/answer/1916514750965187707
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-12 15:18
modified: 2025-06-12 15:18
upvote_num: 1
comment_num: 1
---

只吃素食会缺乏营养，需要通过喝素奶补上这一块。

![](./assets/v2-9a678b959ba52ed64e6fb299edf6c438_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2754' height='3929'></svg>)

