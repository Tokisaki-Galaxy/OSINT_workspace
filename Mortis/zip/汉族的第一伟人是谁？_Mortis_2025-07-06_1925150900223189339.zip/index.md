---
title: 汉族的第一伟人是谁？
url: https://www.zhihu.com/question/1922599560754234381/answer/1925150900223189339
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-06 11:15
modified: 2025-07-06 11:15
upvote_num: 9
comment_num: 0
---

唐可可

![](./assets/v2-0036f5e799b459324c1aad13fe06cc2d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='474' height='474'></svg>)

