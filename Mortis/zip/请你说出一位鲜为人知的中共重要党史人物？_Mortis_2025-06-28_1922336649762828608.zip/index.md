---
title: 请你说出一位鲜为人知的中共重要党史人物？
url: https://www.zhihu.com/question/1919816394779919457/answer/1922336649762828608
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-28 16:52
modified: 2025-06-28 16:52
upvote_num: 94
comment_num: 17
---

**莫悌斯（1893.1.14-1966. ? . ?）**

![](./assets/v2-0c2997f00be9b671c086eebc970750dc_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='629' height='734'></svg>)

