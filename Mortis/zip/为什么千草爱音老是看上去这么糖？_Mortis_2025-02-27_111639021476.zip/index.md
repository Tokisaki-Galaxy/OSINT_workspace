---
title: 为什么千草爱音老是看上去这么糖？
url: https://www.zhihu.com/question/13516458238/answer/111639021476
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-27 11:02
modified: 2025-02-27 11:02
upvote_num: 1731
comment_num: 90
---

千早爱音笑的时候眼神涣散，嘴裂得大。悲伤像泡沫一样浸泡着，但她在想其他的事情。

![](./assets/v2-ffff03a23befd992aeb74d12e61231a8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2127' height='1196'></svg>)

