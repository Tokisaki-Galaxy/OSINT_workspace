---
title: 男人为什么到了一定年纪就喜欢喝酒？
url: https://www.zhihu.com/question/629804174/answer/1968827869087134193
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-11-03 23:52
modified: 2025-11-03 23:52
upvote_num: 43
comment_num: 5
---
留恋母亲的乳汁。

![](./assets/v2-66629b5f96a70fc44ec59eec11d62410_720w.jpg)