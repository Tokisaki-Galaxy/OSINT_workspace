---
title: 分享一句让你一瞬间感动的歌词吧?
url: https://www.zhihu.com/question/12714401071/answer/105399315168
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-20 00:42
modified: 2025-02-20 00:42
upvote_num: 3
comment_num: 1
---

Dropping circle stones on a sun dial

Playing hide and seek with the ghosts of dawn

Waiting for a smile from a sun child

* * *

我感觉我要喝点水

可是你的嘴将我的嘴堵住

* * *

黄色的面孔有红色的污泥

黑色的眼珠有白色的恐惧

* * *

その意味を知る时を迎え

足を踏み入れたは歓楽街

* * *

看着他们为了彼岸，骄傲地、骄傲地灭亡

* * *

