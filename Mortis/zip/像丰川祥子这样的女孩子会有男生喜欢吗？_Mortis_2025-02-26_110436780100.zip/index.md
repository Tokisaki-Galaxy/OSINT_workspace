---
title: 像丰川祥子这样的女孩子会有男生喜欢吗？
url: https://www.zhihu.com/question/13095350927/answer/110436780100
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-26 00:19
modified: 2025-02-26 00:19
upvote_num: 0
comment_num: 0
---

如果能和saki交往，哪怕是开豪车住别墅我都愿意啊！

