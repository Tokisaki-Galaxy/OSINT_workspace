---
title: 假如一天清晨，三角初华从烦躁不安的睡梦中醒来，发现自己在床上变成了一只大的吓人的金毛大狗会怎么样？
url: https://www.zhihu.com/question/1913907496185205610/answer/1916230153354347137
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-11 20:27
modified: 2025-06-11 20:36
upvote_num: 19
comment_num: 1
---

大狗大狗叫

小白脚套真可爱

给我踩踩背

![](./assets/v2-0d64a4bfcb77d1319b14bb312ec1abaa_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='840' height='886'></svg>)

