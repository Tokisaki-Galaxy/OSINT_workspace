---
title: 普通和理所当然的区别是什么?
url: https://www.zhihu.com/question/1912083015460446669/answer/1915070716887430880
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-08 15:40
modified: 2025-06-08 15:40
upvote_num: 6
comment_num: 0
---

老百姓被剥削压迫是一件无数次上演的、极其普通的事情，但并不是理所当然的。

