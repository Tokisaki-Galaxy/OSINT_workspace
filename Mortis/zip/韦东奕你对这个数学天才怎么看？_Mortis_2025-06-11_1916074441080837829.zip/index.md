---
title: 韦东奕你对这个数学天才怎么看？
url: https://www.zhihu.com/question/1914612240939713190/answer/1916074441080837829
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-11 10:09
modified: 2025-06-11 10:09
upvote_num: 1
comment_num: 0
---

以中有足乐者，不知口体之奉不若人也。

