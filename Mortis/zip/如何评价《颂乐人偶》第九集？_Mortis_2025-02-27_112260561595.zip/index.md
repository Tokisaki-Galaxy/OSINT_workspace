---
title: 如何评价《颂乐人偶》第九集？
url: https://www.zhihu.com/question/13583240052/answer/112260561595
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-27 23:50
modified: 2025-02-27 23:50
upvote_num: 10
comment_num: 3
---

![](./assets/v2-89e04bd0ff9604e171e2381718a67302_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='674'></svg>)

