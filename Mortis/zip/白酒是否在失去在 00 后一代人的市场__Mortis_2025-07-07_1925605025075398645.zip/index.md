---
title: 白酒是否在失去在 00 后一代人的市场?
url: https://www.zhihu.com/question/12303778372/answer/1925605025075398645
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-07 17:20
modified: 2025-07-07 17:20
upvote_num: 11
comment_num: 0
---

福寿膏是否正在失去新中国一代人的市场？

