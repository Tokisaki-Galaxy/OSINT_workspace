---
title: 谢惠民教授于 9 月 2 日辞世，如何评价他的一生？
url: https://www.zhihu.com/question/1946236141775852257/answer/1946364075773755401
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-03 00:09
modified: 2025-09-03 00:09
upvote_num: 30
comment_num: 10
---
Q.E.D.