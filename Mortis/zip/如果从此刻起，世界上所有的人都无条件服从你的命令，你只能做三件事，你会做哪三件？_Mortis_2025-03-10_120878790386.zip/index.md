---
title: 如果从此刻起，世界上所有的人都无条件服从你的命令，你只能做三件事，你会做哪三件？
url: https://www.zhihu.com/question/589876285/answer/120878790386
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-10 13:20
modified: 2025-03-10 13:20
upvote_num: 3
comment_num: 2
---

1.全世界所有女同轮流扣丰川祥子

2.三角初华/音除外

3.三角初华/音必须在旁边认真观看，并写观后感

