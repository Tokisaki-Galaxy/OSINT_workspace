---
title: 普通老百姓撞了豪车，是不是真该毁一生？
url: https://www.zhihu.com/question/30340143/answer/90668726293
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-02-01 14:13
modified: 2025-02-01 14:13
upvote_num: 1
comment_num: 0
---

我的发小的父亲去朝鲜谈生意，追尾了将军的迈巴赫，赔了168亿。

![](./assets/v2-71c09f3fa1b31c2c1a2e69b54fd5581a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='474' height='399'></svg>)

