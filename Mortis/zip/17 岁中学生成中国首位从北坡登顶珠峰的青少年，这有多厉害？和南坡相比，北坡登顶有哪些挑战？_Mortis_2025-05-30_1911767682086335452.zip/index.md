---
title: 17 岁中学生成中国首位从北坡登顶珠峰的青少年，这有多厉害？和南坡相比，北坡登顶有哪些挑战？
url: https://www.zhihu.com/question/1911487556740145665/answer/1911767682086335452
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-30 12:55
modified: 2025-05-30 12:55
upvote_num: 0
comment_num: 0
---

超天才

