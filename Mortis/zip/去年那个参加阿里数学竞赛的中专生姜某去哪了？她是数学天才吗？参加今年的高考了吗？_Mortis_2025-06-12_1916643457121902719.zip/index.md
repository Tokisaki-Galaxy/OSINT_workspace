---
title: 去年那个参加阿里数学竞赛的中专生姜某去哪了？她是数学天才吗？参加今年的高考了吗？
url: https://www.zhihu.com/question/1916427994748137663/answer/1916643457121902719
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-12 23:50
modified: 2025-06-16 13:17
upvote_num: 1
comment_num: 0
---

姜萍同学受到了巨大的网络暴力。就在她几乎要终结自己的生命的时候，一首名为《李白》的歌曲拯救了她，给予了她力量。如今，她身处前往燕郊的高铁，前方还是一片雾茫茫。

![](./assets/v2-bc4d7547844d86c9f03c80899e4b74a7_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1809' height='1200'></svg>)

  


![](./assets/v2-811b9b039bfbf668cc435e1083ed2eb2_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='828' height='986'></svg>)

