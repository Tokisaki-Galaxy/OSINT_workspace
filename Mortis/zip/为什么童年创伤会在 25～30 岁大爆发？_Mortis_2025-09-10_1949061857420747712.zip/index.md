---
title: 为什么童年创伤会在 25～30 岁大爆发？
url: https://www.zhihu.com/question/1943330524467819558/answer/1949061857420747712
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-10 10:49
modified: 2025-09-10 10:49
upvote_num: 378
comment_num: 22
---

前已无通路，后不见归途。

![](./assets/v2-25e3779d4e60871e1213ed05bda6972b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1248' height='832'></svg>)

