---
title: 哪一对cp会让你觉得“这也能磕”？
url: https://www.zhihu.com/question/500596251/answer/1944107553366734747
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-27 18:42
modified: 2025-08-27 18:46
upvote_num: 305
comment_num: 20
---

屋里漆黑，我和妹妹盘着腿坐在床上。

妹妹借着手电光做手影。

“这是老鹰，”妹妹扇了扇手掌，老鹰高飞。

“这是兔子，”妹妹曲了曲指节，兔子点头。

“这是大象，”妹妹点了点指尖，大象吸水。

然后，妹妹站起来，跳到地上，她左脚穿着袜子，发出沉闷的咚，而后右脚也着地，右脚光着，发出轻而脆的啪。

她的影子投射在墙上，她的影子比她要高一点。

“这是姐姐，”妹妹说。

我把手电关掉，我充满了屋子。

妹妹喜欢跟自己的影子说话。

一个晚上，我们沿着河堤路散步，月光亮，路灯亮，远处桥上的广告牌往往也亮，往往滚动着一些文旅宣传标语，我不知道给本地人看这些有什么用，贫穷出不去，病毒进不来。

但是广告牌坏了，就在这个晚上，串联着的公共厕所的灯也坏了。

“跟我上个厕所。”

“你自己去吧，我坐着歇会儿。”

我自己去了，我听见她在用手机放歌：

> When you were young, you were the king of carrot flowers，  
> 记得小时候，你是胡萝卜花国王，  
> And how you built a tower tumbling through the trees，  
> 在树丛间搭了歪斜的塔楼，  
> In holy rattlesnake that fell all around your feet，  
> 响尾蛇落在你的脚边，  
> And your mom would stick a fork right into daddy's shoulder，  
> 你妈妈拿叉子擦着了你爸爸肩膀，  
> And dad would throw the garbage all across the floor，  
> 你爸爸抛出的废品地面上空飞跃。

我离厕所越来越近，离她越来越远，我听不清了。

我回来的时候，她已经关掉了音乐，她背对路灯，坐在临河的方形石墩上，每个石墩之间拴着铁链，自然下垂，在理想情形下，我会算它们的曲线方程。

妹妹低着头，嘴里嘀嘀咕咕。

我离她越来越近，我马上就能听清了，她不说了。

“干嘛呢？”

“唠嗑。”

“和谁？”

“影子。”

妹妹的影子长长的躺在倾斜河堤上，头部浸入水中。

“你的影子喘不上气啦。”

“它是鱼。”

我把妹妹从石墩子上拉起来，“别坐这上面，不安全。我看新闻，有个老头子拽这种石墩子间的铁链练功，一下子拽倒了，一倒倒一片，从发源地倒到入海口。”

“那他可能会以为自己是一个武术奇才吧。”

我们继续散步了。

“你和影子唠啥了？”

“唠登月的事情，”妹妹说，“在月亮很亮的时候上去，这样，我的影子就会很大，整个地球也装不下，它会投得很远，一直投到其他星球上。”

![](./assets/v2-33075ea4ec597a1a23a307c285f058d8_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='900' height='900'></svg>)

  


![](./assets/v2-98bb747935f81955220de9f38132e688_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1197' height='1844'></svg>)

