---
title: 希特勒在中国的人气很高吗？
url: https://www.zhihu.com/question/15578162594/answer/1913026396764247428
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-06-03 00:17
modified: 2025-06-03 00:17
upvote_num: 29
comment_num: 4
---

越是陌生，越是亲切；

越是残暴，越是慈爱；

越是邪恶，越是伟大；

越是思考，越是疲劳；

越是自由，越是迷茫。

