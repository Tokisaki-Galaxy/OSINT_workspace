---
title: 女朋友宣称能吃出河里野生鱼和池塘里鱼的味道差别，她是在骗我吗？
url: https://www.zhihu.com/question/549961837/answer/1966260837598619552
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-27 21:51
modified: 2025-10-27 21:51
upvote_num: 550
comment_num: 20
---
烹饪8份鱼肉，其中4份野生河鱼，4份池塘鱼，让女朋友品尝。

如果她瞎蒙，8道全对的概率为1/70，小于原神三抽出金的概率，这几乎不可能。

如果她瞎蒙，答错一道的概率是16/70，远高于小保底歪迪卢克的概率，建议去评选知乎最弱超能力。

![](./assets/v2-f05a4a35a4096697e3b87da5b844186d_720w.jpg)