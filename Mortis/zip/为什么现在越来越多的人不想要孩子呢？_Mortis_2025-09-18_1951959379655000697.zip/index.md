---
title: 为什么现在越来越多的人不想要孩子呢？
url: https://www.zhihu.com/question/455330834/answer/1951959379655000697
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-09-18 10:43
modified: 2025-09-18 10:56
upvote_num: 319
comment_num: 15
---

亚当在上帝建造的伊甸园里不知生活了多久，一日，他感到无聊，取下一根肋骨，创造了夏娃，夏娃降生之时，伊甸园内风雨如晦，悲鸣不已。

有至圣先师牛顿降临，命夏娃绕亚当做圆锥曲线运动：爱则以椭圆轨道拥抱，厌则以双曲线或抛物线别离。

伊甸园恢复如常。

亚当夏娃情久生日，孕有一子。子诞之日，伊甸园内天崩地裂，宛若末世。

有大贤能庞加莱踏破虚空，告诫三人：

“三体问题无人能解。

你们怎么办，只有天知道。”

![](./assets/v2-cfc7b7ac3800cc4e8fd957f78ee927b3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1615'></svg>)

