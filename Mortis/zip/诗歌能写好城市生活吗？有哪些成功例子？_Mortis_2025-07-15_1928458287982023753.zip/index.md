---
title: 诗歌能写好城市生活吗？有哪些成功例子？
url: https://www.zhihu.com/question/1924068783972120507/answer/1928458287982023753
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-15 14:18
modified: 2025-07-15 14:18
upvote_num: 14
comment_num: 2
---

## Pictures of A City

**Peter Sinfield**

Concrete cold face cased in steel，

Stark sharp glass-eyed crack and peel，

Bright light scream beam brake and squeal，

Red white green white neon wheel.

Dream flesh love chase perfumed skin，

Greased hand teeth hide tinseled sin，

Spice ice dance chance sickly grin，

Pasteboard time slot sweat and spin.

Blind stick blind drunk cannot see，

Mouth dry tongue tied cannot speak，

Concrete dream flesh broken shell，

Lost soul lost trace lost in hell.

![](./assets/v2-be65f28bedba386b969c911b8e756403_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1400' height='1400'></svg>)

