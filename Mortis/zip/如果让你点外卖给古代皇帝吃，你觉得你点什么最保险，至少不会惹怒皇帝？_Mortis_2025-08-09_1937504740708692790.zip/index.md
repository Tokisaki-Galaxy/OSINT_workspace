---
title: 如果让你点外卖给古代皇帝吃，你觉得你点什么最保险，至少不会惹怒皇帝？
url: https://www.zhihu.com/question/1936546383587969004/answer/1937504740708692790
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-09 13:25
modified: 2025-08-09 13:25
upvote_num: 4822
comment_num: 385
---

西葫芦炖茄子，加一点肉，日一声打成糊糊。

![](./assets/v2-c73171ad3b1926d53a13b5c36700ba6a_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1240' height='1754'></svg>)

