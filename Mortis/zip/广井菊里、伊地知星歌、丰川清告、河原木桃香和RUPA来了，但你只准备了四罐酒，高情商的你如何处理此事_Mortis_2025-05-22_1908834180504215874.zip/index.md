---
title: 广井菊里、伊地知星歌、丰川清告、河原木桃香和RUPA来了，但你只准备了四罐酒，高情商的你如何处理此事？
url: https://www.zhihu.com/question/1907871710809679548/answer/1908834180504215874
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-22 10:38
modified: 2025-05-22 10:38
upvote_num: 0
comment_num: 2
---

开罐之后广井菊里喝一口，然后嘴对嘴喂，循环以上过程（固定一个人嘴对嘴喂是为了保证每一口几乎相等）。

当一口的量趋于零时，每人最终喝的误差趋于零。

