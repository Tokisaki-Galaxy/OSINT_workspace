---
title: 据说《哪吒2》在日本上映门票被抢光，这会不会对日本动漫产生深远的影响？
url: https://www.zhihu.com/question/1885635541053207763/answer/1889047126106940974
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-28 20:12
modified: 2025-03-28 20:12
upvote_num: 9
comment_num: 3
---

不如BanG Dream Ave Mujica.

