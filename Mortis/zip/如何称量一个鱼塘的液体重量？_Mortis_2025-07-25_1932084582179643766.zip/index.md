---
title: 如何称量一个鱼塘的液体重量？
url: https://www.zhihu.com/question/562775394/answer/1932084582179643766
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-25 14:27
modified: 2025-07-25 14:27
upvote_num: 12
comment_num: 1
---

我记得**“听音辨鼓”** 问题的一个结论是：

你能听出鼓的体积。

那么，只需要再乘以密度就行了。

