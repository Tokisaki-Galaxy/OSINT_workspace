---
title: 庙里的和尚一个个满面红光的，他们真的不吃肉吗？
url: https://www.zhihu.com/question/655537142/answer/1962102257010074755
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-10-16 10:27
modified: 2025-10-16 10:27
upvote_num: 455
comment_num: 42
---

有二高僧得道，瘦者遍体金光，胖者唯余臀部。

观者好奇，问于弟子，弟子曰：

**胖师傅下面食荤，瘦师傅割肉饲虎。**

![](./assets/v2-cfc7b7ac3800cc4e8fd957f78ee927b3_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1615'></svg>)

