---
title: 为什么姜萍一消失，王虹就证明了挂谷猜想，希尔伯特第六问题也被解决?
url: https://www.zhihu.com/question/14489215103/answer/1902673851852252914
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-05 10:39
modified: 2025-05-05 10:39
upvote_num: 12
comment_num: 0
---

jumping一消失，柿本广大就拍出了mujica.

