---
title: 建议让全国各地所有中小学一律统一让女性剪齐耳短发 都要剪短发 一律实行一刀切 你们支持吗？
url: https://www.zhihu.com/question/1926226575986259057/answer/1927417407485478818
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-12 17:21
modified: 2025-07-12 17:21
upvote_num: 205
comment_num: 10
---

高中老师不让我披头散发的，于是我就改马尾了，

**从面前垂下来的那种。**

