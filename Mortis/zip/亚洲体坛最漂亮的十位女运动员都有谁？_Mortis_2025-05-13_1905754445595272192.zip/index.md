---
title: 亚洲体坛最漂亮的十位女运动员都有谁？
url: https://www.zhihu.com/question/493728026/answer/1905754445595272192
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-13 22:41
modified: 2025-05-13 22:41
upvote_num: 10
comment_num: 1
---

![](./assets/v2-0f328501417d65ef386a08476e979b02_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='2800' height='1400'></svg>)

