---
title: 日出而作，下一句是什么？
url: https://www.zhihu.com/question/1912391243603907295/answer/1934678151759369086
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-08-01 18:13
modified: 2025-08-01 18:13
upvote_num: 44
comment_num: 8
---

日落而射

![](./assets/v2-8e0aa5ff649bffc30c7793fc17406c7d_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1397' height='2048'></svg>)

