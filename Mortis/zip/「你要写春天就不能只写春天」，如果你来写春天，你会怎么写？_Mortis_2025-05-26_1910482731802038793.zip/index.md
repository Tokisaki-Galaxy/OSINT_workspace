---
title: 「你要写春天就不能只写春天」，如果你来写春天，你会怎么写？
url: https://www.zhihu.com/question/1888635188176744454/answer/1910482731802038793
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-05-26 23:49
modified: 2025-05-26 23:59
upvote_num: 1
comment_num: 0
---

冰雪消融，尸体腐烂。

![](./assets/v2-46bbd489edff104936cf973d0f351311_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1198'></svg>)

  


![](./assets/v2-149bb184d12720226070e2a238eab33b_720w.jpg)![](data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='1200' height='1198'></svg>)

