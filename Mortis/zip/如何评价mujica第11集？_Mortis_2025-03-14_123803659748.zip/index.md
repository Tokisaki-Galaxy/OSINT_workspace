---
title: 如何评价mujica第11集？
url: https://www.zhihu.com/question/14890802255/answer/123803659748
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-03-14 00:19
modified: 2025-03-14 00:19
upvote_num: 30
comment_num: 1
---

阴暗、扭曲、爬行

