---
title: 在中国儿子就那么重要吗?
url: https://www.zhihu.com/question/1899331587742597522/answer/1927511170044100949
author: Mortis
author_badge: saki，联通
location: 日本
created: 2025-07-12 23:34
modified: 2025-07-13 00:42
upvote_num: 204
comment_num: 14
---

N年前，一个远房亲戚来串门。趁我家大人不在，他要用童子尿煮鸡蛋，就准备去对门家要点童子尿。妹妹跟他说，我就是童子，我尿。亲戚讲，你算什么童子，得是男孩，必须是童男子的煮。

